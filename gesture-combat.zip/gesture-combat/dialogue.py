"""
dialogue.py - Cinematic Boss Dialogue System (Floor 50 Judge of Truth).
Part of the GLYPH-BLADE modular architecture.
"""

import math
import pygame

from config import VIEW_WIDTH, VIEW_HEIGHT, TEXT_GOLD, TEXT_WHITE, TEXT_CYAN
from achievements import ACHIEVEMENT_MANAGER


def open_boss_dialogue(game):
    """Initiates the Floor 50 cinematic dialogue encounter with the Judge of Truth."""
    game.state = 'BOSS_DIALOGUE'
    game.dialogue_stage = 'QUESTION'
    game.dialogue_anim_time = 0.0
    game.dialogue_rects = {}
    game.dialogue_choice = None
    game.dialogue_boss_name = "ВЕРХОВНЫЙ СУДИЯ ИСТИНЫ [БОСС 50 ЭТАЖА]"
    game.dialogue_boss_title = "Хранитель 50-го Эшелона • Владыка Весов Судеб"
    game.dialogue_question_lines = [
        "Смертный... Ты преодолел 50 кругов преисподней и дерзнул ступить в Чертог Истины.",
        "Я зрю сквозь плоть и время, взвешивая твою душу на священных Весах Судьбы.",
        "Ответь мне перед ликом Вечности: ты прошёл игру без урона?"
    ]
    game.dialogue_result_title = ""
    game.dialogue_result_lines = []
    game.dialogue_result_color = TEXT_GOLD
    game.dialogue_damage_reported = 0


def handle_boss_dialogue_choice(game, choice_idx):
    """Processes the player's answer (1: 'Да' / 2: 'Нет') and detects lies."""
    if game.dialogue_stage != 'QUESTION':
        return

    game.dialogue_choice = choice_idx
    damage_taken = getattr(game.player, 'total_damage_taken_run', 0.0)
    hits_taken = getattr(game.player, 'total_hits_taken_run', 0)
    game.dialogue_damage_reported = int(damage_taken)

    if choice_idx == 1:
        # Player said "Да, без урона!"
        if damage_taken > 0 or hits_taken > 0:
            # PLAYER LIED!
            game.dialogue_stage = 'ANSWER_LIED'
            game.dialogue_result_title = "ВРУНИШКА! ЖАЛКИЙ ЛЖЕЦ!"
            game.dialogue_result_color = (255, 60, 60)
            game.dialogue_result_lines = [
                "Я чую запах твоей запекшейся крови и считаю каждый полученный шрам!",
                f"Ты получил {int(damage_taken)} урона ({hits_taken} попаданий) за этот забег, но посмел солгать Судье!",
                "Весы Правосудия обрушатся на тебя со всесокрушающей яростью за твой обман!"
            ]
            game.fx.add_screen_shake(30.0)
            game.sfx.play("crit")

            # Enrage the boss on floor 50!
            for en in game.enemies:
                if en.id == "judge_of_truth":
                    en.enraged = True
                    en.speed *= 1.25
                    en.damage *= 1.20
                    game.fx.spawn_sparks(en.x, en.y, (255, 40, 60), count=55, speed=290)
                    game.fx.add_floating_text("В БЕШЕНСТВЕ ОТ ЛЖИ! (+25% СКОРОСТЬ)", en.x, en.y - 70, (255, 50, 50), size=26)

            # UNLOCK ACHIEVEMENT «Врунишка»
            ACHIEVEMENT_MANAGER.unlock("liar_achievement", game.fx, game.sfx)
        else:
            # TRUE NO-HIT GOD!
            game.dialogue_stage = 'ANSWER_NO_HIT'
            game.dialogue_result_title = "НЕВЕРОЯТНО... БОГ БЕЗУПРЕЧНОСТИ!"
            game.dialogue_result_color = (120, 240, 255)
            game.dialogue_result_lines = [
                "Священные Весы неподвижны... Твои доспехи девственно чисты!",
                "Ни единой царапины, ни капли крови за все 50 этажей преисподней!",
                "Ты воистину величайший мастер клинка. Священный бой равных начинается!"
            ]
            game.fx.add_screen_shake(16.0)
            game.sfx.play("parry")
    elif choice_idx == 2:
        # Player said "Нет, я получал урон" (Truth)
        game.dialogue_stage = 'ANSWER_TRUTH'
        game.dialogue_result_title = "ЧЕСТНОСТЬ ПЕРЕД ЛИКОМ СУДЬБЫ"
        game.dialogue_result_color = (255, 215, 80)
        game.dialogue_result_lines = [
            "Твоя искренность достойна истинного воина клинка.",
            f"Шрамы (ты выдержал {int(damage_taken)} урона) лишь закаляют дух смертного.",
            "Ты не пытался обмануть Весы Истины. Докажи теперь силу своего духа в бою!"
        ]
        game.fx.add_screen_shake(12.0)
        game.sfx.play("parry")


def close_boss_dialogue(game):
    """Ends the dialogue and starts the boss combat."""
    game.state = 'PLAYING'
    game.sfx.play("dash")
    game.fx.add_screen_shake(20.0)
    game.fx.add_floating_text("⚡ БИТВА ЗА СУДЬБУ: 50 ЭТАЖ! ⚡", game.player.x, game.player.y - 120, TEXT_GOLD, size=32)


def draw_boss_dialogue(game, surface, anim_time, fonts):
    """Renders the cinematic Level 50 Boss Dialogue window and choices."""
    w = surface.get_width() if surface else VIEW_WIDTH
    h = surface.get_height() if surface else VIEW_HEIGHT

    # 1. Dark atmospheric overlay
    overlay = pygame.Surface((w, h), pygame.SRCALPHA)
    overlay.fill((6, 8, 14, 235))
    surface.blit(overlay, (0, 0))

    # 2. Main Dialogue Frame
    box_w, box_h = 960, 480
    bx = w // 2 - box_w // 2
    by = 110
    dlg_rect = pygame.Rect(bx, by, box_w, box_h)

    # Pulse border
    pulse = 0.5 + 0.5 * math.sin(anim_time * 5.0)
    border_glow = (
        int(255 * (0.8 + 0.2 * pulse)),
        int(215 * (0.8 + 0.2 * pulse)),
        int(60 * (0.8 + 0.2 * pulse))
    )
    bg_surf = pygame.Surface((box_w, box_h), pygame.SRCALPHA)
    bg_surf.fill((12, 16, 26, 245))
    surface.blit(bg_surf, (bx, by))
    pygame.draw.rect(surface, border_glow, dlg_rect, 2, border_radius=8)

    # Inner decorative gold line
    inner_rect = pygame.Rect(bx + 6, by + 6, box_w - 12, box_h - 12)
    pygame.draw.rect(surface, (60, 50, 25), inner_rect, 1, border_radius=6)

    # 3. Boss Portrait / Crest (Left side)
    p_rect = pygame.Rect(bx + 24, by + 24, 150, 190)
    pygame.draw.rect(surface, (18, 22, 34), p_rect, border_radius=6)
    pygame.draw.rect(surface, (255, 215, 80), p_rect, 1, border_radius=6)

    # Draw Inquisitor boss sprite in portrait!
    inq_img = getattr(game.art, 'inquisitor_sprite', None)
    if inq_img:
        port_sprite = pygame.transform.smoothscale(inq_img, (120, 120))
        tint_surf = pygame.Surface((120, 120), pygame.SRCALPHA)
        tint_surf.fill((255, 215, 60, 60))
        port_sprite.blit(tint_surf, (0, 0), special_flags=pygame.BLEND_RGBA_ADD)
        surface.blit(port_sprite, (p_rect.centerx - 60, p_rect.y + 16))
    else:
        sym_f = fonts.get("sym_large", fonts["large"])
        s_icon = sym_f.render("⚖", True, (255, 220, 80))
        surface.blit(s_icon, (p_rect.centerx - s_icon.get_width() // 2, p_rect.y + 35))

    p_lbl = fonts["med"].render("СУДИЯ", True, TEXT_GOLD)
    surface.blit(p_lbl, (p_rect.centerx - p_lbl.get_width() // 2, p_rect.bottom - 44))
    p_sub = fonts["small"].render("50 ЭТАЖ", True, (200, 220, 240))
    surface.blit(p_sub, (p_rect.centerx - p_sub.get_width() // 2, p_rect.bottom - 24))

    # 4. Boss Title & Header
    title_x = bx + 195
    title_y = by + 24
    b_name = fonts["title"].render("ВЕРХОВНЫЙ СУДИЯ ИСТИНЫ", True, TEXT_GOLD)
    surface.blit(b_name, (title_x, title_y))

    b_tit = fonts["small"].render("[БОСС 50 ЭТАЖА] • Хранитель 50-го Эшелона • Владыка Весов Судеб", True, (190, 215, 245))
    surface.blit(b_tit, (title_x, title_y + 36))

    # Golden separator rule
    pygame.draw.line(surface, (90, 80, 50), (title_x, title_y + 60), (bx + box_w - 24, title_y + 60), 1)

    m_pos = pygame.mouse.get_pos()
    game.dialogue_rects = {}

    # 5. Content based on stage
    if game.dialogue_stage == 'QUESTION':
        # Speech lines
        sy = title_y + 72
        for line in game.dialogue_question_lines[:-1]:
            s_surf = fonts["med"].render(line, True, (220, 230, 245))
            surface.blit(s_surf, (title_x, sy))
            sy += 24

        # Main Question (Glowing highlight)
        q_surf = fonts["large"].render(f"«{game.dialogue_question_lines[-1].split(':')[-1].strip('«» ')}»", True, (255, 230, 100))
        surface.blit(q_surf, (title_x, sy + 6))

        # Option 1: "Да, ни единой царапины!" (Lie if took damage)
        opt1_rect = pygame.Rect(title_x, by + 235, 740, 78)
        game.dialogue_rects["opt1"] = opt1_rect
        is_hov1 = opt1_rect.collidepoint(m_pos)

        bg1 = (25, 34, 52) if is_hov1 else (16, 22, 34)
        bdr1 = (255, 215, 80) if is_hov1 else (70, 90, 130)
        pygame.draw.rect(surface, bg1, opt1_rect, border_radius=6)
        pygame.draw.rect(surface, bdr1, opt1_rect, 2 if is_hov1 else 1, border_radius=6)

        badge1 = pygame.Rect(opt1_rect.x + 12, opt1_rect.y + 14, 46, 50)
        pygame.draw.rect(surface, (20, 26, 42), badge1, border_radius=4)
        pygame.draw.rect(surface, (255, 215, 80), badge1, 1, border_radius=4)
        k1_s = fonts["large"].render("[1]", True, TEXT_GOLD)
        surface.blit(k1_s, (badge1.centerx - k1_s.get_width() // 2, badge1.centery - k1_s.get_height() // 2))

        t1_s = fonts["med"].render("«Да, ни единой царапины! Я прошел без единицы урона!»", True, TEXT_WHITE if not is_hov1 else TEXT_GOLD)
        surface.blit(t1_s, (opt1_rect.x + 70, opt1_rect.y + 14))
        sub1_s = fonts["small"].render("Заявить о безупречности забега  (Соврать Судье, если ты получал урон)", True, (180, 200, 225))
        surface.blit(sub1_s, (opt1_rect.x + 70, opt1_rect.y + 42))

        # Option 2: "Нет, меня ранили" (Truth)
        opt2_rect = pygame.Rect(title_x, by + 325, 740, 78)
        game.dialogue_rects["opt2"] = opt2_rect
        is_hov2 = opt2_rect.collidepoint(m_pos)

        bg2 = (22, 36, 46) if is_hov2 else (16, 22, 34)
        bdr2 = (120, 240, 255) if is_hov2 else (70, 90, 130)
        pygame.draw.rect(surface, bg2, opt2_rect, border_radius=6)
        pygame.draw.rect(surface, bdr2, opt2_rect, 2 if is_hov2 else 1, border_radius=6)

        badge2 = pygame.Rect(opt2_rect.x + 12, opt2_rect.y + 14, 46, 50)
        pygame.draw.rect(surface, (20, 26, 42), badge2, border_radius=4)
        pygame.draw.rect(surface, (120, 240, 255), badge2, 1, border_radius=4)
        k2_s = fonts["large"].render("[2]", True, TEXT_CYAN)
        surface.blit(k2_s, (badge2.centerx - k2_s.get_width() // 2, badge2.centery - k2_s.get_height() // 2))

        t2_s = fonts["med"].render("«Нет, меня ранили на этом тернистом пути.»", True, TEXT_WHITE if not is_hov2 else TEXT_CYAN)
        surface.blit(t2_s, (opt2_rect.x + 70, opt2_rect.y + 14))
        sub2_s = fonts["small"].render("Признать полученные раны  (Сказать чистую правду перед Весами Истины)", True, (180, 200, 225))
        surface.blit(sub2_s, (opt2_rect.x + 70, opt2_rect.y + 42))

        # Bottom hint
        hint_s = fonts["small"].render("Нажми клавишу [1] или [2] на клавиатуре, либо кликни ЛКМ по варианту ответа", True, (150, 170, 200))
        surface.blit(hint_s, (bx + box_w // 2 - hint_s.get_width() // 2, by + box_h - 32))

    else:
        # Result Stage (ANSWER_LIED / ANSWER_NO_HIT / ANSWER_TRUTH)
        res_y = title_y + 72
        hdr_surf = fonts["large"].render(game.dialogue_result_title, True, game.dialogue_result_color)
        surface.blit(hdr_surf, (title_x, res_y))
        res_y += 36

        if game.dialogue_stage == 'ANSWER_LIED':
            sym_m = fonts.get("sym_med", fonts["med"])
            star_s = sym_m.render("★", True, (255, 110, 195))
            ach_txt = fonts["med"].render(" РАЗБЛОКИРОВАНО СЕКРЕТНОЕ ДОСТИЖЕНИЕ: «ВРУНИШКА»! ", True, (255, 110, 195))
            surface.blit(star_s, (title_x, res_y))
            surface.blit(ach_txt, (title_x + star_s.get_width(), res_y))
            surface.blit(star_s, (title_x + star_s.get_width() + ach_txt.get_width(), res_y))
            res_y += 28

            sym_s = fonts.get("sym_small", fonts["small"])
            skull_s = sym_s.render("☠", True, (255, 90, 90))
            buff_txt = fonts["small"].render(" СУДИЯ РАЗЪЯРЕН ЛОЖЬЮ: СКОРОСТЬ +25%, УРОН +20%! ВЕСЫ СКЛОНИЛИСЬ ПРОТИВ ТЕБЯ!", True, (255, 90, 90))
            surface.blit(skull_s, (title_x, res_y))
            surface.blit(buff_txt, (title_x + skull_s.get_width() + 4, res_y))
            res_y += 28

        for line in game.dialogue_result_lines:
            s_surf = fonts["med"].render(line, True, (220, 235, 250))
            surface.blit(s_surf, (title_x, res_y))
            res_y += 25

        # Continue Button
        btn_w, btn_h = 440, 54
        btn_rect = pygame.Rect(bx + box_w // 2 - btn_w // 2, by + box_h - 76, btn_w, btn_h)
        game.dialogue_rects["btn_continue"] = btn_rect
        is_hov = btn_rect.collidepoint(m_pos)

        if game.dialogue_stage == 'ANSWER_LIED':
            b_bg = (55, 16, 24) if is_hov else (38, 12, 18)
            b_bdr = (255, 80, 80) if is_hov else (200, 50, 50)
            btn_txt = "[ ПРИНЯТЬ КАРУ! В БОЙ (ПРОБЕЛ) ]"
            txt_col = (255, 230, 230)
        elif game.dialogue_stage == 'ANSWER_NO_HIT':
            b_bg = (18, 45, 55) if is_hov else (12, 32, 40)
            b_bdr = (120, 240, 255) if is_hov else (70, 180, 210)
            btn_txt = "[ В СВЯЩЕННЫЙ БОЙ (ПРОБЕЛ) ]"
            txt_col = (220, 255, 255)
        else:
            b_bg = (45, 38, 18) if is_hov else (32, 26, 12)
            b_bdr = (255, 215, 80) if is_hov else (190, 160, 50)
            btn_txt = "[ НАЧАТЬ ПОЕДИНОК (ПРОБЕЛ) ]"
            txt_col = TEXT_GOLD

        pygame.draw.rect(surface, b_bg, btn_rect, border_radius=6)
        pygame.draw.rect(surface, b_bdr, btn_rect, 2, border_radius=6)
        b_s = fonts["large"].render(btn_txt, True, txt_col)
        surface.blit(b_s, (btn_rect.centerx - b_s.get_width() // 2, btn_rect.centery - b_s.get_height() // 2))
