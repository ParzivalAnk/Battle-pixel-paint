"""
dev_glyph_studio.py - Developer Glyph Studio & Sacred Pattern Engineering Engine.
Provides precision arrow-key vector drawing, auto-smoothing/tidying algorithms,
live similarity analysis against Wild Magic patterns, ritual testing, and game export.
Protected by secret developer passcode: antigravity-paintly-ParzivalAnk-1546p.
"""

import os
import sys
import math
import json
import time
import copy
import pygame

from config import (
    VIEW_WIDTH,
    VIEW_HEIGHT,
    TEXT_GOLD,
    TEXT_CYAN,
    TEXT_RED,
    TEXT_WHITE,
    TEXT_PURPLE,
)
from recognizer import Point, resample, scale_and_center, gesture_distance, bounding_box
import wild_magic
from hud import render_mixed_text

# Secret developer access key
DEV_SECRET_CODE = "antigravity-paintly-ParzivalAnk-1546p"
CUSTOM_GLYPHS_FILE = "custom_wild_glyphs.json"


def safe_get_clipboard_text():
    """Safely retrieves text from clipboard with multiple cross-platform fallbacks."""
    try:
        if pygame.scrap.get_init():
            raw = pygame.scrap.get(pygame.SCRAP_TEXT)
            if raw:
                text = raw.decode("utf-8", errors="ignore").replace("\x00", "").strip()
                if text:
                    return text
    except Exception:
        pass
    try:
        import tkinter as tk
        root = tk.Tk()
        root.withdraw()
        text = root.clipboard_get()
        root.destroy()
        return text.strip() if text else ""
    except Exception:
        pass
    return ""


def safe_set_clipboard_text(text):
    """Safely copies text to system clipboard."""
    try:
        if pygame.scrap.get_init():
            pygame.scrap.put(pygame.SCRAP_TEXT, text.encode("utf-8"))
    except Exception:
        pass
    try:
        import tkinter as tk
        root = tk.Tk()
        root.withdraw()
        root.clipboard_clear()
        root.clipboard_append(text)
        root.update()
        root.destroy()
    except Exception:
        pass


def chaikin_smooth(points, iterations=2):
    """Applies Chaikin's corner cutting algorithm for organic, aesthetic curves."""
    if len(points) < 3:
        return list(points)
    
    current = list(points)
    for _ in range(iterations):
        smoothed = [current[0]]
        for i in range(len(current) - 1):
            p0 = current[i]
            p1 = current[i + 1]
            q = (0.75 * p0[0] + 0.25 * p1[0], 0.75 * p0[1] + 0.25 * p1[1])
            r = (0.25 * p0[0] + 0.75 * p1[0], 0.25 * p0[1] + 0.75 * p1[1])
            smoothed.append(q)
            smoothed.append(r)
        smoothed.append(current[-1])
        current = smoothed
    return current


def tidy_and_smooth_stroke(points, is_closed=False, snap_angles=True, smooth_curves=True):
    """
    Auto-smoothing & Tidying Engine:
    - Removes duplicate / jittery micro-points
    - Identifies sharp corners (> 45 deg) to preserve geometric apexes
    - Snaps near-orthogonal and 45-degree diagonal segments
    - Applies Chaikin smoothing to curved stretches
    - Snaps start & end together if closed
    - Equidistant arc-length resampling to 64 points
    - Centers and normalizes into [-50, 50] coordinate box
    """
    if len(points) < 2:
        return [], []

    # 1. Deduplicate & filter jitter
    filtered = [points[0]]
    for p in points[1:]:
        dist = math.hypot(p[0] - filtered[-1][0], p[1] - filtered[-1][1])
        if dist >= 4.0:
            filtered.append(p)

    if len(filtered) < 2:
        filtered = list(points)

    # 2. Angle snapping on segments between vertices
    if snap_angles and len(filtered) >= 3:
        snapped = [filtered[0]]
        for i in range(1, len(filtered)):
            px, py = filtered[i]
            prev_x, prev_y = snapped[-1]
            dx = px - prev_x
            dy = py - prev_y
            dist = math.hypot(dx, dy)
            if dist < 6.0:
                continue

            angle = math.atan2(dy, dx)
            # Find nearest 45 degree increment (0, 45, 90, 135, 180, -45, -90, -135)
            step_rad = math.pi / 4.0
            nearest_k = round(angle / step_rad)
            target_angle = nearest_k * step_rad

            # If within 14 degrees of a crisp axis or diagonal, snap it!
            if abs(angle - target_angle) < (math.pi / 12.0):
                snapped_x = prev_x + dist * math.cos(target_angle)
                snapped_y = prev_y + dist * math.sin(target_angle)
                snapped.append((snapped_x, snapped_y))
            else:
                snapped.append((px, py))
        filtered = snapped

    # 3. Close contour if requested or endpoints are near
    d_endpoints = math.hypot(filtered[-1][0] - filtered[0][0], filtered[-1][1] - filtered[0][1])
    should_close = is_closed or (d_endpoints < 45.0 and len(filtered) >= 4)
    if should_close:
        filtered[-1] = filtered[0]

    # 4. Curve smoothing
    if smooth_curves and len(filtered) >= 4:
        smoothed_pts = chaikin_smooth(filtered, iterations=2)
    else:
        smoothed_pts = list(filtered)

    if should_close:
        smoothed_pts[-1] = smoothed_pts[0]

    # 5. Resample to standard 64 equidistant points & normalize [-50, 50]
    rec_pts = [Point(x, y) for x, y in smoothed_pts]
    resampled_64 = resample(rec_pts, 64)
    normalized_64 = scale_and_center(resampled_64, 100.0)

    return smoothed_pts, normalized_64


class DevGlyphStudio:
    """
    Interactive Developer Glyph Studio.
    Provides pixel-perfect grid navigation with arrow keys, auto-smoothing,
    Wild Magic similarity benchmarking, test tracing, and persistence to game files.
    """

    def __init__(self, game=None):
        self.game = game

        # Geometry & Canvas
        self.canvas_rect = pygame.Rect(295, 72, 580, 550)
        self.canvas_cx = self.canvas_rect.centerx
        self.canvas_cy = self.canvas_rect.centery
        self.ui_rects = {}

        # Pen & Grid State
        self.grid_step = 20  # [5, 10, 20, 40]
        self.snap_to_grid = True
        self.pen_down = False
        self.pen_pos = [self.canvas_cx, self.canvas_cy]  # Current screen pos
        self.mouse_drawing = False

        # Stroke Points
        self.raw_points = []
        self.smoothed_points = []
        self.normalized_64 = []
        self.undo_stack = []

        # Modes & Settings
        self.is_closed = False
        self.symmetry_mode = False  # Mirror across vertical axis
        self.view_mode = "SMOOTHED"  # "RAW", "SMOOTHED", "RESAMPLED_64"
        self.snap_angles = True
        self.smooth_curves = True

        # Metadata
        self.glyph_id = "CUSTOM_WILD_GLYPH"
        self.glyph_name = "Первородная Звезда Эфира"
        self.glyph_symbol = "✦"
        self.glyph_duration = 20.0
        self.glyph_color = (120, 240, 255)
        self.glyph_desc = "Священный геометрический глиф, созданный в Студии Разработчика."
        self.boss_req = 0

        # UI state
        self.active_input_field = None  # "ID", "NAME", "DESC"
        self.cursor_blink_time = 0.0
        self.feedback_text = "Студия готова. Черти стрелочками ↑↓←→ или мышью!"
        self.feedback_color = TEXT_CYAN
        self.feedback_timer = 4.0
        self.similarity_matches = []

        # Test Tracing Mode inside studio
        self.testing_ritual = False
        self.test_drawn_points = []
        self.test_timer = 0.0
        self.test_max_timer = 20.0
        self.test_score = 0.0
        self.test_completed = False

        # Fonts
        self._init_fonts()

        # Load existing custom glyphs if present
        self.load_custom_glyphs_from_disk()

    def _init_fonts(self):
        if self.game and hasattr(self.game, 'font_title'):
            self.font_title = self.game.font_title
            self.font_large = self.game.font_large
            self.font_med = self.game.font_med
            self.font_small = self.game.font_small
            self.font_sym_large = self.game.font_sym_large
            self.font_sym_med = self.game.font_sym_med
            self.font_sym_small = self.game.font_sym_small
        else:
            pygame.font.init()
            self.font_title = pygame.font.SysFont("arial", 30, bold=True)
            self.font_large = pygame.font.SysFont("arial", 20, bold=True)
            self.font_med = pygame.font.SysFont("arial", 15, bold=True)
            self.font_small = pygame.font.SysFont("arial", 12)
            self.font_sym_large = pygame.font.SysFont("segoe ui symbol", 24, bold=True)
            self.font_sym_med = pygame.font.SysFont("segoe ui symbol", 18, bold=True)
            self.font_sym_small = pygame.font.SysFont("segoe ui symbol", 14)

    def snap_coord(self, val, center, step):
        """Snaps coordinate to closest grid line relative to center."""
        rel = val - center
        snapped_rel = round(rel / step) * step
        return center + snapped_rel

    def move_pen(self, dx_steps, dy_steps):
        """Moves pen by step count in grid units. If pen is down, draws a vector."""
        if not self.raw_points:
            # First position is recorded
            cur_p = (self.pen_pos[0], self.pen_pos[1])
            if self.snap_to_grid:
                cur_p = (
                    self.snap_coord(cur_p[0], self.canvas_cx, self.grid_step),
                    self.snap_coord(cur_p[1], self.canvas_cy, self.grid_step),
                )
            self.pen_pos = list(cur_p)
            if self.pen_down:
                self.undo_stack.append(list(self.raw_points))
                self.raw_points.append(cur_p)

        new_x = self.pen_pos[0] + dx_steps * self.grid_step
        new_y = self.pen_pos[1] + dy_steps * self.grid_step

        # Clamp to canvas margins
        pad = 20
        new_x = max(self.canvas_rect.left + pad, min(self.canvas_rect.right - pad, new_x))
        new_y = max(self.canvas_rect.top + pad, min(self.canvas_rect.bottom - pad, new_y))

        if self.snap_to_grid:
            new_x = self.snap_coord(new_x, self.canvas_cx, self.grid_step)
            new_y = self.snap_coord(new_y, self.canvas_cy, self.grid_step)

        self.pen_pos = [new_x, new_y]

        if self.pen_down:
            target_pt = (new_x, new_y)
            if not self.raw_points or self.raw_points[-1] != target_pt:
                self.undo_stack.append(list(self.raw_points))
                self.raw_points.append(target_pt)
                self.auto_smooth_and_tidy(silent=True)
                if self.game and hasattr(self.game, 'sfx'):
                    self.game.sfx.play("dash")

    def toggle_pen(self):
        """Toggles Pen Down (drawing) vs Pen Up (navigation)."""
        self.pen_down = not self.pen_down
        if self.pen_down:
            p = (self.pen_pos[0], self.pen_pos[1])
            if self.snap_to_grid:
                p = (
                    self.snap_coord(p[0], self.canvas_cx, self.grid_step),
                    self.snap_coord(p[1], self.canvas_cy, self.grid_step),
                )
            if not self.raw_points:
                self.raw_points.append(p)
            self.set_feedback("ПЕРО ОПУЩЕНО: Рисуем стрелочками ↑↓←→!", TEXT_GOLD)
        else:
            self.set_feedback("ПЕРО ПОДНЯТО: Перемещение без черчения.", TEXT_CYAN)

        if self.game and hasattr(self.game, 'sfx'):
            self.game.sfx.play("parry")

    def undo(self):
        """Reverts the last drawn segment."""
        if self.undo_stack:
            self.raw_points = self.undo_stack.pop()
            if self.raw_points:
                self.pen_pos = list(self.raw_points[-1])
            self.auto_smooth_and_tidy(silent=True)
            self.set_feedback("Шаг отменен [Z]", (220, 220, 220))
        elif self.raw_points:
            self.raw_points.pop()
            if self.raw_points:
                self.pen_pos = list(self.raw_points[-1])
            self.auto_smooth_and_tidy(silent=True)
            self.set_feedback("Точка удалена", (220, 220, 220))

    def clear(self):
        """Clears drawing canvas."""
        self.undo_stack.append(list(self.raw_points))
        self.raw_points.clear()
        self.smoothed_points.clear()
        self.normalized_64.clear()
        self.similarity_matches.clear()
        self.pen_pos = [self.canvas_cx, self.canvas_cy]
        self.set_feedback("Холст очищен. Начни чертить заново!", TEXT_CYAN)

    def close_contour(self):
        """Connects last point directly to first point."""
        if len(self.raw_points) >= 3:
            self.undo_stack.append(list(self.raw_points))
            self.raw_points.append(self.raw_points[0])
            self.is_closed = True
            self.pen_pos = list(self.raw_points[0])
            self.auto_smooth_and_tidy(silent=False)
            self.set_feedback("Контур замкнут!", TEXT_GOLD)
            if self.game and hasattr(self.game, 'sfx'):
                self.game.sfx.play("crit")

    def apply_symmetry(self):
        """Mirrors stroke across canvas vertical Y-axis."""
        if len(self.raw_points) < 2:
            return
        self.undo_stack.append(list(self.raw_points))
        mirrored = []
        for x, y in reversed(self.raw_points):
            dx = x - self.canvas_cx
            mirrored.append((self.canvas_cx - dx, y))
        self.raw_points.extend(mirrored)
        self.auto_smooth_and_tidy(silent=False)
        self.set_feedback("Применена двусторонняя симметрия!", TEXT_GOLD)

    def auto_smooth_and_tidy(self, silent=False):
        """Executes the Auto-Smoothing & Tidying Engine."""
        if len(self.raw_points) < 2:
            self.smoothed_points = list(self.raw_points)
            self.normalized_64 = []
            return

        sm_pts, norm_64 = tidy_and_smooth_stroke(
            self.raw_points,
            is_closed=self.is_closed,
            snap_angles=self.snap_angles,
            smooth_curves=self.smooth_curves,
        )
        self.smoothed_points = sm_pts
        self.normalized_64 = norm_64

        # Run similarity check against Wild Magic patterns
        self.evaluate_similarity()

        if not silent:
            self.set_feedback(f"★ Знак сглажен и выровнен! (64 точки, {len(sm_pts)} вертексов)", TEXT_GOLD)
            if self.game and hasattr(self.game, 'sfx'):
                self.game.sfx.play("crit")

    def evaluate_similarity(self):
        """Compares current normalized glyph against all existing Wild Magic patterns."""
        if not self.normalized_64:
            self.similarity_matches = []
            return

        matches = []
        for pat_id, pat in wild_magic.WILD_MAGIC_PATTERNS.items():
            t_pts = pat.get("resampled")
            if not t_pts:
                continue
            is_cl = pat.get("is_closed", False)
            d = wild_magic.best_template_distance(self.normalized_64, t_pts, is_closed=is_cl)
            pct = max(0, min(100, int((1.0 - (d / 68.0)) * 100)))
            matches.append({
                "id": pat_id,
                "name": pat.get("name", pat_id),
                "symbol": pat.get("symbol", "✦"),
                "distance": d,
                "percent": pct,
                "color": pat.get("color", (255, 255, 255))
            })

        matches.sort(key=lambda m: m["distance"])
        self.similarity_matches = matches[:3]

    def set_feedback(self, msg, color=TEXT_GOLD):
        self.feedback_text = msg
        self.feedback_color = color
        self.feedback_timer = 4.0

    def load_preset(self, pattern_id):
        """Loads an existing Wild Magic glyph as an editable template."""
        pat = wild_magic.WILD_MAGIC_PATTERNS.get(pattern_id)
        if not pat:
            return

        self.undo_stack.append(list(self.raw_points))
        self.glyph_id = pat["id"]
        self.glyph_name = pat.get("name", pat["id"])
        self.glyph_symbol = pat.get("symbol", "✦")
        self.glyph_duration = pat.get("duration", 20.0)
        self.glyph_color = pat.get("color", (120, 240, 255))
        self.glyph_desc = pat.get("desc", "Священный знак.")
        self.is_closed = pat.get("is_closed", False)

        # Scale raw verts to canvas screen coordinates
        raw_verts = pat.get("raw_verts", [])
        if raw_verts:
            sc_pts = []
            scale = 4.4
            for rx, ry in raw_verts:
                sx = self.canvas_cx + (rx - 50.0) * scale
                sy = self.canvas_cy + (ry - 50.0) * scale
                sc_pts.append((sx, sy))
            self.raw_points = sc_pts
        else:
            # Fallback to resampled
            scale = 4.4
            self.raw_points = [
                (self.canvas_cx + p.x * (scale * 0.9), self.canvas_cy + p.y * (scale * 0.9))
                for p in pat["resampled"]
            ]

        if self.raw_points:
            self.pen_pos = list(self.raw_points[-1])

        self.auto_smooth_and_tidy(silent=False)
        self.set_feedback(f"Загружен пресет «{self.glyph_name}»!", TEXT_GOLD)

    def save_to_game(self):
        """Saves current smoothed glyph into custom_wild_glyphs.json and registers dynamically."""
        if len(self.normalized_64) < 16:
            self.set_feedback("Сначала нарисуйте и сгладьте знак [S]!", TEXT_RED)
            return

        # Prepare dictionary
        glyph_data = {
            "id": self.glyph_id.strip().upper().replace(" ", "_"),
            "name": self.glyph_name.strip(),
            "symbol": self.glyph_symbol.strip(),
            "color": list(self.glyph_color),
            "desc": self.glyph_desc.strip(),
            "duration": float(self.glyph_duration),
            "boss_req": int(self.boss_req),
            "is_closed": bool(self.is_closed),
            "raw_verts": [[round(x, 1), round(y, 1)] for x, y in self.raw_points],
            "resampled_coords": [[round(p.x, 2), round(p.y, 2)] for p in self.normalized_64]
        }

        # Load existing file
        existing = {}
        if os.path.exists(CUSTOM_GLYPHS_FILE):
            try:
                with open(CUSTOM_GLYPHS_FILE, "r", encoding="utf-8") as f:
                    existing = json.load(f)
            except Exception:
                existing = {}

        existing[glyph_data["id"]] = glyph_data

        try:
            with open(CUSTOM_GLYPHS_FILE, "w", encoding="utf-8") as f:
                json.dump(existing, f, ensure_ascii=False, indent=2)
        except Exception as e:
            self.set_feedback(f"Ошибка сохранения: {e}", TEXT_RED)
            return

        # Register dynamically into wild_magic
        pts_obj = [Point(c[0], c[1]) for c in glyph_data["resampled_coords"]]
        wild_magic.WILD_MAGIC_PATTERNS[glyph_data["id"]] = {
            "id": glyph_data["id"],
            "name": glyph_data["name"],
            "symbol": glyph_data["symbol"],
            "color": tuple(glyph_data["color"]),
            "desc": glyph_data["desc"],
            "is_closed": glyph_data["is_closed"],
            "duration": glyph_data["duration"],
            "boss_req": glyph_data["boss_req"],
            "resampled": pts_obj,
            "raw_verts": glyph_data["raw_verts"]
        }

        if self.game and hasattr(self.game, 'unlocked_wild_magic_glyphs'):
            self.game.unlocked_wild_magic_glyphs.add(glyph_data["id"])

        self.set_feedback(f"★ ЗНАК «{glyph_data['name']}» СОХРАНЕН В ИГРУ! ★", TEXT_GOLD)
        if self.game and hasattr(self.game, 'sfx'):
            self.game.sfx.play("crit")

    def export_python_snippet(self):
        """Generates ready-to-paste Python dictionary code and copies to clipboard."""
        if len(self.normalized_64) < 16:
            self.set_feedback("Сначала сгладьте знак [S]!", TEXT_RED)
            return

        gid = self.glyph_id.strip().upper().replace(" ", "_")
        code = f'''    # {gid} (Wild Magic Sacred Sign) - {self.glyph_duration:.1f}s
    patterns["{gid}"] = {{
        "id": "{gid}",
        "name": "{self.glyph_name}",
        "symbol": "{self.glyph_symbol}",
        "color": {tuple(self.glyph_color)},
        "desc": "{self.glyph_desc}",
        "is_closed": {self.is_closed},
        "duration": {self.glyph_duration:.1f},
        "boss_req": {self.boss_req},
        "resampled": [
'''
        for p in self.normalized_64:
            code += f'            Point({p.x:.2f}, {p.y:.2f}),\n'
        code += f'''        ],
        "raw_verts": {self.raw_points[:12]}
    }}
'''
        safe_set_clipboard_text(code)
        try:
            with open("exported_glyph.py", "w", encoding="utf-8") as f:
                f.write(code)
        except Exception:
            pass

        self.set_feedback("★ Python код скопирован в буфер и exported_glyph.py!", TEXT_GOLD)
        if self.game and hasattr(self.game, 'sfx'):
            self.game.sfx.play("crit")

    def load_custom_glyphs_from_disk(self):
        """Loads custom glyphs from JSON file into wild_magic registry."""
        if not os.path.exists(CUSTOM_GLYPHS_FILE):
            return
        try:
            with open(CUSTOM_GLYPHS_FILE, "r", encoding="utf-8") as f:
                data = json.load(f)
            for gid, item in data.items():
                pts_obj = [Point(c[0], c[1]) for c in item["resampled_coords"]]
                wild_magic.WILD_MAGIC_PATTERNS[gid] = {
                    "id": gid,
                    "name": item.get("name", gid),
                    "symbol": item.get("symbol", "✦"),
                    "color": tuple(item.get("color", (120, 240, 255))),
                    "desc": item.get("desc", ""),
                    "is_closed": item.get("is_closed", False),
                    "duration": item.get("duration", 20.0),
                    "boss_req": item.get("boss_req", 0),
                    "resampled": pts_obj,
                    "raw_verts": item.get("raw_verts", [])
                }
                if self.game and hasattr(self.game, 'unlocked_wild_magic_glyphs'):
                    self.game.unlocked_wild_magic_glyphs.add(gid)
        except Exception as e:
            print(f"[DevGlyphStudio] Error loading custom glyphs: {e}")

    # -------------------------------------------------------------------------
    # TEST TRACING ARENA
    # -------------------------------------------------------------------------
    def start_test_ritual(self):
        """Enters test tracing mode for realistic muscle-memory verification."""
        if len(self.normalized_64) < 16:
            self.set_feedback("Сначала начертите и сгладьте форму знака [S]!", TEXT_RED)
            return
        self.testing_ritual = True
        self.test_drawn_points = []
        self.test_timer = self.glyph_duration
        self.test_max_timer = self.glyph_duration
        self.test_score = 0.0
        self.test_completed = False
        self.set_feedback("ТЕСТ РИТУАЛА: Проведите мышь или чертите стрелками точно по контуру!", TEXT_GOLD)
        if self.game and hasattr(self.game, 'sfx'):
            self.game.sfx.play("parry")

    def evaluate_test_ritual(self):
        """Evaluates live ritual test tracing."""
        if len(self.test_drawn_points) < 12:
            self.test_score = 0.0
            self.test_completed = True
            self.set_feedback("Тест завершен: Слишком короткий росчерк (0% точности)", TEXT_RED)
            return

        u_res = resample([Point(x, y) for x, y in self.test_drawn_points], 64)
        u_norm = scale_and_center(u_res, 100.0)
        d = wild_magic.best_template_distance(u_norm, self.normalized_64, is_closed=self.is_closed)
        acc = max(0.0, min(1.0, 1.0 - (d / 68.0)))
        pct = int(acc * 100)
        self.test_score = pct
        self.test_completed = True

        if pct >= 80:
            self.set_feedback(f"★ ВЕЛИКИЙ УСПЕХ: Точность {pct}%! Знак легко читается!", TEXT_GOLD)
            if self.game and hasattr(self.game, 'sfx'):
                self.game.sfx.play("crit")
        elif pct >= 60:
            self.set_feedback(f"УСПЕХ: Точность {pct}%. Приемлемый результат.", TEXT_CYAN)
            if self.game and hasattr(self.game, 'sfx'):
                self.game.sfx.play("parry")
        else:
            self.set_feedback(f"Провал теста: Точность {pct}%. Попробуйте сгладить или выровнять.", TEXT_RED)

    # -------------------------------------------------------------------------
    # INPUT & EVENT HANDLING
    # -------------------------------------------------------------------------
    def handle_event(self, event):
        """Handles Pygame input events."""
        m_pos = getattr(event, 'pos', pygame.mouse.get_pos())

        # Keyboard Navigation
        if event.type == pygame.KEYDOWN:
            # Global Hotkey for Fullscreen Toggle: F11 or Alt+Enter
            if event.key == pygame.K_F11 or (event.key == pygame.K_RETURN and ((pygame.key.get_mods() | getattr(event, 'mod', 0)) & pygame.KMOD_ALT)):
                if self.game and hasattr(self.game, 'toggle_fullscreen'):
                    self.game.toggle_fullscreen()
                return

            # Global Hotkey for Resolution Cycle: F10
            if event.key == pygame.K_F10:
                if self.game and hasattr(self.game, 'cycle_resolution'):
                    self.game.cycle_resolution()
                return

            # Active Text Input Editing
            if self.active_input_field:
                if event.key == pygame.K_RETURN or event.key == pygame.K_ESCAPE:
                    self.active_input_field = None
                elif event.key == pygame.K_BACKSPACE:
                    if self.active_input_field == "ID":
                        self.glyph_id = self.glyph_id[:-1]
                    elif self.active_input_field == "NAME":
                        self.glyph_name = self.glyph_name[:-1]
                    elif self.active_input_field == "DESC":
                        self.glyph_desc = self.glyph_desc[:-1]
                elif event.key == pygame.K_v and (pygame.key.get_mods() & pygame.KMOD_CTRL):
                    clip = safe_get_clipboard_text()
                    if clip:
                        if self.active_input_field == "ID":
                            self.glyph_id += clip.upper().replace(" ", "_")[:24]
                        elif self.active_input_field == "NAME":
                            self.glyph_name += clip[:36]
                        elif self.active_input_field == "DESC":
                            self.glyph_desc += clip[:80]
                else:
                    char = event.unicode
                    if char and char.isprintable():
                        if self.active_input_field == "ID" and len(self.glyph_id) < 24:
                            self.glyph_id += char.upper().replace(" ", "_")
                        elif self.active_input_field == "NAME" and len(self.glyph_name) < 36:
                            self.glyph_name += char
                        elif self.active_input_field == "DESC" and len(self.glyph_desc) < 80:
                            self.glyph_desc += char
                return

            # Test Tracing Active Controls
            if self.testing_ritual:
                if event.key == pygame.K_ESCAPE or event.key == pygame.K_t:
                    self.testing_ritual = False
                    self.set_feedback("Тест ритуала остановлен.", TEXT_CYAN)
                elif event.key == pygame.K_RETURN or event.key == pygame.K_SPACE:
                    self.evaluate_test_ritual()
                elif event.key == pygame.K_UP:
                    self.move_pen(0, -1)
                    self.test_drawn_points.append(tuple(self.pen_pos))
                elif event.key == pygame.K_DOWN:
                    self.move_pen(0, 1)
                    self.test_drawn_points.append(tuple(self.pen_pos))
                elif event.key == pygame.K_LEFT:
                    self.move_pen(-1, 0)
                    self.test_drawn_points.append(tuple(self.pen_pos))
                elif event.key == pygame.K_RIGHT:
                    self.move_pen(1, 0)
                    self.test_drawn_points.append(tuple(self.pen_pos))
                return

            # ARROW KEYS DRAWING MECHANISM
            if event.key == pygame.K_UP:
                self.move_pen(0, -1)
            elif event.key == pygame.K_DOWN:
                self.move_pen(0, 1)
            elif event.key == pygame.K_LEFT:
                self.move_pen(-1, 0)
            elif event.key == pygame.K_RIGHT:
                self.move_pen(1, 0)
            # Diagonals
            elif event.key == pygame.K_PAGEUP:
                self.move_pen(1, -1)
            elif event.key == pygame.K_PAGEDOWN:
                self.move_pen(1, 1)
            elif event.key == pygame.K_HOME:
                self.move_pen(-1, -1)
            elif event.key == pygame.K_END:
                self.move_pen(-1, 1)

            # PEN TOGGLE [SPACE]
            elif event.key == pygame.K_SPACE:
                self.toggle_pen()

            # AUTO-SMOOTH & TIDY [S] or [RETURN]
            elif event.key in (pygame.K_s, pygame.K_RETURN):
                self.auto_smooth_and_tidy(silent=False)

            # UNDO [Z]
            elif event.key == pygame.K_z:
                self.undo()

            # CLEAR [C] or [DELETE]
            elif event.key in (pygame.K_c, pygame.K_DELETE):
                self.clear()

            # CLOSE CONTOUR [K]
            elif event.key == pygame.K_k:
                self.close_contour()

            # SYMMETRY [M]
            elif event.key == pygame.K_m:
                self.apply_symmetry()

            # TEST RITUAL [T]
            elif event.key == pygame.K_t:
                self.start_test_ritual()

            # STEP SIZE CYCLING [1, 2, 3, 4]
            elif event.key == pygame.K_1:
                self.grid_step = 5
                self.set_feedback("Шаг сетки: 5px (Тонкая детализация)", TEXT_CYAN)
            elif event.key == pygame.K_2:
                self.grid_step = 10
                self.set_feedback("Шаг сетки: 10px (Средняя)", TEXT_CYAN)
            elif event.key == pygame.K_3:
                self.grid_step = 20
                self.set_feedback("Шаг сетки: 20px (Стандартная)", TEXT_GOLD)
            elif event.key == pygame.K_4:
                self.grid_step = 40
                self.set_feedback("Шаг сетки: 40px (Широкие векторы)", TEXT_CYAN)

            # SAVE SHORTCUT [Ctrl+S]
            elif event.key == pygame.K_s and (pygame.key.get_mods() & pygame.KMOD_CTRL):
                self.save_to_game()

            # EXIT [ESC]
            elif event.key == pygame.K_ESCAPE:
                if self.game:
                    self.game.state = 'MAIN_MENU'
                    if hasattr(self.game, 'sfx'):
                        self.game.sfx.play("dash")

        # Mouse Drawing in Canvas
        elif event.type == pygame.MOUSEBUTTONDOWN:
            if self.canvas_rect.collidepoint(m_pos):
                if self.testing_ritual:
                    self.test_drawn_points = [m_pos]
                else:
                    self.mouse_drawing = True
                    self.undo_stack.append(list(self.raw_points))
                    pt = m_pos
                    if self.snap_to_grid:
                        pt = (
                            self.snap_coord(pt[0], self.canvas_cx, self.grid_step),
                            self.snap_coord(pt[1], self.canvas_cy, self.grid_step),
                        )
                    self.pen_pos = list(pt)
                    self.raw_points.append(pt)
            else:
                self._handle_ui_clicks(m_pos)

        elif event.type == pygame.MOUSEBUTTONUP:
            if self.mouse_drawing:
                self.mouse_drawing = False
                self.auto_smooth_and_tidy(silent=True)
            if self.testing_ritual and len(self.test_drawn_points) > 5:
                self.evaluate_test_ritual()

        elif event.type == pygame.MOUSEMOTION:
            if self.mouse_drawing and self.canvas_rect.collidepoint(m_pos):
                pt = m_pos
                if self.snap_to_grid:
                    pt = (
                        self.snap_coord(pt[0], self.canvas_cx, self.grid_step),
                        self.snap_coord(pt[1], self.canvas_cy, self.grid_step),
                    )
                if not self.raw_points or self.raw_points[-1] != pt:
                    self.pen_pos = list(pt)
                    self.raw_points.append(pt)
            elif self.testing_ritual and pygame.mouse.get_pressed()[0] and self.canvas_rect.collidepoint(m_pos):
                self.test_drawn_points.append(m_pos)

    def _handle_ui_clicks(self, pos):
        """Handles button clicks outside the main drawing canvas."""
        x, y = pos

        # 1. Header Buttons
        sw = self.game.screen.get_width() if (self.game and hasattr(self.game, 'screen') and self.game.screen) else VIEW_WIDTH
        close_rect = self.ui_rects.get("close", pygame.Rect(sw - 150, 15, 130, 36))
        fs_rect = self.ui_rects.get("fullscreen", pygame.Rect(sw - 535, 15, 160, 36))
        res_rect = self.ui_rects.get("resolution", pygame.Rect(sw - 710, 15, 165, 36))

        if close_rect.collidepoint(pos):
            if self.game:
                self.game.state = 'MAIN_MENU'
                if hasattr(self.game, 'sfx'):
                    self.game.sfx.play("dash")
            return

        if fs_rect.collidepoint(pos):
            if self.game and hasattr(self.game, 'toggle_fullscreen'):
                self.game.toggle_fullscreen()
            return

        if res_rect.collidepoint(pos):
            if self.game and hasattr(self.game, 'cycle_resolution'):
                self.game.cycle_resolution()
            return

        # 2. Left Panel Buttons
        if self.ui_rects.get("pen") and self.ui_rects["pen"].collidepoint(pos):
            self.toggle_pen()
            return

        if self.ui_rects.get("smooth") and self.ui_rects["smooth"].collidepoint(pos):
            self.auto_smooth_and_tidy(silent=False)
            return

        if self.ui_rects.get("loop") and self.ui_rects["loop"].collidepoint(pos):
            self.close_contour()
            return

        if self.ui_rects.get("undo") and self.ui_rects["undo"].collidepoint(pos):
            self.undo()
            return

        if self.ui_rects.get("clear") and self.ui_rects["clear"].collidepoint(pos):
            self.clear()
            return

        if self.ui_rects.get("mirror") and self.ui_rects["mirror"].collidepoint(pos):
            self.apply_symmetry()
            return

        if self.ui_rects.get("snap") and self.ui_rects["snap"].collidepoint(pos):
            self.snap_to_grid = not self.snap_to_grid
            st = "ВКЛ" if self.snap_to_grid else "ВЫКЛ"
            self.set_feedback(f"Привязка к сетке: {st}", TEXT_CYAN)
            return

        # Grid Step Buttons
        for st in (5, 10, 20, 40):
            k = f"step_{st}"
            if self.ui_rects.get(k) and self.ui_rects[k].collidepoint(pos):
                self.grid_step = st
                self.set_feedback(f"Шаг сетки: {st}px", TEXT_GOLD)
                return

        # Preset Buttons
        preset_ids = [
            "CRESCENT_BLADE",
            "TRIANGLE_APEX",
            "CHRONO_HOURGLASS_KNOT",
            "OCULUS_VOID",
            "COSMIC_PENTACLE_SUPREME",
        ]
        for pid in preset_ids:
            k = f"preset_{pid}"
            if self.ui_rects.get(k) and self.ui_rects[k].collidepoint(pos):
                self.load_preset(pid)
                return

        # 3. Right Panel Fields & Actions
        if self.ui_rects.get("id_box") and self.ui_rects["id_box"].collidepoint(pos):
            self.active_input_field = "ID"
            return

        if self.ui_rects.get("name_box") and self.ui_rects["name_box"].collidepoint(pos):
            self.active_input_field = "NAME"
            return

        symbols = ["✦", "🌙", "⌛", "⚔", "☠", "△", "💠", "⚜"]
        for sym in symbols:
            k = f"sym_{sym}"
            if self.ui_rects.get(k) and self.ui_rects[k].collidepoint(pos):
                self.glyph_symbol = sym
                self.set_feedback(f"Символ изменен: {sym}", TEXT_GOLD)
                return

        if self.ui_rects.get("dur_minus") and self.ui_rects["dur_minus"].collidepoint(pos):
            self.glyph_duration = max(15.0, self.glyph_duration - 1.0)
            return

        if self.ui_rects.get("dur_plus") and self.ui_rects["dur_plus"].collidepoint(pos):
            self.glyph_duration = min(30.0, self.glyph_duration + 1.0)
            return

        if self.ui_rects.get("test_ritual") and self.ui_rects["test_ritual"].collidepoint(pos):
            self.start_test_ritual()
            return

        if self.ui_rects.get("save_to_game") and self.ui_rects["save_to_game"].collidepoint(pos):
            self.save_to_game()
            return

        if self.ui_rects.get("copy_python") and self.ui_rects["copy_python"].collidepoint(pos):
            self.export_python_snippet()
            return

    # -------------------------------------------------------------------------
    # UPDATE & ANIMATION
    # -------------------------------------------------------------------------
    def update(self, dt):
        """Updates internal studio timers and animations."""
        self.cursor_blink_time += dt
        if self.feedback_timer > 0:
            self.feedback_timer -= dt

        if self.testing_ritual and not self.test_completed:
            self.test_timer -= dt
            if self.test_timer <= 0:
                self.test_timer = 0.0
                self.evaluate_test_ritual()

    # -------------------------------------------------------------------------
    # RENDERING
    # -------------------------------------------------------------------------
    def render(self, surface):
        """Renders the comprehensive Developer Glyph Studio UI."""
        w, h = surface.get_width(), surface.get_height()
        m_pos = pygame.mouse.get_pos()

        # Background Cyber-Slate Fill
        surface.fill((12, 15, 22))

        # Ambient Glow Grid Lines in Background
        for gy in range(0, h, 80):
            pygame.draw.line(surface, (18, 22, 34), (0, gy), (w, gy), 1)

        # 1. Header Banner
        self._render_header(surface)

        # 2. Main Precision Drawing Canvas
        self._render_canvas(surface)

        # 3. Left Tool Palette & Presets
        self._render_left_panel(surface, m_pos)

        # 4. Right Metadata & Analysis Panel
        self._render_right_panel(surface, m_pos)

        # 5. Bottom Status & Key Hints
        self._render_footer(surface)

        # 6. Test Tracing Overlay if active
        if self.testing_ritual:
            self._render_test_ritual_overlay(surface)

    def _render_header(self, surface):
        sw = surface.get_width()

        # Header Box
        pygame.draw.rect(surface, (16, 20, 30), (0, 0, sw, 65))
        pygame.draw.line(surface, (40, 60, 95), (0, 65), (sw, 65), 2)

        star = self.font_sym_large.render("★ ", True, TEXT_GOLD)
        title = self.font_large.render("СТУДИЯ ДИКИХ ЗНАКОВ [DEV]", True, TEXT_GOLD)
        surface.blit(star, (30, 16))
        surface.blit(title, (30 + star.get_width(), 16))

        sub = self.font_small.render(
            "Векторное черчение стрелочками ↑↓←→ • Авто-сглаживание • Интеграция в игру",
            True, (140, 180, 220)
        )
        surface.blit(sub, (32, 42))

        # Resolution Cycle Button in Header
        res_btn = pygame.Rect(sw - 710, 15, 165, 36)
        self.ui_rects["resolution"] = res_btn
        cur_res = getattr(self.game, 'resolution_key', 'FHD') if self.game else 'FHD'
        res_hov = res_btn.collidepoint(pygame.mouse.get_pos())
        res_bg = (38, 36, 60) if res_hov else (20, 20, 36)
        res_bdr = (255, 215, 80) if res_hov else (90, 80, 130)
        pygame.draw.rect(surface, res_bg, res_btn, border_radius=6)
        pygame.draw.rect(surface, res_bdr, res_btn, 1, border_radius=6)
        res_lbl = self.font_small.render(f"[F10] {cur_res} (1080p/2K)", True, (255, 220, 90))
        surface.blit(res_lbl, (res_btn.centerx - res_lbl.get_width() // 2, res_btn.centery - res_lbl.get_height() // 2))

        # Fullscreen Toggle Button in Header
        fs_btn = pygame.Rect(sw - 535, 15, 160, 36)
        self.ui_rects["fullscreen"] = fs_btn
        is_fs = getattr(self.game, 'is_fullscreen', False) if self.game else False
        fs_hov = fs_btn.collidepoint(pygame.mouse.get_pos())
        fs_bg = (30, 44, 62) if fs_hov else (18, 26, 38)
        fs_bdr = (100, 200, 255) if is_fs else ((80, 130, 180) if fs_hov else (45, 75, 110))
        pygame.draw.rect(surface, fs_bg, fs_btn, border_radius=6)
        pygame.draw.rect(surface, fs_bdr, fs_btn, 1, border_radius=6)
        fs_txt = "[F11] ПОЛНЫЙ" if is_fs else "[F11] ОКОННЫЙ"
        fs_col = (120, 230, 255) if is_fs else (180, 205, 230)
        fs_lbl = self.font_small.render(fs_txt, True, fs_col)
        surface.blit(fs_lbl, (fs_btn.centerx - fs_lbl.get_width() // 2, fs_btn.centery - fs_lbl.get_height() // 2))

        # Dev Badge
        badge_rect = pygame.Rect(sw - 360, 15, 195, 36)
        pygame.draw.rect(surface, (20, 38, 30), badge_rect, border_radius=6)
        pygame.draw.rect(surface, (60, 220, 120), badge_rect, 1, border_radius=6)
        b_txt = self.font_med.render("● ДОСТУП РАЗРЕШЁН", True, (80, 240, 140))
        surface.blit(b_txt, (badge_rect.centerx - b_txt.get_width() // 2, badge_rect.centery - b_txt.get_height() // 2))

        # Close / Exit Button
        close_btn = pygame.Rect(sw - 150, 15, 130, 36)
        self.ui_rects["close"] = close_btn
        c_hov = close_btn.collidepoint(pygame.mouse.get_pos())
        c_bg = (55, 25, 25) if c_hov else (38, 18, 22)
        pygame.draw.rect(surface, c_bg, close_btn, border_radius=6)
        pygame.draw.rect(surface, (220, 70, 70), close_btn, 1, border_radius=6)
        c_txt = self.font_med.render("[ESC] ВЫХОД", True, (255, 120, 120))
        surface.blit(c_txt, (close_btn.centerx - c_txt.get_width() // 2, close_btn.centery - c_txt.get_height() // 2))

    def _render_canvas(self, surface):
        cr = self.canvas_rect
        cx, cy = self.canvas_cx, self.canvas_cy

        # Canvas Outer Frame & Glass Shadow
        pygame.draw.rect(surface, (14, 18, 28), cr, border_radius=8)
        pygame.draw.rect(surface, (30, 48, 75), cr, 2, border_radius=8)

        # Coordinate Grid Dots / Lines
        step = self.grid_step
        grid_col = (24, 32, 48)
        grid_dot_col = (38, 52, 78)

        # Draw Grid Lines
        for gx in range(cx % step, cr.right, step):
            if gx >= cr.left:
                pygame.draw.line(surface, grid_col, (gx, cr.top + 2), (gx, cr.bottom - 2), 1)
        for gy in range(cy % step, cr.bottom, step):
            if gy >= cr.top:
                pygame.draw.line(surface, grid_col, (cr.left + 2, gy), (cr.right - 2, gy), 1)

        # Normalized [-50, 50] Area Boundary Box (440x440)
        norm_box = pygame.Rect(cx - 220, cy - 220, 440, 440)
        pygame.draw.rect(surface, (45, 65, 100), norm_box, 1)
        lbl_box = self.font_small.render("Область распознавания [-50, 50]", True, (70, 95, 140))
        surface.blit(lbl_box, (norm_box.left + 8, norm_box.top + 6))

        # Main Axes (X=0, Y=0)
        pygame.draw.line(surface, (50, 90, 140), (cx, cr.top + 2), (cx, cr.bottom - 2), 2)
        pygame.draw.line(surface, (50, 90, 140), (cr.left + 2, cy), (cr.right - 2, cy), 2)
        pygame.draw.circle(surface, TEXT_GOLD, (cx, cy), 3)

        # 1. Render Raw Points if available
        if len(self.raw_points) >= 2:
            pygame.draw.lines(surface, (60, 90, 120), False, self.raw_points, 1)
            for pt in self.raw_points:
                pygame.draw.circle(surface, (120, 150, 180), (int(pt[0]), int(pt[1])), 3)

        # 2. Render Smoothed / Tidied Vector Stroke
        pts_to_draw = self.smoothed_points if self.smoothed_points else self.raw_points
        if len(pts_to_draw) >= 2:
            # Neon Outer Glow
            pygame.draw.lines(surface, (20, 80, 140), False, pts_to_draw, 9)
            # Vivid Core
            pygame.draw.lines(surface, (80, 220, 255), False, pts_to_draw, 4)
            # Pure White Centerline
            pygame.draw.lines(surface, (240, 255, 255), False, pts_to_draw, 1)

            # Draw directional flow arrows along segments
            seg_count = min(8, len(pts_to_draw) - 1)
            step_idx = max(1, (len(pts_to_draw) - 1) // max(1, seg_count))
            for i in range(0, len(pts_to_draw) - 1, step_idx):
                p1 = pts_to_draw[i]
                p2 = pts_to_draw[i + 1]
                mx = (p1[0] + p2[0]) / 2.0
                my = (p1[1] + p2[1]) / 2.0
                ang = math.atan2(p2[1] - p1[1], p2[0] - p1[0])
                # Small directional tick
                alen = 7
                ax1 = mx - alen * math.cos(ang - 0.5)
                ay1 = my - alen * math.sin(ang - 0.5)
                ax2 = mx - alen * math.cos(ang + 0.5)
                ay2 = my - alen * math.sin(ang + 0.5)
                pygame.draw.polygon(surface, TEXT_GOLD, [(int(mx), int(my)), (int(ax1), int(ay1)), (int(ax2), int(ay2))])

            # Start and End points
            start_p = pts_to_draw[0]
            end_p = pts_to_draw[-1]
            pygame.draw.circle(surface, (80, 255, 120), (int(start_p[0]), int(start_p[1])), 6)
            pygame.draw.circle(surface, (255, 90, 90), (int(end_p[0]), int(end_p[1])), 6)

        # 3. Virtual Pen Cursor (Reticle & Coordinate Tag)
        px, py = int(self.pen_pos[0]), int(self.pen_pos[1])
        pen_col = TEXT_GOLD if self.pen_down else (80, 220, 255)
        # Pulsing ring
        pulse = 2.0 * math.sin(self.cursor_blink_time * 6.0)
        rad = int(8 + pulse)
        pygame.draw.circle(surface, pen_col, (px, py), rad, 2)
        pygame.draw.circle(surface, pen_col, (px, py), 3)
        # Crosshair lines
        pygame.draw.line(surface, pen_col, (px - 14, py), (px - 5, py), 2)
        pygame.draw.line(surface, pen_col, (px + 5, py), (px + 14, py), 2)
        pygame.draw.line(surface, pen_col, (px, py - 14), (px, py - 5), 2)
        pygame.draw.line(surface, pen_col, (px, py + 5), (px, py + 14), 2)

        # Readout at canvas bottom
        rel_x = px - cx
        rel_y = py - cy
        mode_str = "ПЕРО: ОПУЩЕНО [ЧЕРЧЕНИЕ]" if self.pen_down else "ПЕРО: ПОДНЯТО [НАВИГАЦИЯ]"
        c_info = self.font_small.render(
            f"Координаты: X:{rel_x:+d}, Y:{rel_y:+d} | Точек: {len(self.raw_points)} | {mode_str} | Шаг: {self.grid_step}px",
            True, (160, 195, 230)
        )
        surface.blit(c_info, (cr.left + 12, cr.bottom - 24))

    def _render_left_panel(self, surface, m_pos):
        # Tools Card
        card_l = pygame.Rect(20, 72, 260, 550)
        pygame.draw.rect(surface, (16, 20, 30), card_l, border_radius=8)
        pygame.draw.rect(surface, (32, 45, 68), card_l, 1, border_radius=8)

        t_lbl = self.font_large.render("ИНСТРУМЕНТЫ", True, TEXT_GOLD)
        surface.blit(t_lbl, (card_l.left + 16, card_l.top + 10))

        # 1. Pen Toggle Button
        p_btn = pygame.Rect(30, 108, 240, 34)
        self.ui_rects["pen"] = p_btn
        p_hov = p_btn.collidepoint(m_pos)
        p_bg = (55, 42, 16) if self.pen_down else (20, 35, 52)
        pygame.draw.rect(surface, p_bg, p_btn, border_radius=6)
        p_bd = TEXT_GOLD if self.pen_down else (60, 140, 220)
        pygame.draw.rect(surface, p_bd, p_btn, 1, border_radius=6)
        p_str = "★ [ПРОБЕЛ] ПЕРО: ОПУЩЕНО" if self.pen_down else "○ [ПРОБЕЛ] ПЕРО: ПОДНЯТО"
        p_txt = self.font_med.render(p_str, True, p_bd)
        surface.blit(p_txt, (p_btn.centerx - p_txt.get_width() // 2, p_btn.centery - p_txt.get_height() // 2))

        # 2. Auto-Smooth Button
        s_btn = pygame.Rect(30, 148, 240, 34)
        self.ui_rects["smooth"] = s_btn
        s_hov = s_btn.collidepoint(m_pos)
        s_bg = (24, 48, 70) if s_hov else (18, 34, 50)
        pygame.draw.rect(surface, s_bg, s_btn, border_radius=6)
        pygame.draw.rect(surface, TEXT_CYAN, s_btn, 1, border_radius=6)
        s_txt = self.font_med.render("✦ [S / ENTER] СГЛАДИТЬ", True, TEXT_CYAN)
        surface.blit(s_txt, (s_btn.centerx - s_txt.get_width() // 2, s_btn.centery - s_txt.get_height() // 2))

        # 3. Close Loop Button
        cl_btn = pygame.Rect(30, 188, 240, 30)
        self.ui_rects["loop"] = cl_btn
        cl_hov = cl_btn.collidepoint(m_pos)
        pygame.draw.rect(surface, (22, 30, 44), cl_btn, border_radius=5)
        pygame.draw.rect(surface, (70, 100, 140), cl_btn, 1, border_radius=5)
        cl_txt = self.font_small.render("[K] Замкнуть контур (Loop)", True, TEXT_WHITE)
        surface.blit(cl_txt, (cl_btn.centerx - cl_txt.get_width() // 2, cl_btn.centery - cl_txt.get_height() // 2))

        # 4. Undo and Clear
        u_btn = pygame.Rect(30, 224, 115, 28)
        self.ui_rects["undo"] = u_btn
        pygame.draw.rect(surface, (24, 30, 42), u_btn, border_radius=5)
        pygame.draw.rect(surface, (70, 90, 120), u_btn, 1, border_radius=5)
        u_txt = self.font_small.render("[Z] Отмена", True, TEXT_WHITE)
        surface.blit(u_txt, (u_btn.centerx - u_txt.get_width() // 2, u_btn.centery - u_txt.get_height() // 2))

        c_btn = pygame.Rect(155, 224, 115, 28)
        self.ui_rects["clear"] = c_btn
        pygame.draw.rect(surface, (35, 20, 24), c_btn, border_radius=5)
        pygame.draw.rect(surface, (160, 60, 60), c_btn, 1, border_radius=5)
        c_txt = self.font_small.render("[C] Очистить", True, (255, 140, 140))
        surface.blit(c_txt, (c_btn.centerx - c_txt.get_width() // 2, c_btn.centery - c_txt.get_height() // 2))

        # 5. Symmetry Mirror Button
        m_btn = pygame.Rect(30, 258, 240, 28)
        self.ui_rects["mirror"] = m_btn
        pygame.draw.rect(surface, (22, 32, 46), m_btn, border_radius=5)
        pygame.draw.rect(surface, (80, 120, 170), m_btn, 1, border_radius=5)
        m_txt = self.font_small.render("[M] Осевая симметрия (X-Mirror)", True, (160, 210, 255))
        surface.blit(m_txt, (m_btn.centerx - m_txt.get_width() // 2, m_btn.centery - m_txt.get_height() // 2))

        # 6. Snap to Grid Toggle
        g_btn = pygame.Rect(30, 292, 240, 28)
        self.ui_rects["snap"] = g_btn
        g_col = (60, 220, 120) if self.snap_to_grid else (160, 160, 160)
        pygame.draw.rect(surface, (20, 28, 40), g_btn, border_radius=5)
        pygame.draw.rect(surface, g_col, g_btn, 1, border_radius=5)
        g_txt = self.font_small.render(f"Привязка к сетке: {'ВКЛ' if self.snap_to_grid else 'ВЫКЛ'}", True, g_col)
        surface.blit(g_txt, (g_btn.centerx - g_txt.get_width() // 2, g_btn.centery - g_txt.get_height() // 2))

        # 7. Grid Step Selector [5, 10, 20, 40]
        step_lbl = self.font_small.render("Шаг стрелок (px):", True, (140, 170, 210))
        surface.blit(step_lbl, (30, 326))
        step_opts = [5, 10, 20, 40]
        for idx, st in enumerate(step_opts):
            s_rect = pygame.Rect(30 + idx * 62, 344, 54, 24)
            self.ui_rects[f"step_{st}"] = s_rect
            is_cur = (self.grid_step == st)
            s_bg = (38, 55, 80) if is_cur else (18, 24, 34)
            pygame.draw.rect(surface, s_bg, s_rect, border_radius=4)
            pygame.draw.rect(surface, TEXT_GOLD if is_cur else (50, 70, 100), s_rect, 1, border_radius=4)
            st_t = self.font_small.render(f"{st}px", True, TEXT_GOLD if is_cur else TEXT_WHITE)
            surface.blit(st_t, (s_rect.centerx - st_t.get_width() // 2, s_rect.centery - st_t.get_height() // 2))

        # Presets Section
        p_lbl = self.font_large.render("ПРЕСЕТЫ ЗНАКОВ", True, (220, 180, 80))
        surface.blit(p_lbl, (card_l.left + 16, 376))
        preset_list = [
            ("CRESCENT_BLADE", "🌙 Полумесяц"),
            ("TRIANGLE_APEX", "△ Треугольник"),
            ("CHRONO_HOURGLASS_KNOT", "⌛ Песочные Часы"),
            ("OCULUS_VOID", "👁 Око Бездны"),
            ("COSMIC_PENTACLE_SUPREME", "✦ Пентаграмма"),
        ]
        for idx, (pid, pname) in enumerate(preset_list):
            pr_r = pygame.Rect(30, 404 + idx * 30, 240, 26)
            self.ui_rects[f"preset_{pid}"] = pr_r
            pr_hov = pr_r.collidepoint(m_pos)
            pygame.draw.rect(surface, (26, 36, 52) if pr_hov else (18, 25, 36), pr_r, border_radius=5)
            pygame.draw.rect(surface, (60, 90, 130), pr_r, 1, border_radius=5)
            pr_txt = render_mixed_text(pname, self.font_small, self.font_sym_small, TEXT_CYAN if pr_hov else TEXT_WHITE)
            surface.blit(pr_txt, (pr_r.left + 12, pr_r.centery - pr_txt.get_height() // 2))

    def _render_right_panel(self, surface, m_pos):
        # Metadata & Recognition Card
        sw = surface.get_width()
        card_r = pygame.Rect(sw - 380, 72, 360, 550)
        pygame.draw.rect(surface, (16, 20, 30), card_r, border_radius=8)
        pygame.draw.rect(surface, (32, 45, 68), card_r, 1, border_radius=8)

        t_lbl = self.font_large.render("СВОЙСТВА & АНАЛИЗ", True, TEXT_GOLD)
        surface.blit(t_lbl, (card_r.left + 16, card_r.top + 10))

        # 1. Glyph ID Field
        id_lbl = self.font_small.render("ID Знака (Код для скрипта):", True, (140, 170, 210))
        surface.blit(id_lbl, (card_r.left + 16, card_r.top + 38))
        id_box = pygame.Rect(card_r.left + 16, card_r.top + 56, card_r.width - 32, 26)
        self.ui_rects["id_box"] = id_box
        is_id_act = (self.active_input_field == "ID")
        pygame.draw.rect(surface, (20, 28, 42) if is_id_act else (14, 18, 26), id_box, border_radius=4)
        pygame.draw.rect(surface, TEXT_GOLD if is_id_act else (50, 70, 100), id_box, 1, border_radius=4)
        id_disp = self.glyph_id + ("|" if is_id_act and int(self.cursor_blink_time * 2) % 2 == 0 else "")
        id_txt = self.font_med.render(id_disp, True, TEXT_GOLD if is_id_act else TEXT_WHITE)
        surface.blit(id_txt, (id_box.left + 8, id_box.centery - id_txt.get_height() // 2))

        # 2. Glyph Name Field
        name_lbl = self.font_small.render("Название (Для игры):", True, (140, 170, 210))
        surface.blit(name_lbl, (card_r.left + 16, card_r.top + 88))
        name_box = pygame.Rect(card_r.left + 16, card_r.top + 106, card_r.width - 32, 26)
        self.ui_rects["name_box"] = name_box
        is_name_act = (self.active_input_field == "NAME")
        pygame.draw.rect(surface, (20, 28, 42) if is_name_act else (14, 18, 26), name_box, border_radius=4)
        pygame.draw.rect(surface, TEXT_GOLD if is_name_act else (50, 70, 100), name_box, 1, border_radius=4)
        name_disp = self.glyph_name + ("|" if is_name_act and int(self.cursor_blink_time * 2) % 2 == 0 else "")
        name_txt = self.font_med.render(name_disp, True, TEXT_CYAN if is_name_act else TEXT_WHITE)
        surface.blit(name_txt, (name_box.left + 8, name_box.centery - name_txt.get_height() // 2))

        # 3. Symbol Selection
        sym_lbl = self.font_small.render("Иконка-символ:", True, (140, 170, 210))
        surface.blit(sym_lbl, (card_r.left + 16, card_r.top + 138))
        symbols = ["✦", "🌙", "⌛", "⚔", "☠", "△", "💠", "⚜"]
        for idx, sym in enumerate(symbols):
            sym_r = pygame.Rect(card_r.left + 16 + (idx % 4) * 83, card_r.top + 156 + (idx // 4) * 28, 77, 24)
            self.ui_rects[f"sym_{sym}"] = sym_r
            is_cur = (self.glyph_symbol == sym)
            pygame.draw.rect(surface, (36, 52, 75) if is_cur else (18, 24, 34), sym_r, border_radius=4)
            pygame.draw.rect(surface, TEXT_GOLD if is_cur else (45, 65, 95), sym_r, 1, border_radius=4)
            s_t = self.font_sym_med.render(sym, True, TEXT_GOLD if is_cur else TEXT_WHITE)
            surface.blit(s_t, (sym_r.centerx - s_t.get_width() // 2, sym_r.centery - s_t.get_height() // 2))

        # 4. Tracing Duration
        dur_lbl = self.font_small.render(f"Время ритуала: {self.glyph_duration:.1f} сек", True, (140, 170, 210))
        surface.blit(dur_lbl, (card_r.left + 16, card_r.top + 222))
        btn_m = pygame.Rect(card_r.right - 92, card_r.top + 218, 34, 22)
        btn_p = pygame.Rect(card_r.right - 50, card_r.top + 218, 34, 22)
        self.ui_rects["dur_minus"] = btn_m
        self.ui_rects["dur_plus"] = btn_p
        pygame.draw.rect(surface, (24, 34, 48), btn_m, border_radius=4)
        pygame.draw.rect(surface, (24, 34, 48), btn_p, border_radius=4)
        pygame.draw.rect(surface, (60, 90, 130), btn_m, 1, border_radius=4)
        pygame.draw.rect(surface, (60, 90, 130), btn_p, 1, border_radius=4)
        txt_m = self.font_med.render("-", True, TEXT_WHITE)
        txt_p = self.font_med.render("+", True, TEXT_WHITE)
        surface.blit(txt_m, (btn_m.centerx - txt_m.get_width() // 2, btn_m.centery - txt_m.get_height() // 2))
        surface.blit(txt_p, (btn_p.centerx - txt_p.get_width() // 2, btn_p.centery - txt_p.get_height() // 2))

        # 5. Live Similarity Recognition Results
        rec_lbl = self.font_large.render("СХОЖЕСТЬ С ДРУГИМИ", True, (220, 180, 80))
        surface.blit(rec_lbl, (card_r.left + 16, card_r.top + 252))

        if self.similarity_matches:
            top = self.similarity_matches[0]
            match_box = pygame.Rect(card_r.left + 16, card_r.top + 278, card_r.width - 32, 54)
            pygame.draw.rect(surface, (14, 22, 34), match_box, border_radius=6)
            sc_col = (80, 240, 140) if top["percent"] < 60 else (TEXT_GOLD if top["percent"] < 80 else (255, 110, 110))
            pygame.draw.rect(surface, sc_col, match_box, 1, border_radius=6)

            m_txt1 = render_mixed_text(f"{top['symbol']} {top['name'][:22]}", self.font_med, self.font_sym_med, sc_col)
            surface.blit(m_txt1, (match_box.left + 10, match_box.top + 6))
            status_txt = "★ УНИКАЛЬНЫЙ ЗНАК!" if top["percent"] < 50 else f"Схожесть: {top['percent']}%"
            m_txt2 = self.font_small.render(status_txt, True, TEXT_WHITE)
            surface.blit(m_txt2, (match_box.left + 10, match_box.top + 30))
        else:
            no_m = self.font_small.render("Нарисуйте знак для анализа...", True, (120, 140, 170))
            surface.blit(no_m, (card_r.left + 16, card_r.top + 288))

        # 6. Action Buttons
        # Test Ritual
        t_btn = pygame.Rect(card_r.left + 16, card_r.top + 346, card_r.width - 32, 36)
        self.ui_rects["test_ritual"] = t_btn
        t_hov = t_btn.collidepoint(m_pos)
        pygame.draw.rect(surface, (24, 48, 70) if t_hov else (18, 34, 52), t_btn, border_radius=6)
        pygame.draw.rect(surface, TEXT_CYAN, t_btn, 1, border_radius=6)
        t_txt = self.font_med.render("⚔ [T] ТЕСТ РИТУАЛА", True, TEXT_CYAN)
        surface.blit(t_txt, (t_btn.centerx - t_txt.get_width() // 2, t_btn.centery - t_txt.get_height() // 2))

        # Save to Game
        save_btn = pygame.Rect(card_r.left + 16, card_r.top + 390, card_r.width - 32, 38)
        self.ui_rects["save_to_game"] = save_btn
        s_hov = save_btn.collidepoint(m_pos)
        pygame.draw.rect(surface, (45, 36, 14) if s_hov else (32, 25, 10), save_btn, border_radius=6)
        pygame.draw.rect(surface, TEXT_GOLD, save_btn, 2, border_radius=6)
        sv_txt = self.font_large.render("★ СОХРАНИТЬ В ИГРУ", True, TEXT_GOLD)
        surface.blit(sv_txt, (save_btn.centerx - sv_txt.get_width() // 2, save_btn.centery - sv_txt.get_height() // 2))

        # Export Python
        py_btn = pygame.Rect(card_r.left + 16, card_r.top + 436, card_r.width - 32, 32)
        self.ui_rects["copy_python"] = py_btn
        py_hov = py_btn.collidepoint(m_pos)
        pygame.draw.rect(surface, (24, 30, 44) if py_hov else (18, 22, 32), py_btn, border_radius=6)
        pygame.draw.rect(surface, (120, 160, 220), py_btn, 1, border_radius=6)
        py_txt = self.font_small.render("СКОПИРОВАТЬ PYTHON КОД", True, (160, 205, 255))
        surface.blit(py_txt, (py_btn.centerx - py_txt.get_width() // 2, py_btn.centery - py_txt.get_height() // 2))

    def _render_footer(self, surface):
        # Footer Bar
        sw = surface.get_width()
        f_rect = pygame.Rect(20, 632, sw - 40, 78)
        pygame.draw.rect(surface, (16, 20, 30), f_rect, border_radius=8)
        pygame.draw.rect(surface, (32, 45, 68), f_rect, 1, border_radius=8)

        # Feedback Message
        fb_txt = self.font_med.render(self.feedback_text, True, self.feedback_color)
        surface.blit(fb_txt, (f_rect.left + 20, f_rect.top + 8))

        # Keymap Shortcuts
        keys_line1 = "[Стрелочки ↑↓←→]: Шаг черчения • [ПРОБЕЛ]: Поднять / Опустить перо • [S / Enter]: Сгладить и выровнять"
        keys_line2 = "[Z]: Отмена точки • [C]: Очистить • [K]: Замкнуть контур • [T]: Тест ритуала • [Ctrl+S]: Сохранить"
        k1 = self.font_small.render(keys_line1, True, (130, 160, 200))
        k2 = self.font_small.render(keys_line2, True, (110, 135, 170))
        surface.blit(k1, (f_rect.left + 20, f_rect.top + 30))
        surface.blit(k2, (f_rect.left + 20, f_rect.top + 50))

    def _render_test_ritual_overlay(self, surface):
        """Renders the sacred in-studio tracing ritual simulation."""
        cr = self.canvas_rect
        cx, cy = self.canvas_cx, self.canvas_cy

        # Blueprint ghost guideline from normalized 64 points
        scale = 4.4
        ghost_pts = [
            (cx + p.x * (scale * 0.9), cy + p.y * (scale * 0.9))
            for p in self.normalized_64
        ]
        if len(ghost_pts) >= 2:
            # Pulsing golden blueprint guide
            pygame.draw.lines(surface, (70, 55, 20), False, ghost_pts, 8)
            pygame.draw.lines(surface, (255, 215, 80), False, ghost_pts, 2)

        # Draw User's live test tracing stroke
        if len(self.test_drawn_points) >= 2:
            pygame.draw.lines(surface, (80, 220, 255), False, self.test_drawn_points, 6)
            pygame.draw.lines(surface, (255, 255, 255), False, self.test_drawn_points, 2)

        # Timer HUD at top of canvas
        t_box = pygame.Rect(cx - 150, cr.top + 16, 300, 42)
        pygame.draw.rect(surface, (12, 16, 24, 230), t_box, border_radius=6)
        pygame.draw.rect(surface, TEXT_GOLD, t_box, 1, border_radius=6)
        t_txt = self.font_med.render(f"ТЕСТ ТРЕЙСИНГА: {self.test_timer:.1f}с", True, TEXT_GOLD)
        surface.blit(t_txt, (t_box.centerx - t_txt.get_width() // 2, t_box.top + 6))

        # Score banner if completed
        if self.test_completed:
            sc_box = pygame.Rect(cx - 180, cy - 40, 360, 80)
            pygame.draw.rect(surface, (14, 20, 32, 245), sc_box, border_radius=8)
            pygame.draw.rect(surface, TEXT_GOLD, sc_box, 2, border_radius=8)
            sc_t = self.font_title.render(f"ТОЧНОСТЬ: {int(self.test_score)}%", True, TEXT_GOLD)
            sub_t = self.font_small.render("[ПРОБЕЛ / T]: Повторить тест  |  [ESC]: Завершить", True, TEXT_WHITE)
            surface.blit(sc_t, (sc_box.centerx - sc_t.get_width() // 2, sc_box.top + 14))
            surface.blit(sub_t, (sc_box.centerx - sub_t.get_width() // 2, sc_box.top + 50))

    # -------------------------------------------------------------------------
    # STANDALONE EXECUTION ENTRY POINT
    # -------------------------------------------------------------------------
    def run_standalone(self):
        """Runs the Developer Glyph Studio as an independent application."""
        pygame.init()
        screen = pygame.display.set_mode((VIEW_WIDTH, VIEW_HEIGHT))
        pygame.display.set_caption("GLYPH-BLADE • Developer Glyph Studio [DEV MODE]")
        clock = pygame.time.Clock()
        self._init_fonts()

        running = True
        while running:
            dt = clock.tick(60) / 1000.0
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    running = False
                elif event.type == pygame.KEYDOWN and event.key == pygame.K_ESCAPE and not self.testing_ritual:
                    running = False
                else:
                    self.handle_event(event)

            self.update(dt)
            self.render(screen)
            pygame.display.flip()

        pygame.quit()


if __name__ == "__main__":
    studio = DevGlyphStudio()
    studio.run_standalone()
