"""
spellcasting.py - Gesture Spell Resolution, Compound Fusions, and Casting Subsystem.
Part of the GLYPH-BLADE modular architecture.
"""

import math
import random
import pygame

from recognizer import evaluate_gesture, SKILL_INFO
from combos import COMBO_MATRIX
from achievements import ACHIEVEMENT_MANAGER
from challenges import CHALLENGE_MANAGER
from config import TEXT_GOLD, TEXT_CYAN, TEXT_PURPLE
from entities import PentagramCataclysm
from abilities import (
    BlackHoleVortex, FireFissure, GlacialStasis, MeteorImpact,
    GlacialCometFusion, FirestormVortexFusion, ThunderMeteorFusion, BloodVortexFusion,
    CrossSlashAbility, PrismaticBarrierAbility, InfiniteBladeBarrageAbility, CustomStrikeAbility,
    DimensionalRiftFusion, HolyPrismaticNovaFusion,
    cast_chain_lightning, cast_blood_harvest
)


def cast_gesture_ability(game, raw_points):
    """Evaluates gestures, resolves combos/fusions, and casts abilities into the game world."""
    skill_id, score, tier, deviation = evaluate_gesture(raw_points)
    if not skill_id or tier == "INVALID":
        return

    CHALLENGE_MANAGER.on_glyph_drawn(game)
    ACHIEVEMENT_MANAGER.unlock("first_glyph", game.fx, game.sfx)

    if game.state == 'DOJO' and hasattr(game, 'tutorial_manager'):
        game.tutorial_manager.on_glyph_cast(skill_id, score, tier, game.fx, game.sfx)
        if game.tutorial_manager.is_all_completed():
            ACHIEVEMENT_MANAGER.unlock("dojo_graduate", game.fx, game.sfx)

    skill = SKILL_INFO.get(skill_id)
    if not skill:
        return

    weapon = game.player.weapon
    accuracy_pct = int(score * 100)

    game.last_accuracy_info = {
        "name": skill["name"],
        "symbol": skill["symbol"],
        "score": accuracy_pct,
        "tier": tier,
        "color": skill["color"]
    }

    # Wild Magic & Combo Buffer Interception:
    # In wild magic mode, signs collect into the combo buffer!
    if getattr(game, 'wild_magic_mode', True):
        if tier == "FUMBLE":
            game.player.fumble_timer = weapon.fumble_stun
            game.fx.add_screen_shake(6.0)
            game.fx.spawn_sparks(game.player.x, game.player.y, (255, 40, 40), count=16)
            game.fx.add_floating_text(f"ОСЕЧКА! ({accuracy_pct}%) - СРЫВ ЗНАКА", game.player.x, game.player.y - 45, (255, 60, 60), size=22)
            game.sfx.play("fumble")
            return

        if len(game.wild_magic_queue) < 5:
            game.wild_magic_queue.append(skill_id)
            game.player.cast_anim_timer = 0.38
            game.sfx.play("slash")
            game.fx.spawn_sparks(game.player.x, game.player.y, skill["color"], count=20, speed=180)
            game.fx.add_floating_text(
                f"+ Знак [{len(game.wild_magic_queue)}/5]: {skill['symbol']} {skill['name']}",
                game.player.x, game.player.y - 48, skill["color"], size=22
            )
            game.draw_cooldown = 0.55
            game.max_draw_cooldown = 0.55
        else:
            game.fx.add_floating_text(
                "КОМБО ЗАПОЛНЕНО (5/5)! Нажми [СТАРТ] или [ПРОБЕЛ]!",
                game.player.x, game.player.y - 48, TEXT_GOLD, size=24
            )
            game.sfx.play("parry")
        return

    # Cursor in world coordinates
    screen_mx, screen_my = pygame.mouse.get_pos()
    world_mx = screen_mx + game.cam_x
    world_my = screen_my + game.cam_y

    base_angle = math.atan2(world_my - game.player.y, world_mx - game.player.x)
    eff_angle = base_angle + math.radians(deviation)

    # Fumble penalty
    if tier == "FUMBLE":
        game.player.fumble_timer = weapon.fumble_stun
        game.player.combo_count = 0
        game.last_gesture_id = None
        game.fx.add_screen_shake(8.0)
        game.fx.spawn_sparks(game.player.x, game.player.y, (255, 40, 40), count=16)
        game.fx.add_floating_text(f"ОСЕЧКА! ({accuracy_pct}%) - СРЫВ ЗНАКА", game.player.x, game.player.y - 45, (255, 60, 60), size=24)
        game.sfx.play("fumble")
        return

    game.player.combo_count += 1
    game.player.combo_timer = weapon.combo_window
    combo_mult = 1.0 + (game.player.combo_count - 1) * 0.30

    if tier == "PERFECT":
        acc_dmg_mult = 1.6
        badge_text = f"★ PERFECT {accuracy_pct}%! CRIT!"
        badge_color = TEXT_GOLD
        game.fx.add_screen_shake(12.0)
        game.sfx.play("crit")
    elif tier == "CLEAN":
        acc_dmg_mult = 1.0
        badge_text = f"CLEAN {accuracy_pct}%"
        badge_color = TEXT_CYAN
        game.fx.add_screen_shake(5.0)
        game.sfx.play("slash")
    else:  # SLOPPY
        acc_dmg_mult = 0.45
        badge_text = f"SLOPPY {accuracy_pct}% (Увод)"
        badge_color = (255, 170, 50)
        game.fx.add_screen_shake(3.0)
        game.sfx.play("slash")

    total_damage_mult = weapon.damage_mult * acc_dmg_mult * combo_mult * game.player.bonus_damage_mult
    if game.player.combo_count >= 3:
        total_damage_mult *= 2.0
        game.fx.add_floating_text("★★★ ФИНИШЕР СЕРИИ x3! ДВОЙНОЙ УРОН! ★★★", game.player.x, game.player.y - 75, TEXT_GOLD, size=28)
        game.fx.add_screen_shake(18.0)
        game.sfx.play("crit")
        game.player.combo_count = 0

    game.fx.add_floating_text(badge_text, game.player.x, game.player.y - 50, badge_color, size=22)
    game.player.cast_anim_timer = 0.38
    game.player.recovery_timer = 0.18 * weapon.recovery_mult
    game.draw_cooldown = max(0.65, 0.90 * weapon.recovery_mult)
    game.max_draw_cooldown = game.draw_cooldown

    now = game.anim_time
    time_since_last = now - game.last_gesture_time

    # =====================================================================
    # COMPOUND MULTI-RUNE SYNTHESIS CHECK!
    # =====================================================================
    is_fusion = False
    fusion_mult = total_damage_mult * (1.0 + getattr(game.player, 'fusion_damage_bonus', 0.0))

    # 1. [|] Метеорит + [V] Лед => КРИО-МЕТЕОРИТ (Glacial Comet)
    if time_since_last < 1.6 and (
        (game.last_gesture_id == "SLASH_V" and skill_id == "PARRY") or
        (game.last_gesture_id == "PARRY" and skill_id == "SLASH_V")
    ):
        game.active_abilities.append(GlacialCometFusion(world_mx, world_my, fusion_mult * 1.4))
        game.fx.add_floating_text("★ СИНТЕЗ: КРИО-МЕТЕОРИТ [| + V]! ЗАМОРОЗКА ПО ОБЛАСТИ!", world_mx, world_my - 60, (140, 230, 255), size=28)
        game.sfx.play("crit")
        is_fusion = True

    # 2. [O] Черная Дыра + [^] Огонь => ОГНЕННАЯ СИНГУЛЯРНОСТЬ
    elif time_since_last < 1.6 and (
        (game.last_gesture_id == "CIRCLE" and skill_id == "UPPERCUT") or
        (game.last_gesture_id == "UPPERCUT" and skill_id == "CIRCLE")
    ):
        game.active_abilities.append(FirestormVortexFusion(world_mx, world_my, fusion_mult * 1.35))
        game.fx.add_floating_text("★ СИНТЕЗ: ИНФЕРНАЛЬНАЯ ВОРОНКА [O + ^]!", world_mx, world_my - 60, (255, 140, 30), size=28)
        game.sfx.play("crit")
        is_fusion = True

    # 3. [|] Метеорит + [Z] Молния => ГРОМОВОЙ РАСКОЛ
    elif time_since_last < 1.6 and (
        (game.last_gesture_id == "SLASH_V" and skill_id == "ZIGZAG") or
        (game.last_gesture_id == "ZIGZAG" and skill_id == "SLASH_V")
    ):
        game.active_abilities.append(ThunderMeteorFusion(world_mx, world_my, fusion_mult * 1.45))
        game.fx.add_floating_text("★ СИНТЕЗ: ГРОМОВОЙ РАСКОЛ [| + Z]!", world_mx, world_my - 60, (255, 255, 100), size=28)
        game.sfx.play("crit")
        is_fusion = True

    # 4. [O] Черная Дыра + [>] Жатва => КРОВАВЫЙ ВИХРЬ
    elif time_since_last < 1.6 and (
        (game.last_gesture_id == "CIRCLE" and skill_id == "THRUST") or
        (game.last_gesture_id == "THRUST" and skill_id == "CIRCLE")
    ):
        game.active_abilities.append(BloodVortexFusion(world_mx, world_my, fusion_mult * 1.3))
        game.fx.add_floating_text("★ СИНТЕЗ: КРОВАВЫЙ ВИХРЬ [O + >]! ОТХИЛ +45 HP!", world_mx, world_my - 60, (255, 40, 70), size=28)
        game.sfx.play("crit")
        is_fusion = True

    # 5. [X] Крест + [—] Срез => ПРОСТРАНСТВЕННЫЙ РАЗРЫВ
    elif time_since_last < 1.6 and (
        (game.last_gesture_id == "CROSS" and skill_id == "SLASH_H") or
        (game.last_gesture_id == "SLASH_H" and skill_id == "CROSS")
    ):
        game.active_abilities.append(DimensionalRiftFusion(world_mx, world_my, fusion_mult * 1.55))
        game.fx.add_floating_text("★ СИНТЕЗ: ПРОСТРАНСТВЕННЫЙ РАЗРЫВ [X + —]!", world_mx, world_my - 60, (140, 240, 255), size=28)
        game.sfx.play("crit")
        is_fusion = True

    # 6. [△] Призма + [★] Звезда => СВЕТОВОЙ КАТАКЛИЗМ
    elif time_since_last < 1.6 and (
        (game.last_gesture_id == "TRIANGLE" and skill_id == "STAR_PENTAGRAM") or
        (game.last_gesture_id == "STAR_PENTAGRAM" and skill_id == "TRIANGLE")
    ):
        game.active_abilities.append(HolyPrismaticNovaFusion(world_mx, world_my, fusion_mult * 1.65))
        game.fx.add_floating_text("★ СИНТЕЗ: СВЕТОВОЙ КАТАКЛИЗМ [△ + ★]!", world_mx, world_my - 60, (255, 255, 180), size=28)
        game.sfx.play("crit")
        is_fusion = True

    # 7. [🛡] Щит + [⌛] Часы => АБСОЛЮТНЫЙ ХРОНО-СТАЗИС
    elif time_since_last < 1.6 and (
        (game.last_gesture_id == "SHIELD_BLOCK" and skill_id == "HOURGLASS_SWAP") or
        (game.last_gesture_id == "HOURGLASS_SWAP" and skill_id == "SHIELD_BLOCK")
    ):
        game.bullet_time_timer = 4.5
        game.player.i_frame_timer = 4.5
        for en in game.enemies:
            if en.alive:
                en.stun_timer = max(en.stun_timer, 4.0)
        game.fx.add_floating_text("★ СИНТЕЗ: ХРОНО-СТАЗИС [🛡 + ⌛]! ПОЛНЫЙ СТОП ВРЕМЕНИ 4с!", world_mx, world_my - 60, (210, 100, 255), size=28)
        game.fx.add_screen_shake(16.0)
        game.sfx.play("parry")
        is_fusion = True

    # Store for next fusion
    game.last_gesture_id = skill_id
    game.last_gesture_time = now

    if is_fusion:
        ACHIEVEMENT_MANAGER.unlock("first_fusion", game.fx, game.sfx)
        game.combo_gesture_chain.clear()
        return  # Fusion successfully consumed the compound cast!

    # Multi-glyph sequence chain buffer (min 3, up to 5 signs for Ultra-Combos!)
    game.combo_gesture_chain.append((skill_id, now))
    game.combo_gesture_chain = [(g, t) for g, t in game.combo_gesture_chain if now - t <= 3.2]
    if len(game.combo_gesture_chain) > 5:
        game.combo_gesture_chain.pop(0)

    # Check for 3, 4, or 5 sign Ultra-Combo synthesis!
    if len(game.combo_gesture_chain) >= 3:
        chain_keys = [g for g, _ in game.combo_gesture_chain]
        resolved = COMBO_MATRIX.resolve_combo(chain_keys)
        if resolved:
            ultra_spell = resolved["creator"](world_mx, world_my, total_damage_mult * resolved["mult"])
            game.active_abilities.append(ultra_spell)
            game.fx.add_floating_text(f"★★★ {resolved['name']}! ★★★", world_mx, world_my - 75, resolved["color"], size=30)
            game.fx.add_screen_shake(26.0)
            game.sfx.play("crit")
            ACHIEVEMENT_MANAGER.unlock("ultra_combo_cast", game.fx, game.sfx)
            game.combo_gesture_chain.clear()
            return

    # =====================================================================
    # STANDARD HIGH-IMPACT ABILITIES
    # =====================================================================
    atype = skill["type"]

    if atype == "shield_block":
        game.bullet_time_timer = 3.2
        game.player.i_frame_timer = 3.2
        game.fx.add_screen_shake(10.0)
        game.fx.spawn_sparks(game.player.x, game.player.y, (255, 230, 80), count=35, speed=280)
        game.fx.add_floating_text("★ БАСТИОН: ВРЕМЯ ЗАМЕДЛЕНО В 5 РАЗ!", game.player.x, game.player.y - 45, TEXT_GOLD, size=26)
        game.sfx.play("parry")
        ACHIEVEMENT_MANAGER.unlock("slo_mo_parry", game.fx, game.sfx)
        if game.state == 'DOJO' and hasattr(game, 'tutorial_manager'):
            game.tutorial_manager.on_slo_mo(game.fx, game.sfx)
            if game.tutorial_manager.is_all_completed():
                ACHIEVEMENT_MANAGER.unlock("dojo_graduate", game.fx, game.sfx)

    elif atype == "swap_position":
        target = None
        min_dist = float('inf')
        for en in game.enemies:
            if en.alive:
                d = math.hypot(world_mx - en.x, world_my - en.y)
                if d < min_dist:
                    min_dist = d
                    target = en

        if target:
            px, py = game.player.x, game.player.y
            ex, ey = target.x, target.y
            game.player.x, game.player.y = ex, ey
            target.x, target.y = px, py
            target.stun_timer = 1.4
            target.is_attacking = False
            target.backstab_vulnerable = True
            
            game.fx.spawn_sparks(px, py, (210, 100, 255), count=25, speed=220)
            game.fx.spawn_sparks(ex, ey, (210, 100, 255), count=25, speed=220)
            game.fx.add_screen_shake(12.0)
            game.fx.add_floating_text("★ РОКИРОВКА! BACKSTAB +200%", game.player.x, game.player.y - 40, TEXT_PURPLE, size=26)
            game.sfx.play("dash")
            if game.state == 'DOJO' and hasattr(game, 'tutorial_manager'):
                game.tutorial_manager.on_swap(game.fx, game.sfx)
                if game.tutorial_manager.is_all_completed():
                    ACHIEVEMENT_MANAGER.unlock("dojo_graduate", game.fx, game.sfx)
        else:
            game.fx.add_floating_text("НЕТ ВРАГА ДЛЯ РОКИРОВКИ", world_mx, world_my - 20, (180, 160, 200), size=18)

    elif atype == "cataclysm_star":
        game.active_abilities.append(PentagramCataclysm(world_mx, world_my, total_damage_mult))
        game.zone_timer += 15.0
        game.fx.add_floating_text("★ АПОКАЛИПСИС: +15s TIME!", world_mx, world_my - 50, TEXT_GOLD, size=28)
        game.sfx.play("crit")

    elif atype == "vortex":
        game.active_abilities.append(BlackHoleVortex(world_mx, world_my, total_damage_mult))
        game.sfx.play("dash")
        game.fx.add_floating_text("СИНГУЛЯРНОСТЬ!", world_mx, world_my - 30, (180, 80, 255), size=26)

    elif atype == "fire_fissure":
        game.active_abilities.append(FireFissure(game.player.x, game.player.y, eff_angle, total_damage_mult))
        game.sfx.play("slash")
        game.fx.add_screen_shake(8.0)
        game.fx.add_floating_text("ИНФЕРНО!", game.player.x, game.player.y - 30, (255, 120, 30), size=24)

    elif atype == "frost_stasis":
        target = None
        min_dist = 280.0
        for en in game.enemies:
            if en.alive:
                d = math.hypot(world_mx - en.x, world_my - en.y)
                if d < min_dist:
                    min_dist = d
                    target = en
        if target:
            game.active_abilities.append(GlacialStasis(target, total_damage_mult, game.player))
            game.sfx.play("parry")
            game.fx.spawn_sparks(target.x, target.y, (160, 230, 255), count=25, speed=220)
            game.fx.add_floating_text("ЗАМОРОЗКА! (x2.5 SHATTER)", target.x, target.y - 45, (140, 230, 255), size=26)

    elif atype == "meteor":
        game.active_abilities.append(MeteorImpact(world_mx, world_my, total_damage_mult))
        game.sfx.play("dash")
        game.fx.add_floating_text("МЕТЕОРИТ!", world_mx, world_my - 30, (255, 90, 30), size=26)

    elif atype == "lightning":
        cast_chain_lightning(game.player, game.enemies, total_damage_mult, game.fx, game.sfx)
        game.player.i_frame_timer = 0.25

    elif atype == "dimensional_slash":
        dash_len = 210.0
        game.fx.add_slash(game.player.x, game.player.y, eff_angle, "SLASH_H", (120, 240, 255))
        game.player.vx = math.cos(eff_angle) * 880.0
        game.player.vy = math.sin(eff_angle) * 880.0
        game.player.i_frame_timer = 0.32
        game.sfx.play("dash")

        for en in game.enemies:
            if en.alive and math.hypot(en.x - game.player.x, en.y - game.player.y) < 160:
                dmg = 22.0 * total_damage_mult
                en.take_hit(dmg, math.cos(eff_angle) * 280, math.sin(eff_angle) * 280, 0.4, False, game.fx, game.sfx, spell_tag="БАЗОВЫЙ РАЗРЕЗ", player=game.player)
                game.fx.add_floating_text(f"-{int(dmg)}", en.x, en.y - 25, (120, 240, 255), size=24)

    elif atype == "cross_slash":
        game.active_abilities.append(CrossSlashAbility(world_mx, world_my, total_damage_mult))
        game.sfx.play("slash")

    elif atype == "prismatic_barrier":
        game.active_abilities.append(PrismaticBarrierAbility(game.player.x, game.player.y, total_damage_mult))
        game.sfx.play("parry")
        game.fx.add_floating_text("ЭГИДА ПРИЗМЫ!", game.player.x, game.player.y - 35, (100, 255, 200), size=26)

    elif atype == "infinite_barrage":
        game.active_abilities.append(InfiniteBladeBarrageAbility(world_mx, world_my, total_damage_mult))
        game.sfx.play("slash")
        game.fx.add_floating_text("ПЕТЛЯ БЕСКОНЕЧНОСТИ (OMNISLASH)!", world_mx, world_my - 35, (220, 120, 255), size=26)

    elif atype == "custom_strike":
        game.active_abilities.append(CustomStrikeAbility(world_mx, world_my, total_damage_mult * 1.5))
        game.sfx.play("crit")
        game.fx.add_floating_text("✦ ЗНАК ВЛАДЫКИ: СВЕРХУДАР!", world_mx, world_my - 45, (255, 235, 90), size=30)
