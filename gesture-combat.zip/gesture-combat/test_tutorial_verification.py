"""
test_tutorial_verification.py - Automated test suite for Interactive Tutorial & Ghost Trajectory System.
"""

import os
import sys
import pygame

sys.stdout.reconfigure(encoding='utf-8', errors='replace')

# Set dummy video driver for headless testing
os.environ["SDL_VIDEODRIVER"] = "dummy"

from tutorial import TUTORIAL_MANAGER, GUIDE_TRAJECTORIES, TutorialQuest
from achievements import ACHIEVEMENT_MANAGER
from main import Game, MAP_WIDTH, MAP_HEIGHT, VIEW_WIDTH, VIEW_HEIGHT

def run_tests():
    print("=== TEST 1: TUTORIAL_MANAGER & GUIDE_TRAJECTORIES Verification ===")
    assert len(TUTORIAL_MANAGER.quests) == 10, f"Expected 10 quests, got {len(TUTORIAL_MANAGER.quests)}"
    print(f"Verified 10 quests registered:")
    for idx, q in enumerate(TUTORIAL_MANAGER.quests):
        print(f"  [{idx + 1}] {q.title} | Glyph: {q.glyph_key} | Target: {q.target_count}")

    # Check required glyph trajectories
    required_glyphs = ["SLASH_H", "SLASH_V", "PARRY", "UPPERCUT", "CIRCLE", "SHIELD_BLOCK", "HOURGLASS_SWAP", "STAR_PENTAGRAM", "SHATTER"]
    for gkey in required_glyphs:
        assert gkey in GUIDE_TRAJECTORIES, f"Missing trajectory for {gkey}"
        t_data = GUIDE_TRAJECTORIES[gkey]
        assert "points" in t_data or "is_composite" in t_data
        assert "steps" in t_data and len(t_data["steps"]) >= 2
        print(f"  ✓ Trajectory {gkey}: {t_data['name']} [{t_data['symbol']}] ({len(t_data.get('points', []))} points)")

    print("\n=== TEST 2: Game Initialization & DOJO State Transition ===")
    game = Game()
    assert game.state == 'MAIN_MENU'
    assert hasattr(game, 'tutorial_manager')

    # Enter DOJO from MAIN_MENU
    game.dojo_source = 'MAIN_MENU'
    game.enter_dojo()
    assert game.state == 'DOJO'
    assert len(game.enemies) == 3
    print("Verified 3 training dummies spawned in DOJO:")
    for dummy in game.enemies:
        assert getattr(dummy, 'is_training_dummy', False) is True
        assert dummy.hp == 99999
        assert dummy.speed == 0
        print(f"  - {dummy.name} | HP: {dummy.hp} | Anchor: ({dummy.anchor_x}, {dummy.anchor_y})")

    print("\n=== TEST 3: Step-by-Step Interactive Quest Progress & Auto-Advance ===")
    tm = game.tutorial_manager
    tm.reset()
    assert tm.get_completed_count() == 0
    assert tm.active_idx == 0

    # Step 1: Move on WASD
    print("Executing Step 1: WASD Movement...")
    tm.on_player_move(1.2, True, game.fx, game.sfx)
    assert not tm.quests[0].completed
    tm.on_player_move(1.0, True, game.fx, game.sfx)
    assert tm.quests[0].completed
    print(f"  ✓ Quest 1 Completed! Active quest auto-advanced to: {tm.get_active_quest().title}")
    assert tm.active_idx == 1

    # Step 2: Horizontal Slash [—]
    print("Executing Step 2: Horizontal Slash [—]...")
    tm.on_glyph_cast("SLASH_H", 0.94, "PERFECT", game.fx, game.sfx)
    assert tm.quests[1].completed
    print(f"  ✓ Quest 2 Completed! Active quest auto-advanced to: {tm.get_active_quest().title}")
    assert tm.active_idx == 2

    # Step 3: Vertical Meteor [|]
    print("Executing Step 3: Vertical Meteor [|]...")
    tm.on_glyph_cast("SLASH_V", 0.89, "PERFECT", game.fx, game.sfx)
    assert tm.quests[2].completed
    print(f"  ✓ Quest 3 Completed! Active quest auto-advanced to: {tm.get_active_quest().title}")
    assert tm.active_idx == 3

    # Step 4: Frost Stasis [V]
    print("Executing Step 4: Frost Stasis [V]...")
    tm.on_glyph_cast("PARRY", 0.91, "PERFECT", game.fx, game.sfx)
    assert tm.quests[3].completed
    print(f"  ✓ Quest 4 Completed! Active quest auto-advanced to: {tm.get_active_quest().title}")
    assert tm.active_idx == 4

    # Step 5: Shatter Combo (V + |)
    print("Executing Step 5: Shatter Combo...")
    tm.on_shatter(game.fx, game.sfx)
    assert tm.quests[4].completed
    print(f"  ✓ Quest 5 Completed! Active quest auto-advanced to: {tm.get_active_quest().title}")
    assert tm.active_idx == 5

    # Step 6: Singularity Vortex [O]
    print("Executing Step 6: Singularity Vortex [O]...")
    tm.on_glyph_cast("CIRCLE", 0.88, "CLEAN", game.fx, game.sfx)
    assert tm.quests[5].completed
    print(f"  ✓ Quest 6 Completed! Active quest auto-advanced to: {tm.get_active_quest().title}")
    assert tm.active_idx == 6

    # Step 7: Bastion Shield Block & Slo-Mo
    print("Executing Step 7: Bastion Shield & Slo-Mo...")
    tm.on_slo_mo(game.fx, game.sfx)
    assert tm.quests[6].completed
    print(f"  ✓ Quest 7 Completed! Active quest auto-advanced to: {tm.get_active_quest().title}")
    assert tm.active_idx == 7

    # Step 8: Shadow Swap [⌛]
    print("Executing Step 8: Shadow Swap [⌛]...")
    tm.on_swap(game.fx, game.sfx)
    assert tm.quests[7].completed
    print(f"  ✓ Quest 8 Completed! Active quest auto-advanced to: {tm.get_active_quest().title}")
    assert tm.active_idx == 8

    # Step 9: Weapon Switch [1-3]
    print("Executing Step 9: Weapon Switch [1-3]...")
    tm.on_weapon_switch(3, game.fx, game.sfx)
    assert tm.quests[8].completed
    print(f"  ✓ Quest 9 Completed! Active quest auto-advanced to: {tm.get_active_quest().title}")
    assert tm.active_idx == 9

    # Step 10: Combo Altar / Star Pentagram [★]
    print("Executing Step 10: Combo Altar / Star [★]...")
    tm.on_altar_open(game.fx, game.sfx)
    assert tm.quests[9].completed
    print(f"  ✓ Quest 10 Completed!")

    # Verify All 10 Quests Completed!
    assert tm.is_all_completed()
    print(f"  ★ All {tm.get_completed_count()}/10 Quests successfully completed!")

    # Verify Achievement Unlock
    ACHIEVEMENT_MANAGER.unlock("dojo_graduate", game.fx, game.sfx)
    assert ACHIEVEMENT_MANAGER.is_unlocked("dojo_graduate")
    print("  ★ Achievement 'dojo_graduate' successfully unlocked!")

    print("\n=== TEST 4: UI Rendering & Ghost Trajectory Canvas ===")
    surface = pygame.Surface((VIEW_WIDTH, VIEW_HEIGHT))
    fonts_dict = {
        "title": game.font_title,
        "large": game.font_large,
        "med": game.font_med,
        "small": game.font_small,
        "sym_large": game.font_sym_large,
        "sym_med": game.font_sym_med,
        "sym_small": game.font_sym_small
    }

    # Render expanded tutorial panel
    tm.panel_collapsed = False
    tm.draw_dojo_tutorial(surface, 1.5, fonts_dict)
    print("  ✓ Expanded tutorial panel rendered without errors.")

    # Render in-world projection hologram
    tm.show_ghost_trajectory = True
    tm.draw_in_world_projection(surface, 0, 0, game.player, 1.5, fonts_dict)
    print("  ✓ In-world ghost projection rendered without errors.")

    # Render collapsed mini-bar
    tm.panel_collapsed = True
    tm.draw_dojo_tutorial(surface, 2.0, fonts_dict)
    print("  ✓ Collapsed tutorial mini-bar rendered without errors.")

    # Test UI click handling
    tm.panel_collapsed = False
    assert tm.handle_click((330, 75)) is True # Collapse button click
    assert tm.panel_collapsed is True
    assert tm.handle_click((50, 75)) is True  # Expand bar click
    assert tm.panel_collapsed is False

    # Test leaving DOJO returns to MAIN_MENU
    game.leave_dojo()
    assert game.state == 'MAIN_MENU'
    print("  ✓ Leave DOJO successfully returned to MAIN_MENU.")

    print("\n=== ALL TUTORIAL & TRAJECTORY TESTS PASSED! ===")

if __name__ == '__main__':
    run_tests()
