"""
forge.py - Tome of Synthesis / Combo Forge System (17 Elements, 204 Combinations Matrix).
Part of the GLYPH-BLADE modular architecture.
"""

import pygame

from config import VIEW_WIDTH, VIEW_HEIGHT, TEXT_GOLD, TEXT_WHITE, TEXT_CYAN
from combos import COMBO_MATRIX, ELEMENTS, GLYPH_TO_ELEMENT


def get_combo_forge_rects(game=None):
    """Returns geometry rectangles for all interactive elements in Combo Forge Menu."""
    btn_test = pygame.Rect(380, 615, 135, 38)
    btn_seal = pygame.Rect(525, 615, 150, 38)
    btn_clear = pygame.Rect(685, 615, 135, 38)
    btn_exit = pygame.Rect(380, 665, 440, 34)

    canvas_rect = pygame.Rect(380, 175, 440, 395)

    elem_rects = {}
    # 3 Area / Action types
    area_ids = ["AOE", "ZONE", "HP"]
    for idx, eid in enumerate(area_ids):
        elem_rects[eid] = pygame.Rect(35, 155 + idx * 30, 310, 26)

    # 9 Base elements (2 columns)
    base_ids = ["FIRE", "ICE", "LIGHTNING", "EARTH", "CHRONO", "STAR", "BLADE", "PRISM", "OMNI"]
    for idx, eid in enumerate(base_ids):
        col = idx % 2
        row = idx // 2
        elem_rects[eid] = pygame.Rect(35 + col * 158, 280 + row * 34, 152, 30)

    # 5 Secret elements (floors 1-5 unlocks)
    secret_ids = ["SUPERNOVA", "ABSOLUTE_ZERO", "CHRONO_SINGULARITY", "ANTIMATTER", "PRIMORDIAL_CHAOS"]
    for idx, eid in enumerate(secret_ids):
        elem_rects[eid] = pygame.Rect(35, 485 + idx * 36, 310, 32)

    return {
        "btn_test": btn_test,
        "btn_seal": btn_seal,
        "btn_clear": btn_clear,
        "btn_exit": btn_exit,
        "canvas_rect": canvas_rect,
        "elem_rects": elem_rects
    }


def get_slot_element_info(item_key):
    """Maps any glyph or element identifier to its metadata dict."""
    if item_key in ELEMENTS:
        return ELEMENTS[item_key]
    elif item_key in GLYPH_TO_ELEMENT:
        return ELEMENTS[GLYPH_TO_ELEMENT[item_key]]
    return ELEMENTS["AOE"]


def draw_combo_forge_menu(game, surface=None):
    """Renders the comprehensive 17-Element / 204-Combination Synthesis Forge."""
    if surface is None:
        surface = game.screen

    w, h = surface.get_width(), surface.get_height()
    overlay = pygame.Surface((w, h), pygame.SRCALPHA)
    overlay.fill((8, 10, 18, 245))
    surface.blit(overlay, (0, 0))

    # Title & Subtitle with crisp font rendering
    star_l = game.font_sym_large.render("★ ", True, TEXT_GOLD)
    title_mid = game.font_title.render("КУЗНИЦА СВЯЗОК КОМБО (COMBO MATRIX FORGE)", True, TEXT_GOLD)
    star_r = game.font_sym_large.render(" ★", True, TEXT_GOLD)
    tot_tw = star_l.get_width() + title_mid.get_width() + star_r.get_width()
    tx = w // 2 - tot_tw // 2
    surface.blit(star_l, (tx, 16))
    surface.blit(title_mid, (tx + star_l.get_width(), 16))
    surface.blit(star_r, (tx + star_l.get_width() + title_mid.get_width(), 16))

    sub = game.font_med.render(
        "Формула 204 комбо: 17 настроек x 3 знака (51) + 17 x 4 знака (68) + 17 x 5 знаков (85) = 204 комбинации!",
        True, (170, 200, 235)
    )
    surface.blit(sub, (w // 2 - sub.get_width() // 2, 58))

    rects = get_combo_forge_rects(game)

    # =========================================================================
    # LEFT PANEL: 17 НАСТРОЕК И СТИХИЙ (17 SETTINGS)
    # =========================================================================
    lp_rect = pygame.Rect(25, 95, 330, 685)
    pygame.draw.rect(surface, (13, 17, 28), lp_rect)
    pygame.draw.rect(surface, (40, 56, 82), lp_rect, 2)

    lp_head = game.font_large.render("17 НАСТРОЕК И СТИХИЙ", True, TEXT_GOLD)
    surface.blit(lp_head, (lp_rect.centerx - lp_head.get_width() // 2, 105))

    # 3 Area Types
    g1_txt = game.font_small.render("● 3 ТИПА ДЕЙСТВИЯ (ОБЛАСТЬ / ЗОНА / HP):", True, TEXT_CYAN)
    surface.blit(g1_txt, (35, 134))

    area_keys = ["AOE", "ZONE", "HP"]
    for eid in area_keys:
        e_info = ELEMENTS[eid]
        r = rects["elem_rects"][eid]
        pygame.draw.rect(surface, (20, 26, 40), r)
        pygame.draw.rect(surface, e_info["color"], r, 1)

        sym_s = game.font_sym_med.render(f"[{e_info['symbol']}]", True, e_info["color"])
        surface.blit(sym_s, (r.x + 8, r.y + 2))

        name_s = game.font_small.render(e_info["name"], True, TEXT_WHITE)
        surface.blit(name_s, (r.x + 46, r.y + 5))

    # 9 Base Elements
    g2_txt = game.font_small.render("● 9 БАЗОВЫХ СТИХИЙ (КЛИКНИ ИЛИ НАРИСУЙ):", True, TEXT_CYAN)
    surface.blit(g2_txt, (35, 256))

    base_keys = ["FIRE", "ICE", "LIGHTNING", "EARTH", "CHRONO", "STAR", "BLADE", "PRISM", "OMNI"]
    for eid in base_keys:
        e_info = ELEMENTS[eid]
        r = rects["elem_rects"][eid]
        pygame.draw.rect(surface, (20, 26, 40), r)
        pygame.draw.rect(surface, e_info["color"], r, 1)

        sym_s = game.font_sym_med.render(f"[{e_info['symbol']}]", True, e_info["color"])
        surface.blit(sym_s, (r.x + 6, r.y + 4))

        short_name = e_info["name"].split()[0]
        name_s = game.font_small.render(short_name, True, TEXT_WHITE)
        surface.blit(name_s, (r.x + 40, r.y + 7))

    # 5 Secret Elements
    g3_txt = game.font_small.render("● 5 ЗАСЕКРЕЧЕННЫХ СТИХИЙ (ЭТАЖИ 1-5):", True, TEXT_CYAN)
    surface.blit(g3_txt, (35, 460))

    secret_keys = ["SUPERNOVA", "ABSOLUTE_ZERO", "CHRONO_SINGULARITY", "ANTIMATTER", "PRIMORDIAL_CHAOS"]
    for eid in secret_keys:
        e_info = ELEMENTS[eid]
        r = rects["elem_rects"][eid]
        is_open = COMBO_MATRIX.is_element_unlocked(eid)

        b_col = e_info["color"] if is_open else (50, 60, 80)
        pygame.draw.rect(surface, (18, 22, 34) if is_open else (12, 14, 20), r)
        pygame.draw.rect(surface, b_col, r, 1)

        sym_col = e_info["color"] if is_open else (100, 110, 130)
        sym_s = game.font_sym_med.render(f"[{e_info['symbol']}]", True, sym_col)
        surface.blit(sym_s, (r.x + 8, r.y + 5))

        name_col = TEXT_WHITE if is_open else (120, 130, 150)
        name_s = game.font_small.render(e_info["name"], True, name_col)
        surface.blit(name_s, (r.x + 46, r.y + 8))

        tag_str = "[ОТКРЫТО]" if is_open else f"[ЭТАЖ {e_info['floor_unlock']}]"
        tag_col = (80, 240, 140) if is_open else (240, 120, 60)
        tag_s = game.font_small.render(tag_str, True, tag_col)
        surface.blit(tag_s, (r.right - tag_s.get_width() - 8, r.y + 8))

    # =========================================================================
    # CENTER PANEL: SLOTS & DRAWING CANVAS
    # =========================================================================
    cp_rect = pygame.Rect(370, 95, 460, 685)
    pygame.draw.rect(surface, (14, 18, 30), cp_rect)
    pygame.draw.rect(surface, (45, 62, 92), cp_rect, 2)

    # 5 Combo Slots across top of center panel
    slot_w = 82
    slot_h = 56
    slot_y = 105
    for i in range(5):
        sx = 378 + i * 88
        sr = pygame.Rect(sx, slot_y, slot_w, slot_h)
        if i < len(game.forge_slots):
            item_key = game.forge_slots[i]
            e_data = get_slot_element_info(item_key)
            pygame.draw.rect(surface, (24, 32, 50), sr)
            pygame.draw.rect(surface, e_data["color"], sr, 2)

            s_surf = game.font_sym_large.render(f"{e_data['symbol']}", True, e_data["color"])
            surface.blit(s_surf, (sr.centerx - s_surf.get_width() // 2, sr.y + 3))

            sn_surf = game.font_small.render(e_data["name"], True, TEXT_WHITE)
            surface.blit(sn_surf, (sr.centerx - sn_surf.get_width() // 2, sr.y + 32))
        else:
            pygame.draw.rect(surface, (16, 20, 32), sr)
            pygame.draw.rect(surface, (40, 50, 70), sr, 1)
            req_txt = f"СЛОТ {i+1}" if i < 3 else f"+СЛОТ {i+1}"
            txt_col = (140, 155, 175) if i < 3 else (90, 105, 125)
            s_surf = game.font_small.render(req_txt, True, txt_col)
            surface.blit(s_surf, (sr.centerx - s_surf.get_width() // 2, sr.centery - s_surf.get_height() // 2))

    # Canvas Tablet
    canv_r = rects["canvas_rect"]
    pygame.draw.rect(surface, (10, 13, 22), canv_r)
    pygame.draw.rect(surface, (255, 215, 75), canv_r, 2)

    # Crosshair and runes in canvas
    pygame.draw.line(surface, (28, 38, 58), (canv_r.x, canv_r.centery), (canv_r.right, canv_r.centery), 1)
    pygame.draw.line(surface, (28, 38, 58), (canv_r.centerx, canv_r.y), (canv_r.centerx, canv_r.bottom), 1)
    pygame.draw.circle(surface, (34, 46, 70), (canv_r.centerx, canv_r.centery), 130, 1)

    # Watermark hint inside canvas if empty
    if len(game.forge_points) == 0:
        wm1 = game.font_med.render("РИСУЙ ЗНАКИ ПО ОЧЕРЕДИ НА ХОЛСТЕ", True, (60, 80, 115))
        wm2 = game.font_small.render("(Или просто кликай стихии слева)", True, (50, 70, 95))
        surface.blit(wm1, (canv_r.centerx - wm1.get_width() // 2, canv_r.centery - 20))
        surface.blit(wm2, (canv_r.centerx - wm2.get_width() // 2, canv_r.centery + 10))

    # Draw current stroke
    if len(game.forge_points) > 1:
        pygame.draw.lines(surface, (120, 240, 255), False, game.forge_points, 5)
        pygame.draw.lines(surface, (255, 255, 255), False, game.forge_points, 2)
        for pt in game.forge_points:
            pygame.draw.circle(surface, (140, 245, 255), pt, 4)

    # Feedback text
    fb_col = TEXT_GOLD if ("СИНТЕЗИРОВАНО" in game.forge_feedback or "ЗАПЕЧАТАНО" in game.forge_feedback) else TEXT_CYAN
    fb_s = game.font_small.render(game.forge_feedback, True, fb_col)
    surface.blit(fb_s, (cp_rect.centerx - fb_s.get_width() // 2, canv_r.bottom + 8))

    # Action Buttons
    # [ТЕСТ (SPACE)]
    b_test = rects["btn_test"]
    pygame.draw.rect(surface, (25, 38, 56), b_test)
    pygame.draw.rect(surface, (90, 180, 255), b_test, 1)
    bt_s = game.font_small.render("[ТЕСТ] (SPACE)", True, (160, 220, 255))
    surface.blit(bt_s, (b_test.centerx - bt_s.get_width() // 2, b_test.centery - bt_s.get_height() // 2))

    # [ЗАПЕЧАТАТЬ [F]]
    b_seal = rects["btn_seal"]
    pygame.draw.rect(surface, (40, 32, 20), b_seal)
    pygame.draw.rect(surface, TEXT_GOLD, b_seal, 2)
    star_icon = game.font_sym_small.render("★ ", True, TEXT_GOLD)
    seal_txt = game.font_small.render("ЗАПЕЧАТАТЬ [F]", True, TEXT_GOLD)
    tot_sw = star_icon.get_width() + seal_txt.get_width()
    surface.blit(star_icon, (b_seal.centerx - tot_sw // 2, b_seal.centery - seal_txt.get_height() // 2))
    surface.blit(seal_txt, (b_seal.centerx - tot_sw // 2 + star_icon.get_width(), b_seal.centery - seal_txt.get_height() // 2))

    # [ОЧИСТИТЬ]
    b_clear = rects["btn_clear"]
    pygame.draw.rect(surface, (34, 20, 24), b_clear)
    pygame.draw.rect(surface, (240, 80, 90), b_clear, 1)
    bc_s = game.font_small.render("ОЧИСТИТЬ (BS)", True, (255, 140, 150))
    surface.blit(bc_s, (b_clear.centerx - bc_s.get_width() // 2, b_clear.centery - bc_s.get_height() // 2))

    # [ВЫЙТИ В БОЙ]
    b_exit = rects["btn_exit"]
    pygame.draw.rect(surface, (18, 24, 38), b_exit)
    pygame.draw.rect(surface, (70, 95, 135), b_exit, 1)
    be_s = game.font_small.render("ЗАКРЫТЬ АЛТАРЬ И ВЕРНУТЬСЯ В БОЙ [ESC / C]", True, (190, 205, 230))
    surface.blit(be_s, (b_exit.centerx - be_s.get_width() // 2, b_exit.centery - be_s.get_height() // 2))

    # =========================================================================
    # RIGHT PANEL: RESULT CARD & CODEX
    # =========================================================================
    rp_rect = pygame.Rect(845, 95, 330, 685)
    pygame.draw.rect(surface, (13, 17, 28), rp_rect)
    pygame.draw.rect(surface, (40, 56, 82), rp_rect, 2)

    rp_head = game.font_large.render("РЕЗУЛЬТАТ СИНТЕЗА", True, TEXT_CYAN)
    surface.blit(rp_head, (rp_rect.centerx - rp_head.get_width() // 2, 105))

    if len(game.forge_slots) >= 3:
        res = COMBO_MATRIX.resolve_combo(game.forge_slots)
        
        res_card = pygame.Rect(858, 145, 304, 360)
        pygame.draw.rect(surface, (18, 24, 38), res_card)
        pygame.draw.rect(surface, res["color"], res_card, 2)

        # Name with icon rendered cleanly
        is_uf = ("Полярный" in res["name"] or "Заморозка" in res["name"])
        clean_name = res["name"].replace("❄ ", "").replace("★ ", "")
        head_icon = game.font_sym_med.render("❄ " if is_uf else "★ ", True, res["color"])
        surface.blit(head_icon, (res_card.x + 12, res_card.y + 12))
        avail_w = res_card.width - 24 - head_icon.get_width()
        r_font = game.font_med if game.font_med.size(clean_name)[0] <= avail_w else game.font_small
        r_name = r_font.render(clean_name, True, res["color"])
        surface.blit(r_name, (res_card.x + 12 + head_icon.get_width(), res_card.y + (12 if r_font == game.font_med else 15)))

        r_tier = game.font_small.render(f"РАНГ: {res['tier']} | УРОН x{res['mult']:.2f}", True, TEXT_GOLD)
        surface.blit(r_tier, (res_card.x + 12, res_card.y + 40))

        # Sequence badges drawn with symbol font
        seq_lbl = game.font_small.render("Связка: ", True, TEXT_WHITE)
        surface.blit(seq_lbl, (res_card.x + 12, res_card.y + 68))
        cur_x = res_card.x + 12 + seq_lbl.get_width()
        for idx_k, k in enumerate(game.forge_slots):
            e_data = get_slot_element_info(k)
            sym_s = game.font_sym_med.render(f"[{e_data['symbol']}]", True, e_data["color"])
            surface.blit(sym_s, (cur_x, res_card.y + 66))
            cur_x += sym_s.get_width() + 4
            if idx_k < len(game.forge_slots) - 1:
                plus_s = game.font_small.render("+", True, (160, 180, 200))
                surface.blit(plus_s, (cur_x, res_card.y + 68))
                cur_x += plus_s.get_width() + 4

        if is_uf:
            uf_box = pygame.Rect(res_card.x + 10, res_card.y + 98, res_card.width - 20, 110)
            pygame.draw.rect(surface, (15, 35, 55), uf_box)
            pygame.draw.rect(surface, (140, 240, 255), uf_box, 2)

            uf_icon = game.font_sym_med.render("❄ ", True, (140, 240, 255))
            uf_t = game.font_med.render("УЛЬТРА-ЗАМОРОЗКА!", True, (140, 240, 255))
            tot_ufw = uf_icon.get_width() + uf_t.get_width()
            surface.blit(uf_icon, (uf_box.centerx - tot_ufw // 2, uf_box.y + 8))
            surface.blit(uf_t, (uf_box.centerx - tot_ufw // 2 + uf_icon.get_width(), uf_box.y + 8))
            
            uf_d1 = game.font_small.render("● Мгновенный абсолютный стазис", True, TEXT_WHITE)
            uf_d2 = game.font_small.render("  всех врагов и боссов на всей арене!", True, TEXT_WHITE)
            uf_d3 = game.font_small.render("● Крио-раскол с уроном x3.40+", True, (160, 230, 255))
            surface.blit(uf_d1, (uf_box.x + 10, uf_box.y + 36))
            surface.blit(uf_d2, (uf_box.x + 10, uf_box.y + 54))
            surface.blit(uf_d3, (uf_box.x + 10, uf_box.y + 76))
        else:
            desc_s1 = game.font_small.render(res["desc"][:42], True, (210, 220, 240))
            desc_s2 = game.font_small.render(res["desc"][42:85], True, (210, 220, 240))
            surface.blit(desc_s1, (res_card.x + 12, res_card.y + 105))
            surface.blit(desc_s2, (res_card.x + 12, res_card.y + 125))

        seal_h = game.font_small.render("Нажми [ENTER], чтобы привязать к [F]!", True, TEXT_GOLD)
        surface.blit(seal_h, (res_card.x + 12, res_card.bottom - 32))

    else:
        info_box = pygame.Rect(858, 145, 304, 360)
        pygame.draw.rect(surface, (16, 21, 33), info_box)
        pygame.draw.rect(surface, (45, 60, 85), info_box, 1)

        i1 = game.font_med.render("КАК СИНТЕЗИРОВАТЬ:", True, TEXT_GOLD)
        surface.blit(i1, (info_box.x + 12, info_box.y + 12))

        lines = [
            ("1.", "Начерти на холсте или кликни"),
            ("  ", "минимум 3 знака связки (до 5)."),
            ("2.", "Пример Легендарного Комбо:"),
            ("  ", "★ Звезда [★]"),
            ("  ", "+ Инферно [^]"),
            ("  ", "+ Крио [V]"),
            ("=>", "УЛЬТРА-ЗАМОРОЗКА!"),
            ("3.", "Жми [ENTER], чтобы запечатать"),
            ("  ", "в клавишу быстрого вызова [F]!")
        ]
        iy = info_box.y + 42
        for prefix, text in lines:
            c = (140, 240, 255) if "УЛЬТРА" in text or "Звезда" in text or "Инферно" in text or "Крио" in text else (210, 220, 240)
            if prefix in ("1.", "2.", "3.", "=>"):
                s = game.font_small.render(f"{prefix} {text}", True, TEXT_GOLD if prefix != "=>" else (140, 240, 255))
            else:
                s = game.font_small.render(f"   {text}", True, c)
            surface.blit(s, (info_box.x + 10, iy))
            iy += 26

    # Bottom section: Current Sealed Combo Status
    bot_box = pygame.Rect(858, 520, 304, 240)
    pygame.draw.rect(surface, (18, 22, 34), bot_box)
    pygame.draw.rect(surface, (55, 75, 110), bot_box, 1)

    b_title = game.font_med.render("БЫСТРЫЙ ВЫЗОВ В БОЮ [F]:", True, TEXT_GOLD)
    surface.blit(b_title, (bot_box.x + 12, bot_box.y + 12))

    if game.sealed_ultra_combo:
        sc = game.sealed_ultra_combo
        sc_s1 = game.font_small.render("АКТИВНОЕ ЗАПЕЧАТАННОЕ КОМБО:", True, TEXT_CYAN)
        surface.blit(sc_s1, (bot_box.x + 12, bot_box.y + 40))
        clean_sc_name = sc["name"].replace("❄ ", "").replace("★ ", "")
        sc_icon = game.font_sym_med.render("❄ " if "Полярный" in sc["name"] else "★ ", True, sc["color"])
        sc_s2 = game.font_med.render(clean_sc_name[:24], True, sc["color"])
        surface.blit(sc_icon, (bot_box.x + 12, bot_box.y + 64))
        surface.blit(sc_s2, (bot_box.x + 12 + sc_icon.get_width(), bot_box.y + 64))
        sc_s3 = game.font_small.render(f"Урон: x{sc['mult']:.2f} | В бою жми [F]!", True, (80, 240, 140))
        surface.blit(sc_s3, (bot_box.x + 12, bot_box.y + 92))
    else:
        sc_empty = game.font_small.render("Слот [F] пуст.", True, (140, 150, 170))
        surface.blit(sc_empty, (bot_box.x + 12, bot_box.y + 40))
        sc_hint = game.font_small.render("Собери 3+ знака и нажми [ENTER],", True, (170, 185, 205))
        sc_hint2 = game.font_small.render("чтобы зарядить клавишу [F]!", True, (170, 185, 205))
        surface.blit(sc_hint, (bot_box.x + 12, bot_box.y + 64))
        surface.blit(sc_hint2, (bot_box.x + 12, bot_box.y + 84))

    # 204 combinations formula badge
    f_box = pygame.Rect(bot_box.x + 10, bot_box.y + 125, bot_box.width - 20, 100)
    pygame.draw.rect(surface, (12, 16, 26), f_box)
    pygame.draw.rect(surface, (35, 50, 75), f_box, 1)

    f_head = game.font_small.render("БИБЛИОТЕКА КОМБО (204 ВСЕГО):", True, TEXT_GOLD)
    surface.blit(f_head, (f_box.x + 8, f_box.y + 6))
    f_l1 = game.font_small.render("● 17 x 3 знака = 51 комбо", True, (180, 195, 220))
    f_l2 = game.font_small.render("● 17 x 4 знака = 68 комбо", True, (180, 195, 220))
    f_l3 = game.font_small.render("● 17 x 5 знаков = 85 комбо", True, (180, 195, 220))
    f_sum = game.font_small.render("ИТОГО: 204 УНИКАЛЬНЫХ ЗАКЛИНАНИЯ", True, (80, 235, 255))
    surface.blit(f_l1, (f_box.x + 8, f_box.y + 26))
    surface.blit(f_l2, (f_box.x + 8, f_box.y + 44))
    surface.blit(f_l3, (f_box.x + 8, f_box.y + 62))
    surface.blit(f_sum, (f_box.x + 8, f_box.y + 80))
