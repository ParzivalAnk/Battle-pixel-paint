import os
import math
import random
import pygame

# Set headless video driver for testing
os.environ["SDL_VIDEODRIVER"] = "dummy"

from main import (
    Game, VIEW_WIDTH, VIEW_HEIGHT, MAP_WIDTH, MAP_HEIGHT,
    WILD_MAGIC_PATTERNS, GLYPH_COMPLEXITY, best_template_distance
)
from recognizer import Point, resample, scale_and_center
from achievements import ACHIEVEMENT_MANAGER

print("=== STARTING EXPANDED WILD MAGIC, 5-SLOT BUFFER & BOSS CUTSCENE VERIFICATION ===")

pygame.init()
pygame.font.init()

game = Game()
game.state = 'PLAYING'
game.load_floor(0)

# =============================================================================
# 1. VERIFY ALL 13 SACRED GLYPHS IN WILD_MAGIC_PATTERNS
# =============================================================================
print("\n--- 1. Verifying 13 Sacred Glyphs & Durations ---")
expected_glyphs = [
    "CRESCENT_BLADE", "TRIANGLE_APEX", "DIAMOND_SEAL", "HEXAGRAM_SEAL",
    "AETHER_LEMNISCATE", "CROWN_SERAPHIM", "OCULUS_VOID", "CHRONO_HOURGLASS_KNOT",
    "VALKIRIA_BLADE_CREST", "HEPTAGRAM_CHAOS", "NECRO_SPIRE_SIGIL",
    "COSMIC_PENTACLE_SUPREME", "JUDGEMENT_SCALES"
]
assert len(WILD_MAGIC_PATTERNS) >= 13, f"Expected at least 13 patterns, got {len(WILD_MAGIC_PATTERNS)}"
for gid in expected_glyphs:
    assert gid in WILD_MAGIC_PATTERNS, f"Missing pattern: {gid}"
    p = WILD_MAGIC_PATTERNS[gid]
    assert len(p["resampled"]) == 64, f"Resampled points must be 64 for {gid}"
    assert p["duration"] >= 18.0, f"Duration must be >= 18s for {gid}, got {p['duration']}"
    print(f"  [OK] Glyph {gid}: Duration {p['duration']}s, Boss Req: Floor {p['boss_req']}")

# =============================================================================
# 2. TEST DYNAMIC PATTERN SELECTION (1-5 GLYPH ROUTING & SIMPLIFIED TIER 1)
# =============================================================================
print("\n--- 2. Testing Dynamic Pattern Selection based on Count & Complexity ---")
# Case A: 1 basic slash -> Clean Tier 1 Crescent Blade (18.0s)
game.wild_magic_queue = ["SLASH_H"]
pat_t1 = game.get_wild_magic_pattern_for_queue()
assert pat_t1["id"] == "CRESCENT_BLADE", f"Expected CRESCENT_BLADE for single slash, got {pat_t1['id']}"
assert pat_t1["duration"] == 18.0, f"Expected 18.0s, got {pat_t1['duration']}"
print(f"  [OK] 1 Basic Slash -> {pat_t1['id']} ({pat_t1['duration']}s) [Clean Single-Stroke Shape!]")

# Case B: 1 uppercut / defense -> Clean Tier 1 Triangle Apex (18.0s)
game.wild_magic_queue = ["UPPERCUT"]
pat_tri = game.get_wild_magic_pattern_for_queue()
assert pat_tri["id"] == "TRIANGLE_APEX", f"Expected TRIANGLE_APEX, got {pat_tri['id']}"
print(f"  [OK] 1 Vertical/Defense -> {pat_tri['id']} ({pat_tri['duration']}s)")

# Case C: 2 slashes -> Tier 2 Diamond or Hexagram Seal (19.0s)
game.wild_magic_queue = ["SLASH_H", "SLASH_V"]
pat_t2 = game.get_wild_magic_pattern_for_queue()
assert pat_t2["id"] in ("DIAMOND_SEAL", "HEXAGRAM_SEAL"), f"Expected Tier 2 Seal, got {pat_t2['id']}"
assert pat_t2["duration"] == 19.0, f"Expected 19.0s, got {pat_t2['duration']}"
print(f"  [OK] 2 Slashes -> {pat_t2['id']} ({pat_t2['duration']}s)")

# Case D: Defensive runes -> Tier 2 Crown of the Seraphim (20.0s)
game.wild_magic_queue = ["SHIELD_BLOCK", "TRIANGLE"]
pat_crown = game.get_wild_magic_pattern_for_queue()
assert pat_crown["id"] == "CROWN_SERAPHIM", f"Expected CROWN_SERAPHIM, got {pat_crown['id']}"
assert pat_crown["duration"] == 20.0, f"Expected 20.0s, got {pat_crown['duration']}"
print(f"  [OK] Defensive Runes -> {pat_crown['id']} ({pat_crown['duration']}s)")

# Case E: 3 runes (Chaos/Void) -> Tier 3 Oculus Void or Heptagram (22.0s)
game.wild_magic_queue = ["CIRCLE", "SLASH_H", "SLASH_V"]
pat_eye = game.get_wild_magic_pattern_for_queue()
assert pat_eye["id"] == "OCULUS_VOID", f"Expected OCULUS_VOID, got {pat_eye['id']}"
print(f"  [OK] 3 Runes (Void) -> {pat_eye['id']} ({pat_eye['duration']}s) [Clean Almond Eye!]")

# Case F: 5 runes in buffer -> Tier 5 Cosmic Pentacle Supreme (25.0s)
game.wild_magic_queue = ["SLASH_H", "SLASH_V", "ZIGZAG", "STAR_PENTAGRAM", "CIRCLE"]
pat_t5 = game.get_wild_magic_pattern_for_queue()
assert pat_t5["id"] == "COSMIC_PENTACLE_SUPREME", f"Expected COSMIC_PENTACLE_SUPREME for 5 runes, got {pat_t5['id']}"
assert pat_t5["duration"] == 25.0, f"Expected 25.0s, got {pat_t5['duration']}"
print(f"  [OK] 5 Runes Buffer -> {pat_t5['id']} ({pat_t5['duration']}s) [Supreme Finisher!]")

# =============================================================================
# 3. TEST BOSS UNLOCK PROGRESSION (TIME MAGIC & FLOOR BOSSES)
# =============================================================================
print("\n--- 3. Testing Boss Unlock Progression for Time Magic & Sacred Signs ---")
# On Floor 0: Chrono Magic is locked!
game.wild_magic_queue = ["HOURGLASS_SWAP", "PARRY", "INFINITY"]
assert "CHRONO_HOURGLASS_KNOT" not in game.unlocked_wild_magic_glyphs, "Chrono knot must start locked on Floor 0!"
pat_locked = game.get_wild_magic_pattern_for_queue()
assert pat_locked["id"] == "AETHER_LEMNISCATE", f"Must fallback to AETHER_LEMNISCATE when Chrono locked, got {pat_locked['id']}"
print(f"  [OK] Floor 0 (Locked Chrono): Selected fallback {pat_locked['id']}")

# Progress to Floor 2 (beating Floor 1 Boss Malchor)
game.load_floor(1)
assert "CHRONO_HOURGLASS_KNOT" in game.unlocked_wild_magic_glyphs, "CHRONO_HOURGLASS_KNOT must unlock after beating Floor 1 Boss!"
assert ACHIEVEMENT_MANAGER.is_unlocked("chrono_wild_magic"), "Achievement 'chrono_wild_magic' must unlock!"
print("  [OK] Floor 2 Reached: CHRONO_HOURGLASS_KNOT Unlocked! Achievement 'chrono_wild_magic' Granted!")

# Now queue with Time runes must select Chrono Knot!
game.wild_magic_queue = ["HOURGLASS_SWAP", "PARRY", "INFINITY"]
pat_unlocked_chrono = game.get_wild_magic_pattern_for_queue()
assert pat_unlocked_chrono["id"] == "CHRONO_HOURGLASS_KNOT", f"Expected CHRONO_HOURGLASS_KNOT, got {pat_unlocked_chrono['id']}"
assert pat_unlocked_chrono["duration"] == 22.0, f"Expected 22.0s, got {pat_unlocked_chrono['duration']}"
print(f"  [OK] Time Runes after Boss -> {pat_unlocked_chrono['id']} ({pat_unlocked_chrono['duration']}s)")

# Progress to Floor 3 (Valkiria Blade Crest Unlocks)
game.load_floor(2)
assert "VALKIRIA_BLADE_CREST" in game.unlocked_wild_magic_glyphs, "VALKIRIA_BLADE_CREST must unlock after Floor 2 Boss!"
game.wild_magic_queue = ["SLASH_H", "SLASH_V", "CROSS"]
pat_valk = game.get_wild_magic_pattern_for_queue()
assert pat_valk["id"] == "VALKIRIA_BLADE_CREST", f"Expected VALKIRIA_BLADE_CREST, got {pat_valk['id']}"
print(f"  [OK] Floor 3 Reached: VALKIRIA_BLADE_CREST Unlocked! ({pat_valk['duration']}s)")

# Progress to Floor 4 (Necro Spire Sigil Unlocks)
game.load_floor(3)
assert "NECRO_SPIRE_SIGIL" in game.unlocked_wild_magic_glyphs, "NECRO_SPIRE_SIGIL must unlock after Floor 3 Boss!"
game.wild_magic_queue = ["STAR_PENTAGRAM", "CIRCLE", "CROSS", "UPPERCUT"]
pat_necro = game.get_wild_magic_pattern_for_queue()
assert pat_necro["id"] == "NECRO_SPIRE_SIGIL", f"Expected NECRO_SPIRE_SIGIL, got {pat_necro['id']}"
print(f"  [OK] Floor 4 Reached: NECRO_SPIRE_SIGIL Unlocked! ({pat_necro['duration']}s)")

# =============================================================================
# 4. TEST 5-SLOT HUD BUFFER RENDERING & SAVE PREVIEW
# =============================================================================
print("\n--- 4. Testing 5-Slot HUD Buffer Rendering ---")
artifact_dir = r"C:\Users\Parzi\.gemini\antigravity\brain\e1863129-f3a8-499f-bf5e-d134defe1c6c"
os.makedirs(artifact_dir, exist_ok=True)

# Fill 5 slots in buffer
game.wild_magic_queue = ["SLASH_H", "PARRY", "CIRCLE", "ZIGZAG", "STAR_PENTAGRAM"]
assert len(game.wild_magic_queue) == 5, "Buffer must hold exactly 5 runes!"
game.screen.fill((14, 18, 26))
game.draw_hud(game.screen)

hud_preview_path = os.path.join(artifact_dir, "wild_magic_hud_buffer_preview.png")
pygame.image.save(game.screen, hud_preview_path)
print(f"  [OK] Saved 5-Slot Combo HUD Preview to: {hud_preview_path}")

# =============================================================================
# 5. TEST SACRED GLYPH DRAWING ACCURACY WITH FORGIVING 68.0 DIVISOR
# =============================================================================
print("\n--- 5. Testing Sacred Tracing & Forgiving Tolerance (68.0 Divisor) ---")
game.wild_magic_queue = ["SLASH_H"]
game.trigger_wild_magic_start()
assert game.wild_magic_state == 'RITUAL', "Game must enter RITUAL state!"
assert game.wild_magic_pattern["id"] == "CRESCENT_BLADE"

pattern = game.wild_magic_pattern
cw, ch = 420, 420
cx = VIEW_WIDTH // 2 - cw // 2
cy = VIEW_HEIGHT // 2 - ch // 2 + 30
margin = 35
scale_x = (cw - margin * 2) / 100.0
scale_y = (ch - margin * 2) / 100.0

simulated_screen_stroke = []
for p in pattern["resampled"]:
    sx = cx + margin + (p.x + 50.0) * scale_x + random.uniform(-1.0, 1.0)
    sy = cy + margin + (p.y + 50.0) * scale_y + random.uniform(-1.0, 1.0)
    simulated_screen_stroke.append((sx, sy))

game.wild_magic_drawn_points = simulated_screen_stroke

# Render ritual screen before evaluation
game.screen.fill((10, 14, 22))
game.draw_wild_magic_ritual(game.screen)
ritual_preview_path = os.path.join(artifact_dir, "wild_magic_ritual_tracing_preview.png")
pygame.image.save(game.screen, ritual_preview_path)
print(f"  [OK] Saved Simplified Ritual Tracing Preview to: {ritual_preview_path}")

# Evaluate single-rune crescent blade
game.evaluate_wild_magic_drawing()
assert game.wild_magic_state is None
assert len(game.wild_magic_queue) == 0
print("  [OK] 1-Rune Crescent Blade smoothly evaluated without triggering boss cutscene!")

# =============================================================================
# 6. TEST 5-GLYPH COMBO FINISHER CINEMATIC CUTSCENE
# =============================================================================
print("\n--- 6. Testing 5-Glyph Combo Boss Finisher Cinematic Cutscene ---")
# Setup boss enemy
boss = game.enemies[0]
boss.alive = True
boss.is_boss = True
boss.hp = 5000.0
boss.max_hp = 5000.0
initial_boss_hp = boss.hp

# Queue 5 glyphs for ultimate combo
game.wild_magic_queue = ["SLASH_H", "SLASH_V", "ZIGZAG", "CIRCLE", "STAR_PENTAGRAM"]
game.trigger_wild_magic_start()
assert game.wild_magic_pattern["id"] == "COSMIC_PENTACLE_SUPREME"

# Simulate stroke tracing the supreme pentacle
pattern_t5 = game.wild_magic_pattern
t5_stroke = []
for p in pattern_t5["resampled"]:
    sx = cx + margin + (p.x + 50.0) * scale_x + random.uniform(-1.2, 1.2)
    sy = cy + margin + (p.y + 50.0) * scale_y + random.uniform(-1.2, 1.2)
    t5_stroke.append((sx, sy))

game.wild_magic_drawn_points = t5_stroke

# Evaluate! With 5 runes and an alive boss, it must trigger CUTSCENE_5_GLYPH!
game.evaluate_wild_magic_drawing()

assert game.state == 'CUTSCENE_5_GLYPH', f"Game state must switch to 'CUTSCENE_5_GLYPH', got {game.state}"
assert game.cutscene_boss == boss, "Cutscene target must be the boss!"
assert game.cutscene_dmg > 0, "Cutscene damage must be calculated!"
assert len(game.cutscene_runes) == 5, f"Cutscene must receive 5 runes, got {len(game.cutscene_runes)}"
print(f"  [OK] Cutscene initiated! Boss: {boss.name}, Finisher Damage: {game.cutscene_dmg:.0f} HP")

# Advance cutscene frames and verify procedural stages
# Frame at t = 2.0s (3 rune slams stamped with pentagram lines)
game.cutscene_timer = 2.0
game.draw_5_glyph_cutscene(game.screen, 0.0)
cutscene_preview_path = os.path.join(artifact_dir, "cutscene_5_glyph_preview.png")
pygame.image.save(game.screen, cutscene_preview_path)
print(f"  [OK] Saved Cutscene Action Frame Preview to: {cutscene_preview_path}")

# Frame at t = 3.6s (Supernova flash and devastating typography)
game.cutscene_timer = 3.6
game.draw_5_glyph_cutscene(game.screen, 0.0)
supernova_preview_path = os.path.join(artifact_dir, "cutscene_supernova_preview.png")
pygame.image.save(game.screen, supernova_preview_path)
print(f"  [OK] Saved Cutscene Supernova Frame Preview to: {supernova_preview_path}")

# Finalize cutscene
game.end_5_glyph_cutscene()
assert game.state == 'PLAYING', f"Game state must return to PLAYING, got {game.state}"
assert boss.hp < initial_boss_hp, f"Boss must take devastating damage! Initial: {initial_boss_hp}, Current: {boss.hp}"
assert boss.is_frozen is True, "Boss must be locked in stasis after cataclysm finisher!"
assert boss.stun_timer >= 4.0, "Boss must receive 4+ second stun!"
print(f"  [OK] Boss took {int(initial_boss_hp - boss.hp)} damage and is paralyzed in stasis!")
assert ACHIEVEMENT_MANAGER.is_unlocked("wild_magic_unleashed"), "Achievement 'wild_magic_unleashed' unlocked!"

print("\n=== ALL EXPANDED 5-GLYPH COMBO & CINEMATIC CUTSCENE TESTS PASSED 100%! ===")
