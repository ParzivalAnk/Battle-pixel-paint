import os
import pygame
import sys

# Ensure headless video driver for testing
os.environ["SDL_VIDEODRIVER"] = "dummy"

from main import Game, VIEW_WIDTH, VIEW_HEIGHT, MAP_WIDTH, MAP_HEIGHT
from difficulty import DIFFICULTY_MANAGER

print("=== STARTING NEW HUD LAYOUT VERIFICATION ===")

pygame.init()
pygame.font.init()

game = Game()
game.state = 'PLAYING'

# 1. Test Boss Info Text on Floor 1
game.load_floor(0)
f1_boss = game.get_boss_info_text()
print(f"Floor 1 Boss info: {f1_boss}")
assert f1_boss is not None, "Floor 1 should have a boss/leader identified!"

# 2. Test Boss Info Text on Floor 2 (Grand Inquisitor Malchor)
game.load_floor(1)
f2_boss = game.get_boss_info_text()
print(f"Floor 2 Boss info: {f2_boss}")
assert "Верховный Инквизитор Малхор" in f2_boss or "Малхор" in f2_boss, f"Expected Malchor on Floor 2, got {f2_boss}"

# 3. Test Boss Info Text on Floor 50 (Judge of Truth)
game.load_floor(49)
f50_boss = game.get_boss_info_text()
print(f"Floor 50 Boss info: {f50_boss}")
assert "Верховный Судия Истины" in f50_boss, f"Expected Judge of Truth on Floor 50, got {f50_boss}"

# 4. Render HUD on Floor 2 Wave 1 (Normal wave)
game.load_floor(1)
game.screen.fill((16, 20, 28))
# Render game HUD
game.draw_hud(game.screen)

artifact_dir = r"C:\Users\Parzi\.gemini\antigravity\brain\e1863129-f3a8-499f-bf5e-d134defe1c6c"
os.makedirs(artifact_dir, exist_ok=True)
screenshot_path = os.path.join(artifact_dir, "new_hud_layout_preview.png")
pygame.image.save(game.screen, screenshot_path)
print(f"[OK] Saved HUD screenshot to: {screenshot_path}")

# 5. Spawn Boss Wave (Floor 2 Wave 3) and verify active boss
game.spawn_wave(2)
active_boss_info = game.get_boss_info_text()
print(f"Wave 3 Active Boss info: {active_boss_info}")
assert "Верховный Инквизитор Малхор" in active_boss_info

# Render boss wave frame
game.screen.fill((20, 16, 24))
game.draw_hud(game.screen)
screenshot_boss_path = os.path.join(artifact_dir, "new_hud_boss_wave_preview.png")
pygame.image.save(game.screen, screenshot_boss_path)
print(f"[OK] Saved Boss wave HUD screenshot to: {screenshot_boss_path}")

print("=== ALL NEW HUD TESTS COMPLETED SUCCESSFULLY! ===")
