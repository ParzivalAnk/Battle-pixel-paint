"""
test_dev_glyph_studio_and_secret_code.py - Verification suite for Developer Glyph Studio,
Arrow-Key Precision Tracing, Auto-Smoothing Engine, and Secret Passcode Access.
"""

import os
import sys
import math
import json
import pygame

if hasattr(sys.stdout, 'reconfigure'):
    sys.stdout.reconfigure(encoding='utf-8')

# Set dummy video driver for headless execution
os.environ["SDL_VIDEODRIVER"] = "dummy"
pygame.init()
pygame.display.set_mode((1200, 800))

from config import VIEW_WIDTH, VIEW_HEIGHT
from game_engine import Game
from dev_glyph_studio import (
    DevGlyphStudio,
    DEV_SECRET_CODE,
    tidy_and_smooth_stroke,
    safe_get_clipboard_text,
    CUSTOM_GLYPHS_FILE,
)
import wild_magic

artifact_dir = r"C:\Users\Parzi\.gemini\antigravity\brain\e1863129-f3a8-499f-bf5e-d134defe1c6c"
os.makedirs(artifact_dir, exist_ok=True)


def run_tests():
    print("=== STARTING DEVELOPER GLYPH STUDIO & SECRET PASSCODE VERIFICATION ===")

    # =========================================================================
    # 1. TEST SECRET DEVELOPER ACCESS CODE MODAL
    # =========================================================================
    print("\n--- 1. Testing Secret Developer Passcode Authentication ---")
    game = Game()
    assert game.state == 'MAIN_MENU', f"Expected initial state MAIN_MENU, got {game.state}"
    assert game.dev_mode_unlocked is False, "Dev mode must start locked"

    # Verify required secret passcode constant
    expected_code = "antigravity-paintly-ParzivalAnk-1546p"
    assert DEV_SECRET_CODE == expected_code, f"Secret code must match '{expected_code}'"
    print(f"  [OK] Developer Passcode Verified: '{DEV_SECRET_CODE}'")

    # Simulate opening modal via ~ or F1
    game.secret_code_modal_active = True
    game.secret_code_input = "wrong-code-123"
    game.submit_secret_code()

    assert game.dev_mode_unlocked is False, "Dev mode must NOT unlock with wrong passcode"
    assert "НЕВЕРНЫЙ КОД" in game.secret_code_feedback, "Must show error feedback"
    print("  [OK] Invalid passcode correctly rejected!")

    # Render Secret Code Modal Preview
    game.render()
    modal_preview_path = os.path.join(artifact_dir, "secret_code_modal_preview.png")
    pygame.image.save(game.screen, modal_preview_path)
    print(f"  [OK] Saved Secret Code Modal Preview to: {modal_preview_path}")

    # Enter valid passcode
    game.secret_code_input = expected_code
    game.submit_secret_code()

    assert game.dev_mode_unlocked is True, "Dev mode MUST unlock with correct passcode!"
    assert game.state == 'DEV_GLYPH_STUDIO', f"State must switch to DEV_GLYPH_STUDIO, got {game.state}"
    assert game.secret_code_modal_active is False, "Modal must close on successful authentication"
    print("  [OK] Correct passcode accepted! Developer Mode Unlocked!")

    # Verify Main Menu now displays DEV button
    game.state = 'MAIN_MENU'
    game.render()
    assert "DEV_STUDIO" in game.menu_buttons or "SECRET_CODE" in game.menu_buttons
    main_menu_preview_path = os.path.join(artifact_dir, "main_menu_dev_unlocked_preview.png")
    pygame.image.save(game.screen, main_menu_preview_path)
    print(f"  [OK] Saved Main Menu with Dev Button Preview to: {main_menu_preview_path}")

    # =========================================================================
    # 2. TEST ARROW KEY VECTOR DRAWING MECHANISM
    # =========================================================================
    print("\n--- 2. Testing Arrow Key Precision Vector Tracing ---")
    studio = DevGlyphStudio(game)
    assert studio.grid_step == 20, "Default grid step should be 20px"

    # Start drawing at center
    cx, cy = studio.canvas_cx, studio.canvas_cy
    studio.pen_pos = [cx, cy]

    # Step 1: Pen Up movement (Repositioning to top apex without drawing)
    studio.pen_down = False
    studio.move_pen(0, -5)  # Move UP 100px (5 * 20px)
    assert studio.pen_pos[1] == cy - 100
    assert len(studio.raw_points) == 0, "Pen Up must not add points to stroke"
    print("  [OK] Pen Up successfully repositioned pen without drawing!")

    # Step 2: Toggle Pen Down
    studio.toggle_pen()
    assert studio.pen_down is True, "Pen must be in DOWN (drawing) mode"

    # Step 3: Draw a sharp equilateral diamond / chevron using arrow keys:
    # From top apex: DOWN-RIGHT -> DOWN-LEFT -> UP-LEFT -> UP-RIGHT (closed contour)
    # 1. DOWN-RIGHT 3 steps (dx=+3, dy=+3)
    studio.move_pen(3, 3)
    # 2. DOWN-LEFT 3 steps (dx=-3, dy=+3)
    studio.move_pen(-3, 3)
    # 3. UP-LEFT 3 steps (dx=-3, dy=-3)
    studio.move_pen(-3, -3)
    # 4. UP-RIGHT 3 steps (dx=+3, dy=-3) -> back to apex!
    studio.move_pen(3, -3)

    assert len(studio.raw_points) >= 4, f"Arrow keys must produce points, got {len(studio.raw_points)}"
    print(f"  [OK] Arrow keys generated {len(studio.raw_points)} precision grid vertices!")

    # Step 4: Test Undo
    prev_cnt = len(studio.raw_points)
    studio.undo()
    assert len(studio.raw_points) == prev_cnt - 1, "Undo [Z] must revert last segment"
    # Redo the step to close diamond
    studio.move_pen(3, -3)
    print("  [OK] Undo & Step Redo functions work as expected!")

    # =========================================================================
    # 3. TEST AUTO-SMOOTHING & RESAMPLING ENGINE
    # =========================================================================
    print("\n--- 3. Testing Auto-Smoothing & Resampling Engine ---")
    studio.is_closed = True
    studio.auto_smooth_and_tidy(silent=False)

    assert len(studio.smoothed_points) >= len(studio.raw_points), "Smoothed points must be generated"
    assert len(studio.normalized_64) == 64, f"Normalized points must contain exactly 64 points, got {len(studio.normalized_64)}"

    # Check normalization span and centroid
    xs = [p.x for p in studio.normalized_64]
    ys = [p.y for p in studio.normalized_64]
    assert (max(xs) - min(xs)) <= 100.1, f"X span exceeds 100: {max(xs) - min(xs)}"
    assert (max(ys) - min(ys)) <= 100.1, f"Y span exceeds 100: {max(ys) - min(ys)}"
    assert abs(sum(xs) / len(xs)) < 1.0, f"X centroid should be centered near 0: {sum(xs)/len(xs)}"
    assert abs(sum(ys) / len(ys)) < 1.0, f"Y centroid should be centered near 0: {sum(ys)/len(ys)}"
    print("  [OK] Auto-Smoothing normalized stroke into exact 64 equidistant points in [-50, 50] space!")

    # =========================================================================
    # 4. TEST LIVE SIMILARITY BENCHMARK AGAINST WILD MAGIC
    # =========================================================================
    print("\n--- 4. Testing Live Wild Magic Similarity Analysis ---")
    studio.evaluate_similarity()
    assert len(studio.similarity_matches) > 0, "Must return top pattern matches"
    top_match = studio.similarity_matches[0]
    print(f"  [OK] Top Match: {top_match['symbol']} {top_match['name']} ({top_match['percent']}% similarity)")

    # Save Dev Studio Canvas Preview
    studio.render(game.screen)
    studio_preview_path = os.path.join(artifact_dir, "dev_glyph_studio_canvas_preview.png")
    pygame.image.save(game.screen, studio_preview_path)
    print(f"  [OK] Saved Dev Glyph Studio Canvas Preview to: {studio_preview_path}")

    # =========================================================================
    # 5. TEST IN-STUDIO TRACING RITUAL TEST
    # =========================================================================
    print("\n--- 5. Testing In-Studio Tracing Ritual Test Mode ---")
    studio.start_test_ritual()
    assert studio.testing_ritual is True, "Ritual testing mode must be active"

    # Simulate realistic tracing stroke
    studio.test_drawn_points = [
        (studio.canvas_cx + p.x * 4.0, studio.canvas_cy + p.y * 4.0)
        for p in studio.normalized_64
    ]
    studio.evaluate_test_ritual()
    assert studio.test_completed is True, "Test ritual must be marked completed"
    assert studio.test_score >= 80, f"Expected high test accuracy, got {studio.test_score}%"
    print(f"  [OK] In-Studio Tracing Ritual Score: {studio.test_score:.0f}% Accuracy!")

    # Save Ritual Test Mode Preview
    studio.render(game.screen)
    test_ritual_preview_path = os.path.join(artifact_dir, "dev_glyph_studio_test_ritual_preview.png")
    pygame.image.save(game.screen, test_ritual_preview_path)
    print(f"  [OK] Saved Studio Ritual Tracing Preview to: {test_ritual_preview_path}")

    # =========================================================================
    # 6. TEST GLYPH PERSISTENCE & DYNAMIC GAME INTEGRATION
    # =========================================================================
    print("\n--- 6. Testing Persistence & Game Dynamic Registration ---")
    studio.glyph_id = "AURA_AEGIS_CRYSTAL"
    studio.glyph_name = "Кристальный Эгис Акулы"
    studio.glyph_symbol = "💠"
    studio.glyph_duration = 21.0
    studio.save_to_game()

    # Verify custom_wild_glyphs.json exists and contains glyph
    assert os.path.exists(CUSTOM_GLYPHS_FILE), f"{CUSTOM_GLYPHS_FILE} must be created"
    with open(CUSTOM_GLYPHS_FILE, "r", encoding="utf-8") as f:
        saved_data = json.load(f)
    assert "AURA_AEGIS_CRYSTAL" in saved_data, "Saved glyph must be present in JSON"
    print("  [OK] Glyph saved to custom_wild_glyphs.json successfully!")

    # Verify dynamic registry in wild_magic
    assert "AURA_AEGIS_CRYSTAL" in wild_magic.WILD_MAGIC_PATTERNS, "Glyph must be loaded into WILD_MAGIC_PATTERNS"
    registered_pat = wild_magic.WILD_MAGIC_PATTERNS["AURA_AEGIS_CRYSTAL"]
    assert registered_pat["duration"] == 21.0
    assert len(registered_pat["resampled"]) == 64
    print(f"  [OK] Registered '{registered_pat['name']}' ({registered_pat['symbol']}) directly into Wild Magic!")

    # Test Python snippet exporter
    studio.export_python_snippet()
    assert os.path.exists("exported_glyph.py"), "exported_glyph.py must be generated"
    with open("exported_glyph.py", "r", encoding="utf-8") as f:
        snippet_content = f.read()
    assert "AURA_AEGIS_CRYSTAL" in snippet_content
    print("  [OK] Python code generator successfully created clean snippet!")

    print("\n=== ALL DEVELOPER GLYPH STUDIO & SECRET PASSCODE TESTS PASSED 100%! ===")


if __name__ == "__main__":
    run_tests()
