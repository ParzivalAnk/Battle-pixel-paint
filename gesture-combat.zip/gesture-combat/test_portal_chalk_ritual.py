"""
test_portal_chalk_ritual.py
Tests and verifies the 10th-floor frame-by-frame chalk ritual and portal mechanics.
"""

import os
import sys
import math
import pygame

# Set dummy video driver for headless environments if needed
os.environ["SDL_VIDEODRIVER"] = "dummy"

import pygame
pygame.init()

from game_engine import Game
from art import draw_portal

def run_tests():
    print("=== STARTING PORTAL CHALK RITUAL TESTS ===")
    game = Game()
    
    # 1. Test Floor 0 (Floor 1, non-10th floor)
    game.load_floor(0)
    assert not game.is_tenth_floor_portal, "Floor 1 should NOT be a tenth-floor portal"
    assert not game.portal_active, "Portal should be inactive on fresh floor load"
    assert not game.portal_ritual_active, "Portal ritual should be inactive on fresh floor load"
    print("[OK] Regular floor (Floor 1) flag verified.")

    # 2. Test Floor 9 (Floor 10, tenth-floor portal)
    game.load_floor(9)
    assert game.is_tenth_floor_portal, "Floor 10 (idx 9) MUST have is_tenth_floor_portal == True"
    assert not game.portal_active
    print("[OK] 10th floor (Floor 10, idx 9) flag verified.")

    # 3. Test Floor 19 (Floor 20, tenth-floor portal)
    game.load_floor(19)
    assert game.is_tenth_floor_portal, "Floor 20 (idx 19) MUST have is_tenth_floor_portal == True"
    print("[OK] 20th floor (Floor 20, idx 19) flag verified.")

    # 4. Simulate Wave Completion on Floor 9 (10th floor)
    game.load_floor(9)
    game.state = 'PLAYING'
    game.current_wave_idx = len(game.current_floor_data["waves"]) - 1
    # Kill all enemies
    for en in game.enemies:
        en.alive = False
        en.hp = 0

    # Execute one game update tick
    game.update(0.016)

    assert game.portal_active, "Portal must be active after wave cleared"
    assert game.portal_ritual_active, "Portal ritual MUST be active on 10th floor wave clear"
    assert game.portal_ritual_timer >= 0.0, "Portal ritual timer must be initialized"
    print("[OK] 10th floor portal ritual activation verified.")

    # 5. Check Player collision gating: Player cannot enter before portal opens (t < 2.8s)
    game.player.x = game.portal_pos[0]
    game.player.y = game.portal_pos[1]
    game.portal_ritual_timer = 1.0  # Still in Phase 1 (Chalk drawing)
    game.update(0.016)
    assert game.state == 'PLAYING', "Player must NOT enter portal while chalk is still being drawn"
    print("[OK] Portal entry gated during ritual drawing phase.")

    # 6. Check Phase 1 -> Phase 2 transition (t = 1.6s)
    game.portal_ritual_timer = 1.59
    game.update(0.02)
    assert game.portal_ritual_timer >= 1.6, "Timer should cross Phase 2 threshold"
    print("[OK] Phase 2 (Chalk ignites electric blue) reached and updated.")

    # 7. Check Phase 2 -> Phase 3 transition (t = 2.8s)
    game.portal_ritual_timer = 2.79
    game.update(0.02)
    assert game.portal_ritual_timer >= 2.8, "Timer should cross Phase 3 threshold"
    print("[OK] Phase 3 (Dimensional portal erupts above glowing blue seal) reached.")

    # 8. Check Player enters portal once t >= 2.8s
    game.update(0.016)
    assert game.state == 'PERK_SELECTION', f"Player should enter portal after ritual completes, got state {game.state}"
    print("[OK] Player successfully enters completed 10th floor dimensional portal!")

    # 9. Verify visual rendering of all phases
    render_surf = pygame.Surface((200, 200), pygame.SRCALPHA)
    
    # Phase 1: Chalk (t = 0.8s)
    render_surf.fill((0, 0, 0, 0))
    draw_portal(render_surf, 100, 130, 0.0, art=game.art, is_tenth_floor=True, ritual_timer=0.8)
    assert render_surf.get_at((100, 130)) != (0, 0, 0, 0) or render_surf.get_bounding_rect().width > 0, "Phase 1 must render chalk pixels"

    # Phase 2: Electric blue glow (t = 2.2s)
    render_surf.fill((0, 0, 0, 0))
    draw_portal(render_surf, 100, 130, 0.0, art=game.art, is_tenth_floor=True, ritual_timer=2.2)
    assert render_surf.get_bounding_rect().width > 0, "Phase 2 must render glowing blue seal pixels"

    # Phase 3: Dimensional portal above seal (t = 3.5s)
    render_surf.fill((0, 0, 0, 0))
    draw_portal(render_surf, 100, 130, 0.0, art=game.art, is_tenth_floor=True, ritual_timer=3.5)
    assert render_surf.get_bounding_rect().width > 0, "Phase 3 must render portal and seal pixels"

    print("[OK] All 3 ritual visual phases rendered successfully without errors.")

    # 10. Composite comparison screenshot (Regular Portal vs 10th Floor 3 Phases)
    comp_surf = pygame.Surface((800, 240))
    comp_surf.fill((16, 20, 28))
    
    font = pygame.font.SysFont("arial", 16, bold=True)
    
    # Col 1: Regular Portal
    draw_portal(comp_surf, 100, 130, 1.0, art=game.art, is_tenth_floor=False)
    t1 = font.render("Regular Floor Portal", True, (200, 220, 255))
    comp_surf.blit(t1, (25, 205))

    # Col 2: 10th Floor Phase 1 (Chalk)
    draw_portal(comp_surf, 300, 140, 0.0, art=game.art, is_tenth_floor=True, ritual_timer=0.8)
    t2 = font.render("Phase 1: White Chalk", True, (240, 240, 255))
    comp_surf.blit(t2, (225, 205))

    # Col 3: 10th Floor Phase 2 (Blue Glow)
    draw_portal(comp_surf, 500, 140, 0.0, art=game.art, is_tenth_floor=True, ritual_timer=2.2)
    t3 = font.render("Phase 2: Blue Glow & Pillars", True, (80, 200, 255))
    comp_surf.blit(t3, (405, 205))

    # Col 4: 10th Floor Phase 3 (Portal + Seal)
    draw_portal(comp_surf, 700, 140, 0.0, art=game.art, is_tenth_floor=True, ritual_timer=3.5)
    t4 = font.render("Phase 3: Portal + Glowing Seal", True, (160, 240, 255))
    comp_surf.blit(t4, (605, 205))

    preview_path = "assets/anim_frames/portal_chalk/portal_comparison_preview.png"
    pygame.image.save(comp_surf, preview_path)
    print(f"[OK] Saved visual comparison preview to {preview_path}")

    print("=== ALL PORTAL CHALK RITUAL TESTS PASSED! ===")

if __name__ == "__main__":
    run_tests()
