import os
import sys
import json
import pygame

# Set dummy video driver for headless environment
os.environ["SDL_VIDEODRIVER"] = "dummy"

if hasattr(sys.stdout, 'reconfigure'):
    sys.stdout.reconfigure(encoding='utf-8')

import game_engine
from game_engine import Game
import hud
import menu
from dev_glyph_studio import DevGlyphStudio

def test_fullscreen_toggle_and_persistence():
    print("--- 1. Testing Fullscreen Toggle and Settings Persistence ---")
    settings_file = "settings.json"
    
    # Clean settings file before test
    if os.path.exists(settings_file):
        try:
            os.remove(settings_file)
        except Exception:
            pass

    game = Game()
    assert game.is_fullscreen is False, f"Expected initial is_fullscreen=False, got {game.is_fullscreen}"

    # Toggle to Fullscreen
    game.toggle_fullscreen()
    assert game.is_fullscreen is True, "Expected is_fullscreen=True after first toggle"
    assert os.path.exists(settings_file), "settings.json must exist after toggle"
    with open(settings_file, "r", encoding="utf-8") as f:
        data = json.load(f)
    assert data.get("fullscreen") is True, f"settings.json should have fullscreen=True, got {data}"
    print("[OK] Toggle to True persisted to settings.json successfully")

    # Toggle back to Windowed
    game.toggle_fullscreen()
    assert game.is_fullscreen is False, "Expected is_fullscreen=False after second toggle"
    with open(settings_file, "r", encoding="utf-8") as f:
        data = json.load(f)
    assert data.get("fullscreen") is False, f"settings.json should have fullscreen=False, got {data}"
    print("✓ Toggle to False persisted to settings.json successfully")

    # Re-instantiate game with settings having fullscreen: True
    with open(settings_file, "w", encoding="utf-8") as f:
        json.dump({"fullscreen": True}, f)
    game2 = Game()
    assert game2.is_fullscreen is True, "Game2 should load fullscreen=True from settings.json"
    print("✓ Game loads persisted fullscreen setting on launch")

    # Reset settings file to False
    game2.toggle_fullscreen()
    assert game2.is_fullscreen is False

def test_menu_rendering_and_buttons():
    print("--- 2. Testing Main Menu & Pause Menu Fullscreen UI ---")
    game = Game()
    surf = pygame.Surface((1200, 800))
    fonts = {
        "title": game.font_title,
        "large": game.font_large,
        "med": game.font_med,
        "small": game.font_small,
        "sym_large": game.font_sym_large,
        "sym_med": game.font_sym_med,
        "sym_small": game.font_sym_small
    }

    # Test draw_main_menu with is_fullscreen=False
    rects = menu.draw_main_menu(surf, 0.0, fonts, is_fullscreen=False)
    assert "FULLSCREEN" in rects, "draw_main_menu must return 'FULLSCREEN' rect"
    fs_rect = rects["FULLSCREEN"]
    assert fs_rect.width > 100 and fs_rect.height > 20
    print("✓ Main menu renders 'FULLSCREEN' button with is_fullscreen=False")

    # Test draw_main_menu with is_fullscreen=True
    rects_fs = menu.draw_main_menu(surf, 0.0, fonts, is_fullscreen=True)
    assert "FULLSCREEN" in rects_fs
    print("✓ Main menu renders 'FULLSCREEN' button with is_fullscreen=True")

    # Test draw_pause_menu
    game.state = 'PAUSED'
    game.is_fullscreen = False
    hud.draw_pause_menu(game, surf)
    assert "fullscreen" in game.pause_rects, "draw_pause_menu must register pause_rects['fullscreen']"
    pause_fs_rect = game.pause_rects["fullscreen"]
    assert pause_fs_rect.width > 200
    print("✓ Pause menu renders interactive fullscreen button and sets pause_rects['fullscreen']")

def test_hotkeys_and_click_handling():
    print("--- 3. Testing Hotkeys and Click Events ---")
    game = Game()
    game.is_fullscreen = False

    # Simulate F11 keydown event
    f11_event = pygame.event.Event(pygame.KEYDOWN, key=pygame.K_F11, mod=0)
    pygame.event.post(f11_event)
    game.handle_input()
    assert game.is_fullscreen is True, "F11 should toggle fullscreen to True"
    print("✓ F11 hotkey toggled fullscreen to True")

    # Simulate Alt+Enter keydown event
    alt_enter_event = pygame.event.Event(pygame.KEYDOWN, key=pygame.K_RETURN, mod=pygame.KMOD_ALT)
    pygame.event.post(alt_enter_event)
    game.handle_input()
    assert game.is_fullscreen is False, "Alt+Enter should toggle fullscreen to False"
    print("✓ Alt+Enter hotkey toggled fullscreen to False")

    # Simulate Main Menu button click
    game.state = 'MAIN_MENU'
    fonts = {
        "title": game.font_title,
        "large": game.font_large,
        "med": game.font_med,
        "small": game.font_small,
        "sym_large": game.font_sym_large,
        "sym_med": game.font_sym_med,
        "sym_small": game.font_sym_small
    }
    game.menu_buttons = menu.draw_main_menu(game.screen, 0.0, fonts, is_fullscreen=game.is_fullscreen)
    btn_center = game.menu_buttons["FULLSCREEN"].center
    click_event = pygame.event.Event(pygame.MOUSEBUTTONDOWN, pos=btn_center, button=1)
    pygame.event.post(click_event)
    game.handle_input()
    assert game.is_fullscreen is True, "Clicking Main Menu fullscreen button should toggle fullscreen to True"
    print("✓ Clicking Main Menu fullscreen button toggled fullscreen to True")

    # Simulate Pause Menu button click
    game.state = 'PAUSED'
    hud.draw_pause_menu(game, game.screen)
    pause_btn_center = game.pause_rects["fullscreen"].center
    click_pause = pygame.event.Event(pygame.MOUSEBUTTONDOWN, pos=pause_btn_center, button=1)
    pygame.event.post(click_pause)
    game.handle_input()
    assert game.is_fullscreen is False, "Clicking Pause Menu fullscreen button should toggle fullscreen to False"
    print("✓ Clicking Pause Menu fullscreen button toggled fullscreen to False")

def test_dev_studio_fullscreen():
    print("--- 4. Testing Dev Glyph Studio Fullscreen Support ---")
    game = Game()
    game.is_fullscreen = False
    studio = DevGlyphStudio(game)

    # Test F11 in Dev Studio
    f11_event = pygame.event.Event(pygame.KEYDOWN, key=pygame.K_F11, mod=0)
    studio.handle_event(f11_event)
    assert game.is_fullscreen is True, "Dev studio F11 should toggle fullscreen to True"
    print("✓ Dev Studio F11 toggled fullscreen to True")

    # Test Header button click in Dev Studio (button is at sw - 535, 15, 160, 36)
    studio.render(game.screen)
    sw = game.screen.get_width()
    fs_click_pos = (sw - 535 + 50, 15 + 18)
    click_event = pygame.event.Event(pygame.MOUSEBUTTONDOWN, pos=fs_click_pos, button=1)
    studio.handle_event(click_event)
    assert game.is_fullscreen is False, "Dev studio header button click should toggle fullscreen to False"
    print("✓ Dev Studio header button click toggled fullscreen to False")

def test_resolution_presets_and_2k_centering():
    print("--- 5. Testing FHD (1920x1080) / 2K (2560x1440) / HD (1280x720) Resolution Cycling ---")
    settings_file = "settings.json"
    if os.path.exists(settings_file):
        try:
            os.remove(settings_file)
        except Exception:
            pass

    game = Game()
    assert game.resolution_key == "FHD", f"Expected default resolution 'FHD', got {game.resolution_key}"
    assert game.screen.get_size() == (1920, 1080), f"Expected 1920x1080 surface, got {game.screen.get_size()}"
    print("✓ Default resolution is native FHD (1920x1080)")

    # Cycle to 2K via F10 hotkey
    f10_event = pygame.event.Event(pygame.KEYDOWN, key=pygame.K_F10, mod=0)
    pygame.event.post(f10_event)
    game.handle_input()
    assert game.resolution_key == "2K", f"Expected '2K' after F10, got {game.resolution_key}"
    assert game.screen.get_size() == (2560, 1440), f"Expected 2560x1440 surface, got {game.screen.get_size()}"
    # Verify 2K camera horizontally centers the 2200px arena: -(2560 - 2200) // 2 = -180
    assert game.cam_x == -180, f"Expected centered 2K cam_x=-180, got {game.cam_x}"
    print("✓ F10 switched to 2K (2560x1440) and centered arena camera (cam_x=-180)")

    # Cycle to HD via Pause Menu button click
    game.state = 'PAUSED'
    hud.draw_pause_menu(game, game.screen)
    assert "resolution" in game.pause_rects, "Pause menu must include 'resolution' button rect"
    res_btn_center = game.pause_rects["resolution"].center
    pygame.event.post(pygame.event.Event(pygame.MOUSEBUTTONDOWN, pos=res_btn_center, button=1))
    game.handle_input()
    assert game.resolution_key == "HD", f"Expected 'HD' after clicking pause resolution button, got {game.resolution_key}"
    assert game.screen.get_size() == (1280, 720), f"Expected 1280x720 surface, got {game.screen.get_size()}"
    print("✓ Pause Menu resolution button cycled to HD (1280x720)")

    # Cycle back to FHD via Main Menu button click
    game.state = 'MAIN_MENU'
    fonts = {
        "title": game.font_title,
        "large": game.font_large,
        "med": game.font_med,
        "small": game.font_small,
        "sym_large": game.font_sym_large,
        "sym_med": game.font_sym_med,
        "sym_small": game.font_sym_small
    }
    game.menu_buttons = menu.draw_main_menu(
        game.screen, 0.0, fonts,
        is_fullscreen=game.is_fullscreen,
        resolution_name=game.resolution_key
    )
    assert "RESOLUTION" in game.menu_buttons, "Main menu must include 'RESOLUTION' button rect"
    pygame.event.post(pygame.event.Event(pygame.MOUSEBUTTONDOWN, pos=game.menu_buttons["RESOLUTION"].center, button=1))
    game.handle_input()
    assert game.resolution_key == "FHD", f"Expected 'FHD' after Main Menu click, got {game.resolution_key}"
    assert game.screen.get_size() == (1920, 1080)
    print("✓ Main Menu resolution button cycled back to FHD (1920x1080) and saved to settings.json")

if __name__ == "__main__":
    test_fullscreen_toggle_and_persistence()
    test_menu_rendering_and_buttons()
    test_hotkeys_and_click_handling()
    test_dev_studio_fullscreen()
    test_resolution_presets_and_2k_centering()
    print("\n==========================================")
    print("ALL FULLSCREEN & FHD/2K TESTS PASSED!")
    print("==========================================")
