"""
tutorial.py - Interactive Dojo Training Quests & Animated Ghost Trajectory Guide for GLYPH-BLADE.
Provides step-by-step interactive lessons, animated glyph stroke trajectories,
in-world ethereal projections, and real-time combat feedback in the Training Dojo.
"""

import math
import random
import pygame

# =============================================================================
# COLOR THEMES & PALETTES
# =============================================================================
COLOR_BG_PANEL = (14, 18, 28, 238)
COLOR_BG_CARD = (22, 28, 42, 240)
COLOR_BG_PREVIEW = (10, 13, 20, 255)
COLOR_BORDER_GOLD = (255, 215, 60)
COLOR_BORDER_CYAN = (80, 225, 255)
COLOR_BORDER_MUTED = (45, 60, 85)
COLOR_TEXT_WHITE = (240, 245, 255)
COLOR_TEXT_GOLD = (255, 220, 60)
COLOR_TEXT_CYAN = (90, 230, 255)
COLOR_TEXT_GREEN = (100, 245, 140)
COLOR_TEXT_RED = (255, 80, 80)
COLOR_TEXT_PURPLE = (220, 120, 255)
COLOR_TEXT_MUTED = (140, 160, 190)

# =============================================================================
# CANONICAL GLYPH TRAJECTORY WAYPOINTS (Normalized 0..100 space)
# =============================================================================
GUIDE_TRAJECTORIES = {
    "SLASH_H": {
        "name": "Пространственный Срез",
        "symbol": "—",
        "description": "Телепортирующий разрез сквозь ткань пространства.",
        "color": (120, 240, 255),
        "points": [(15.0, 50.0), (85.0, 50.0)],
        "steps": [
            "1. Зажми ЛКМ или ПКМ слева",
            "2. Быстро проведи линию вправо [—]",
            "3. Отпусти кнопку мыши"
        ],
        "tactics": "Мгновенно наносит урон всем врагам на линии среза."
    },
    "SLASH_V": {
        "name": "Падение Метеорита",
        "symbol": "|",
        "description": "Обрушивает раскаленный астероид с небес в точку прицела.",
        "color": (255, 110, 40),
        "points": [(50.0, 15.0), (50.0, 85.0)],
        "steps": [
            "1. Зажми ЛКМ/ПКМ в верхней точке",
            "2. Проведи вертикальную линию вниз [|]",
            "3. Отпусти кнопку мыши"
        ],
        "tactics": "Наносит x2.5 крит по замороженным врагам (SHATTER)!"
    },
    "PARRY": {
        "name": "Ледяной Стазис",
        "symbol": "V",
        "description": "Замуровывает врага в монолитную ледяную глыбу льда.",
        "color": (140, 230, 255),
        "points": [(20.0, 25.0), (50.0, 75.0), (80.0, 25.0)],
        "steps": [
            "1. Начни чертить вверху слева",
            "2. Опусти линию вниз в центр",
            "3. Резко подними вправо вверх [V]"
        ],
        "tactics": "Полностью парализует цель, подготавливая ее к дробящему удару."
    },
    "UPPERCUT": {
        "name": "Инфернальный Разлом",
        "symbol": "^",
        "description": "Волна яростного пламени вырывается из земли конусом.",
        "color": (255, 170, 40),
        "points": [(20.0, 75.0), (50.0, 25.0), (80.0, 75.0)],
        "steps": [
            "1. Начни снизу слева",
            "2. Проведи линию вверх в вершину",
            "3. Опусти вправо вниз [^]"
        ],
        "tactics": "Поджигает плоть врагов и сочетается с воронкой в огненный вихрь."
    },
    "CIRCLE": {
        "name": "Сингулярность Бездны",
        "symbol": "O",
        "description": "Создает Черную Дыру, стягивающую всех врагов в центр.",
        "color": (190, 90, 255),
        "points": [
            (50.0 + 34.0 * math.cos(-math.pi / 2 + (2 * math.pi * i / 16)),
             50.0 + 34.0 * math.sin(-math.pi / 2 + (2 * math.pi * i / 16)))
            for i in range(17)
        ],
        "steps": [
            "1. Начни в верхней точке круга",
            "2. Проведи окружность по часовой стрелке",
            "3. Замкни контур в начальной точке [O]"
        ],
        "tactics": "Идеально стягивает группы монстров перед мощным AoE ударом."
    },
    "SHIELD_BLOCK": {
        "name": "Блок Бастиона / Slo-Mo",
        "symbol": "🛡",
        "description": "Стойка щита. Блокирует урон и включает Slo-Mo x5 на 3 сек!",
        "color": (255, 220, 60),
        "points": [
            (25.0, 25.0),
            (75.0, 25.0),
            (75.0, 55.0),
            (50.0, 85.0),
            (25.0, 55.0),
            (25.0, 25.0)
        ],
        "steps": [
            "1. Проведи верхнюю планку вправо",
            "2. Опустись вниз и сойдись в острие внизу",
            "3. Поднимись вверх и замкни контур щита"
        ],
        "tactics": "Замедляет мир в 5 раз! Дает время начертить сложнейшие комбо."
    },
    "HOURGLASS_SWAP": {
        "name": "Теневая Рокировка",
        "symbol": "⌛",
        "description": "Меняет тебя и врага местами. Ты заходишь в спину (BACKSTAB x3)!",
        "color": (210, 100, 255),
        "points": [
            (25.0, 22.0),
            (75.0, 22.0),
            (25.0, 78.0),
            (75.0, 78.0),
            (25.0, 22.0)
        ],
        "steps": [
            "1. Верхняя планка вправо",
            "2. Диагональ в левый нижний угол",
            "3. Нижняя планка вправо и диагональ вверх"
        ],
        "tactics": "Враг бьет в пустоту, а ты наносишь +200% урона в уязвимую спину!"
    },
    "STAR_PENTAGRAM": {
        "name": "Звезда Катаклизма",
        "symbol": "★",
        "description": "Пятиконечная печать судного дня. Колоссальный взрыв на арену!",
        "color": (255, 60, 60),
        "points": [
            (50.0, 12.0),
            (78.0, 85.0),
            (15.0, 38.0),
            (85.0, 38.0),
            (22.0, 85.0),
            (50.0, 12.0)
        ],
        "steps": [
            "1. Из вершины проведи в правый низ",
            "2. В левый верх -> горизонтально в правый верх",
            "3. В левый низ -> замкни обратно в вершину"
        ],
        "tactics": "Ультимативное заклинание! Дает +15 сек таймера выживания."
    },
    "SHATTER": {
        "name": "Осколочный Раскол (Shatter)",
        "symbol": "❄+☄",
        "description": "Сначала заморозь цель знаком [V], затем разбей Метеоритом [|]!",
        "color": (140, 240, 255),
        "is_composite": True,
        "sub_keys": ["PARRY", "SLASH_V"],
        "steps": [
            "1. Нарисуй [V] и заморозь манекен",
            "2. Пока манекен во льду, начерти [|]",
            "3. Лед расколется со взрывом (x2.5 CRIT)!"
        ],
        "tactics": "Связка Заморозка + Метеорит — главное оружие против толстокожих врагов."
    }
}

# =============================================================================
# TUTORIAL QUEST CLASS
# =============================================================================
class TutorialQuest:
    def __init__(self, qid, title, category, short_desc, instruction, target_count=1, glyph_key=None, lore_tip=""):
        self.id = qid
        self.title = title
        self.category = category
        self.short_desc = short_desc
        self.instruction = instruction
        self.target_count = target_count
        self.current_count = 0
        self.glyph_key = glyph_key
        self.lore_tip = lore_tip
        self.completed = False

    def reset(self):
        self.current_count = 0
        self.completed = False

    def set_progress(self, current):
        if self.completed:
            return False
        self.current_count = min(self.target_count, current)
        if self.current_count >= self.target_count:
            self.completed = True
            return True
        return False

    def add_progress(self, amount=1):
        return self.set_progress(self.current_count + amount)


# =============================================================================
# TUTORIAL MANAGER
# =============================================================================
class TutorialManager:
    def __init__(self):
        self.quests = self._build_quest_list()
        self.active_idx = 0
        self.panel_collapsed = False
        self.show_ghost_trajectory = True
        self.celebration_timer = 0.0
        self.toast_text = ""
        self.toast_timer = 0.0
        self.toast_color = COLOR_TEXT_GOLD
        self.all_completed_notified = False

        # Live tracking stats
        self.tracking_data = {
            "move_time": 0.0,
            "shatter_count": 0,
            "slo_mo_count": 0,
            "swap_count": 0,
            "weapons_switched": set(),
            "altar_opened": False
        }

    def _build_quest_list(self):
        return [
            TutorialQuest(
                qid="move",
                title="1. Движение WASD",
                category="БАЗОВЫЕ НАВЫКИ",
                short_desc="Подвигайся на WASD (2 сек)",
                instruction="Используй клавиши [W, A, S, D] или стрелки для перемещения. Курсор мыши задает направление взгляда.",
                target_count=2,
                glyph_key=None,
                lore_tip="• Постоянное движение спасает жизнь: держи дистанцию и уклоняйся от атак!"
            ),
            TutorialQuest(
                qid="slash_h",
                title="2. Пространственный Срез [—]",
                category="БАЗОВЫЙ ГЛИФ",
                short_desc="Начерти горизонтальную линию [—]",
                instruction="Зажми ЛКМ или ПКМ и быстро проведи горизонтальную линию слева направо [—], затем отпусти.",
                target_count=1,
                glyph_key="SLASH_H",
                lore_tip="• Срез мгновенно телепортирует клинок сквозь пространство, поражая цели на линии."
            ),
            TutorialQuest(
                qid="slash_v",
                title="3. Падение Метеорита [|]",
                category="БАЗОВЫЙ ГЛИФ",
                short_desc="Начерти вертикальную линию сверху вниз [|]",
                instruction="Зажми ЛКМ/ПКМ и проведи вертикальную линию сверху вниз [|]. Обрушивает раскаленный астероид.",
                target_count=1,
                glyph_key="SLASH_V",
                lore_tip="• Метеорит наносит мощный AoE урон и дробит замороженных врагов на осколки!"
            ),
            TutorialQuest(
                qid="frost_v",
                title="4. Ледяной Стазис [V]",
                category="КОНТРОЛЬ",
                short_desc="Начерти галочку [V] для заморозки",
                instruction="Зажми ЛКМ/ПКМ и нарисуй галочку [V] (вниз-вправо, затем вверх-вправо). Замораживает манекен во льду!",
                target_count=1,
                glyph_key="PARRY",
                lore_tip="• Замороженный враг полностью обездвижен и становится уязвим к дробящим ударам."
            ),
            TutorialQuest(
                qid="shatter",
                title="5. Осколочный Раскол (Shatter)",
                category="СТИХИЙНОЕ СЛИЯНИЕ",
                short_desc="Заморозь цель [V], затем разбей Метеоритом [|]",
                instruction="Сначала наложи Ледяной Стазис [V], а пока манекен во льду — обрушь на него Падение Метеорита [|]!",
                target_count=1,
                glyph_key="SHATTER",
                lore_tip="• Раскол наносит x2.5 критический урон и разбрасывает ледяные осколки вокруг."
            ),
            TutorialQuest(
                qid="vortex_o",
                title="6. Сингулярность Бездны [O]",
                category="СТЯЖКА ВРАГОВ",
                short_desc="Начерти круг по часовой стрелке [O]",
                instruction="Зажми ЛКМ/ПКМ и нарисуй замкнутый круг [O]. Создает Черную Дыру, стягивающую всех врагов в центр!",
                target_count=1,
                glyph_key="CIRCLE",
                lore_tip="• Черная дыра не дает врагам атаковать и концентрирует их под AoE взрыв."
            ),
            TutorialQuest(
                qid="shield_block",
                title="7. Бастион & Замедление (Slo-Mo)",
                category="ЗАЩИТА И ВРЕМЯ",
                short_desc="Начерти контур щита для включения Slo-Mo",
                instruction="Начерти форму щита: верхняя планка, боковины и острие внизу. Блокирует урон и включает Slo-Mo x5!",
                target_count=1,
                glyph_key="SHIELD_BLOCK",
                lore_tip="• Slo-Mo замедляет мир в 5 раз на 3.2 сек — идеальный момент начертить сложные заклинания!"
            ),
            TutorialQuest(
                qid="hourglass_swap",
                title="8. Теневая Рокировка [Рокировка]",
                category="ТАКТИКА БОЯ",
                short_desc="Начерти песочные часы для захода в спину",
                instruction="Нарисуй песочные часы: верх, диагональ, низ, диагональ вверх. Ты мгновенно окажешься за спиной манекена!",
                target_count=1,
                glyph_key="HOURGLASS_SWAP",
                lore_tip="• Удар в спину (BACKSTAB) наносит тройной критический урон (+200%)!"
            ),
            TutorialQuest(
                qid="weapon_switch",
                title="9. Арсенал и Смена Оружия",
                category="УПРАВЛЕНИЕ АРСЕНАЛОМ",
                short_desc="Переключи оружие клавишами [1], [2] или [3]",
                instruction="Нажми клавишу [1], [2] или [3] на клавиатуре для выбора активного клинка в арсенале.",
                target_count=1,
                glyph_key=None,
                lore_tip="• Разное оружие меняет скорость бега, урон и бонусы (вампиризм, крит, инерцию)."
            ),
            TutorialQuest(
                qid="combo_altar",
                title="10. Алтарь Синтеза & Звезда",
                category="ВЫСШАЯ МАГИЯ",
                short_desc="Открой Алтарь на [C] или начерти Звезду",
                instruction="Нажми клавишу [C] для открытия Гримуара Синтеза комбо, ИЛИ нарисуй 5-конечную Звезду Катаклизма [★]!",
                target_count=1,
                glyph_key="STAR_PENTAGRAM",
                lore_tip="• В Алтаре [C] можно составить цепочку из 3-5 знаков и запечатать разрушительное комбо на [F]!"
            )
        ]

    def reset(self):
        for q in self.quests:
            q.reset()
        self.active_idx = 0
        self.all_completed_notified = False
        self.celebration_timer = 0.0
        self.toast_timer = 0.0
        self.tracking_data = {
            "move_time": 0.0,
            "shatter_count": 0,
            "slo_mo_count": 0,
            "swap_count": 0,
            "weapons_switched": set(),
            "altar_opened": False
        }

    def get_active_quest(self):
        if 0 <= self.active_idx < len(self.quests):
            return self.quests[self.active_idx]
        return self.quests[0]

    def get_completed_count(self):
        return sum(1 for q in self.quests if q.completed)

    def is_all_completed(self):
        return self.get_completed_count() == len(self.quests)

    def select_quest(self, idx):
        if 0 <= idx < len(self.quests):
            self.active_idx = idx

    def next_quest(self):
        self.active_idx = (self.active_idx + 1) % len(self.quests)

    def prev_quest(self):
        self.active_idx = (self.active_idx - 1) % len(self.quests)

    def show_toast(self, text, color=COLOR_TEXT_GOLD, duration=3.5):
        self.toast_text = text
        self.toast_color = color
        self.toast_timer = duration

    def _check_quest_complete(self, quest, fx, sfx):
        if quest.completed:
            fx.add_screen_shake(12.0)
            sfx.play("crit")
            self.show_toast(f"★ УРОК ВЫПОЛНЕН: {quest.title}! ★", COLOR_TEXT_GREEN)

            # Auto advance to next incomplete quest
            for i in range(len(self.quests)):
                next_i = (self.active_idx + 1 + i) % len(self.quests)
                if not self.quests[next_i].completed:
                    self.active_idx = next_i
                    break

            if self.is_all_completed() and not self.all_completed_notified:
                self.all_completed_notified = True
                self.celebration_timer = 8.0
                fx.add_screen_shake(25.0)
                sfx.play("crit")
                self.show_toast("🏆 КУРС ДОДЗЁ УСПЕШНО ЗАВЕРШЕН! ТЫ ГОТОВ К БИТВАМ!", COLOR_TEXT_GOLD, 6.0)

    # -------------------------------------------------------------------------
    # EVENT HOOKS
    # -------------------------------------------------------------------------
    def on_player_move(self, dt, is_moving, fx, sfx):
        if is_moving:
            q = self.quests[0] # Move quest
            if not q.completed:
                self.tracking_data["move_time"] += dt
                sec = int(self.tracking_data["move_time"])
                if q.set_progress(sec):
                    self._check_quest_complete(q, fx, sfx)

    def on_glyph_cast(self, skill_id, score, tier, fx, sfx):
        active_q = self.get_active_quest()

        # Map skill_id to quest checks
        glyph_to_qid = {
            "SLASH_H": "slash_h",
            "SLASH_V": "slash_v",
            "PARRY": "frost_v",
            "CIRCLE": "vortex_o",
            "SHIELD_BLOCK": "shield_block",
            "HOURGLASS_SWAP": "hourglass_swap",
            "STAR_PENTAGRAM": "combo_altar"
        }

        target_qid = glyph_to_qid.get(skill_id)
        if target_qid:
            for q in self.quests:
                if q.id == target_qid and not q.completed:
                    if q.add_progress(1):
                        self._check_quest_complete(q, fx, sfx)
                    break

    def on_shatter(self, fx, sfx):
        q = next((quest for quest in self.quests if quest.id == "shatter"), None)
        if q and not q.completed:
            if q.add_progress(1):
                self._check_quest_complete(q, fx, sfx)

    def on_slo_mo(self, fx, sfx):
        q = next((quest for quest in self.quests if quest.id == "shield_block"), None)
        if q and not q.completed:
            if q.add_progress(1):
                self._check_quest_complete(q, fx, sfx)

    def on_swap(self, fx, sfx):
        q = next((quest for quest in self.quests if quest.id == "hourglass_swap"), None)
        if q and not q.completed:
            if q.add_progress(1):
                self._check_quest_complete(q, fx, sfx)

    def on_weapon_switch(self, slot, fx, sfx):
        q = next((quest for quest in self.quests if quest.id == "weapon_switch"), None)
        if q and not q.completed:
            self.tracking_data["weapons_switched"].add(slot)
            if q.add_progress(1):
                self._check_quest_complete(q, fx, sfx)

    def on_altar_open(self, fx, sfx):
        q = next((quest for quest in self.quests if quest.id == "combo_altar"), None)
        if q and not q.completed:
            if q.add_progress(1):
                self._check_quest_complete(q, fx, sfx)

    def update(self, dt):
        if self.toast_timer > 0:
            self.toast_timer = max(0.0, self.toast_timer - dt)
        if self.celebration_timer > 0:
            self.celebration_timer = max(0.0, self.celebration_timer - dt)

    # -------------------------------------------------------------------------
    # INTERACTIVE CLICK HANDLING
    # -------------------------------------------------------------------------
    def handle_click(self, pos):
        """Processes mouse click on interactive tutorial UI. Returns True if handled."""
        if self.panel_collapsed:
            # Check collapsed bar click
            bar_rect = pygame.Rect(20, 58, 480, 36)
            if bar_rect.collidepoint(pos):
                self.panel_collapsed = False
                return True
            return False

        panel_rect = pygame.Rect(20, 58, 335, 715)
        if not panel_rect.collidepoint(pos):
            return False

        # 1. Collapse toggle button
        btn_collapse = pygame.Rect(325, 68, 22, 22)
        if btn_collapse.collidepoint(pos):
            self.panel_collapsed = True
            return True

        # 2. Quest items list (Y: 120 to 380)
        list_y = 122
        item_h = 25
        for idx in range(len(self.quests)):
            item_rect = pygame.Rect(28, list_y + idx * item_h, 318, item_h - 2)
            if item_rect.collidepoint(pos):
                self.select_quest(idx)
                return True

        # 3. Navigation & Toggle Buttons at bottom of active card
        btn_prev = pygame.Rect(30, 728, 85, 30)
        btn_next = pygame.Rect(122, 728, 85, 30)
        btn_ghost = pygame.Rect(214, 728, 132, 30)

        if btn_prev.collidepoint(pos):
            self.prev_quest()
            return True
        if btn_next.collidepoint(pos):
            self.next_quest()
            return True
        if btn_ghost.collidepoint(pos):
            self.show_ghost_trajectory = not self.show_ghost_trajectory
            return True

        return True # Absorbed by panel background

    # -------------------------------------------------------------------------
    # DRAWING TRAJECTORY BOX (Animated High-Fidelity Ghost Guide)
    # -------------------------------------------------------------------------
    def draw_trajectory_box(self, surface, rect, glyph_info, anim_time, fonts):
        """Renders animated ghost stroke trajectory with arrow chevrons, start/finish, and traveling spark."""
        # Box background & slate border
        pygame.draw.rect(surface, COLOR_BG_PREVIEW, rect, border_radius=6)
        pygame.draw.rect(surface, (35, 48, 70), rect, 1, border_radius=6)

        # Subtle dark coordinate grid
        gx_step = rect.width // 4
        gy_step = rect.height // 4
        for i in range(1, 4):
            pygame.draw.line(surface, (20, 26, 38), (rect.x + i * gx_step, rect.y + 4), (rect.x + i * gx_step, rect.bottom - 4), 1)
            pygame.draw.line(surface, (20, 26, 38), (rect.x + 4, rect.y + i * gy_step), (rect.right - 4, rect.y + i * gy_step), 1)

        if not glyph_info or "points" not in glyph_info:
            no_txt = fonts["small"].render("Действие клавишами / Не требует знака", True, COLOR_TEXT_MUTED)
            surface.blit(no_txt, (rect.centerx - no_txt.get_width() // 2, rect.centery - no_txt.get_height() // 2))
            return

        points = glyph_info["points"]
        theme_col = glyph_info.get("color", COLOR_TEXT_CYAN)

        # Convert normalized 0..100 points to screen coords with padding
        pad_x = 22
        pad_y = 16
        inner_w = rect.width - pad_x * 2
        inner_h = rect.height - pad_y * 2

        screen_pts = []
        for ux, uy in points:
            sx = rect.x + pad_x + (ux / 100.0) * inner_w
            sy = rect.y + pad_y + (uy / 100.0) * inner_h
            screen_pts.append((sx, sy))

        if len(screen_pts) < 2:
            return

        # 1. Base Ethereal Outer Glow Lines
        glow_surf = pygame.Surface((rect.width, rect.height), pygame.SRCALPHA)
        local_pts = [(p[0] - rect.x, p[1] - rect.y) for p in screen_pts]
        pygame.draw.lines(glow_surf, (theme_col[0], theme_col[1], theme_col[2], 65), False, local_pts, 8)
        pygame.draw.lines(glow_surf, (theme_col[0], theme_col[1], theme_col[2], 160), False, local_pts, 4)
        surface.blit(glow_surf, (rect.x, rect.y))

        # 2. Crisp Core Line
        pygame.draw.lines(surface, (255, 255, 255), False, screen_pts, 2)

        # 3. Directional Chevrons / Arrowheads along segments
        for i in range(len(screen_pts) - 1):
            p1 = screen_pts[i]
            p2 = screen_pts[i + 1]
            seg_len = math.hypot(p2[0] - p1[0], p2[1] - p1[1])
            if seg_len > 18.0:
                mx = (p1[0] + p2[0]) * 0.5
                my = (p1[1] + p2[1]) * 0.5
                dx = (p2[0] - p1[0]) / seg_len
                dy = (p2[1] - p1[1]) / seg_len
                nx = -dy
                ny = dx
                arr_sz = 6.0
                a1 = (mx - dx * arr_sz + nx * (arr_sz * 0.8), my - dy * arr_sz + ny * (arr_sz * 0.8))
                a2 = (mx + dx * 2.0, my + dy * 2.0)
                a3 = (mx - dx * arr_sz - nx * (arr_sz * 0.8), my - dy * arr_sz - ny * (arr_sz * 0.8))
                pygame.draw.polygon(surface, (255, 255, 255), [a1, a2, a3])
                pygame.draw.polygon(surface, theme_col, [a1, a2, a3], 1)

        # 4. START Node (Green with pulsing halo)
        start_pt = screen_pts[0]
        pulse = 0.5 + 0.5 * math.sin(anim_time * 5.0)
        halo_r = int(7 + 3 * pulse)
        pygame.draw.circle(surface, (60, 240, 120, 100), (int(start_pt[0]), int(start_pt[1])), halo_r, 1)
        pygame.draw.circle(surface, (60, 240, 120), (int(start_pt[0]), int(start_pt[1])), 5)
        pygame.draw.circle(surface, (255, 255, 255), (int(start_pt[0]), int(start_pt[1])), 2)

        start_lbl = fonts["small"].render("СТАРТ", True, (100, 255, 150))
        surface.blit(start_lbl, (int(start_pt[0]) - start_lbl.get_width() // 2, int(start_pt[1]) - 16))

        # 5. FINISH Node (Ruby with border)
        end_pt = screen_pts[-1]
        pygame.draw.circle(surface, (255, 60, 70), (int(end_pt[0]), int(end_pt[1])), 5)
        pygame.draw.circle(surface, (255, 255, 255), (int(end_pt[0]), int(end_pt[1])), 2)
        end_lbl = fonts["small"].render("ФИНИШ", True, (255, 120, 120))
        surface.blit(end_lbl, (int(end_pt[0]) - end_lbl.get_width() // 2, int(end_pt[1]) + 6))

        # 6. Animated Traveling Spark (Looped motion across segments)
        total_len = 0.0
        seg_lengths = []
        for i in range(len(screen_pts) - 1):
            d = math.hypot(screen_pts[i+1][0] - screen_pts[i][0], screen_pts[i+1][1] - screen_pts[i][1])
            seg_lengths.append(d)
            total_len += d

        if total_len > 0:
            # Loop traveling spark
            spark_speed = 0.85
            t_loop = (anim_time * spark_speed) % 1.0
            cur_dist = t_loop * total_len

            accum = 0.0
            spark_x, spark_y = screen_pts[0]
            for i, slen in enumerate(seg_lengths):
                if accum + slen >= cur_dist:
                    seg_t = (cur_dist - accum) / max(0.001, slen)
                    spark_x = screen_pts[i][0] + seg_t * (screen_pts[i+1][0] - screen_pts[i][0])
                    spark_y = screen_pts[i][1] + seg_t * (screen_pts[i+1][1] - screen_pts[i][1])
                    break
                accum += slen

            # Render comet head & trailing sparks
            pygame.draw.circle(surface, (255, 240, 140), (int(spark_x), int(spark_y)), 6)
            pygame.draw.circle(surface, (255, 255, 255), (int(spark_x), int(spark_y)), 3)

    # -------------------------------------------------------------------------
    # IN-WORLD ETHEREAL PROJECTION (Runic ground hologram near player)
    # -------------------------------------------------------------------------
    def draw_in_world_projection(self, surface, cam_x, cam_y, player, anim_time, fonts):
        """Renders an ethereal magical glyph projection directly onto the arena floor near player."""
        if not self.show_ghost_trajectory or self.is_all_completed():
            return

        active_q = self.get_active_quest()
        if not active_q or not active_q.glyph_key or active_q.completed:
            return

        glyph_info = GUIDE_TRAJECTORIES.get(active_q.glyph_key)
        if not glyph_info or "points" not in glyph_info:
            return

        # Position hologram 130px in front of player
        aim_rad = getattr(player, 'aim_angle', 0.0)
        proj_world_x = player.x + math.cos(aim_rad) * 135.0
        proj_world_y = player.y + math.sin(aim_rad) * 135.0

        sx = int(proj_world_x - cam_x)
        sy = int(proj_world_y - cam_y)

        # Check viewport culling
        if sx < -100 or sx > surface.get_width() + 100 or sy < -100 or sy > surface.get_height() + 100:
            return

        proj_radius = 56
        holo_surf = pygame.Surface((proj_radius * 2 + 10, proj_radius * 2 + 10), pygame.SRCALPHA)
        hcx = proj_radius + 5
        hcy = proj_radius + 5

        # Glowing runic circle
        theme_col = glyph_info.get("color", COLOR_TEXT_CYAN)
        pulse = 0.5 + 0.5 * math.sin(anim_time * 3.5)
        alpha_base = int(110 + 60 * pulse)

        pygame.draw.circle(holo_surf, (theme_col[0], theme_col[1], theme_col[2], 28), (hcx, hcy), proj_radius)
        pygame.draw.circle(holo_surf, (theme_col[0], theme_col[1], theme_col[2], alpha_base), (hcx, hcy), proj_radius, 2)
        pygame.draw.circle(holo_surf, (255, 255, 255, alpha_base // 2), (hcx, hcy), proj_radius - 8, 1)

        # Project glyph points into holo surface
        inner_sz = proj_radius * 1.3
        pts = []
        for ux, uy in glyph_info["points"]:
            px = hcx - inner_sz * 0.5 + (ux / 100.0) * inner_sz
            py = hcy - inner_sz * 0.5 + (uy / 100.0) * inner_sz
            pts.append((px, py))

        if len(pts) >= 2:
            pygame.draw.lines(holo_surf, (theme_col[0], theme_col[1], theme_col[2], int(alpha_base * 0.8)), False, pts, 4)
            pygame.draw.lines(holo_surf, (255, 255, 255, alpha_base), False, pts, 2)
            # Start node
            pygame.draw.circle(holo_surf, (100, 255, 140, 220), (int(pts[0][0]), int(pts[0][1])), 4)
            # End node
            pygame.draw.circle(holo_surf, (255, 75, 75, 220), (int(pts[-1][0]), int(pts[-1][1])), 4)

        surface.blit(holo_surf, (sx - hcx, sy - hcy))

        # Floating label
        hint_str = f"Нарисуй: [{glyph_info['symbol']}] {glyph_info['name']}"
        h_surf = fonts["small"].render(hint_str, True, (255, 235, 120))
        surface.blit(h_surf, (sx - h_surf.get_width() // 2, sy - proj_radius - 18))

    # -------------------------------------------------------------------------
    # MAIN DOJO TUTORIAL HUD RENDERING
    # -------------------------------------------------------------------------
    def draw_dojo_tutorial(self, surface, anim_time, fonts, mouse_pos=None):
        """Renders the complete training quest panel & active lesson HUD."""
        w, h = surface.get_width(), surface.get_height()
        m_pos = mouse_pos if mouse_pos is not None else pygame.mouse.get_pos()

        # =====================================================================
        # 1. COLLAPSED MINI-BAR MODE
        # =====================================================================
        if self.panel_collapsed:
            bar_w = 520
            bar_h = 36
            bar_rect = pygame.Rect(20, 58, bar_w, bar_h)
            is_hov = bar_rect.collidepoint(m_pos)

            pygame.draw.rect(surface, (14, 18, 28, 230), bar_rect, border_radius=6)
            pygame.draw.rect(surface, COLOR_BORDER_GOLD if is_hov else COLOR_BORDER_MUTED, bar_rect, 1, border_radius=6)

            cur_q = self.get_active_quest()
            q_txt = f"[TAB] 📜 ОБУЧЕНИЕ: {cur_q.title} — {cur_q.short_desc} [РАЗВЕРНУТЬ ▾]"
            t_surf = fonts["med"].render(q_txt, True, COLOR_TEXT_GOLD if is_hov else COLOR_TEXT_CYAN)
            surface.blit(t_surf, (bar_rect.centerx - t_surf.get_width() // 2, bar_rect.centery - t_surf.get_height() // 2))
            return

        # =====================================================================
        # 2. EXPANDED FULL QUEST PANEL (Left screen side)
        # =====================================================================
        panel_w = 345
        panel_h = 712
        panel_rect = pygame.Rect(20, 58, panel_w, panel_h)

        # Dark atmospheric slate background
        bg_surf = pygame.Surface((panel_w, panel_h), pygame.SRCALPHA)
        bg_surf.fill((12, 16, 26, 240))
        surface.blit(bg_surf, (panel_rect.x, panel_rect.y))
        pygame.draw.rect(surface, COLOR_BORDER_MUTED, panel_rect, 1, border_radius=8)

        # Header bar
        header_rect = pygame.Rect(panel_rect.x, panel_rect.y, panel_w, 38)
        pygame.draw.rect(surface, (20, 26, 38), header_rect, border_top_left_radius=8, border_top_right_radius=8)
        pygame.draw.rect(surface, COLOR_BORDER_GOLD, header_rect, 1, border_top_left_radius=8, border_top_right_radius=8)

        sym_f = fonts.get("sym_med", fonts["med"])
        sym_sm = fonts.get("sym_small", fonts["small"])

        head_ic = sym_f.render("⚔ ", True, COLOR_TEXT_GOLD)
        head_txt = fonts["med"].render("ОБУЧАЮЩИЕ КВЕСТЫ ДОДЗЁ", True, COLOR_TEXT_GOLD)
        hx = header_rect.x + 14
        hy = header_rect.centery - head_txt.get_height() // 2
        surface.blit(head_ic, (hx, hy))
        surface.blit(head_txt, (hx + head_ic.get_width(), hy))

        # Collapse button
        btn_collapse = pygame.Rect(panel_rect.right - 28, panel_rect.y + 8, 20, 20)
        hov_col = btn_collapse.collidepoint(m_pos)
        pygame.draw.rect(surface, (40, 50, 70) if hov_col else (25, 32, 45), btn_collapse, border_radius=4)
        c_sym = sym_sm.render("✕", True, COLOR_TEXT_WHITE if hov_col else COLOR_TEXT_MUTED)
        surface.blit(c_sym, (btn_collapse.centerx - c_sym.get_width() // 2, btn_collapse.centery - c_sym.get_height() // 2))

        # Overall Progress Bar
        completed_c = self.get_completed_count()
        total_c = len(self.quests)
        prog_ratio = completed_c / float(total_c)

        prog_txt = fonts["small"].render(f"Прогресс: {completed_c} / {total_c} выполнено ({int(prog_ratio * 100)}%)", True, COLOR_TEXT_WHITE)
        surface.blit(prog_txt, (panel_rect.x + 14, header_rect.bottom + 8))

        pbar_rect = pygame.Rect(panel_rect.x + 14, header_rect.bottom + 26, panel_w - 28, 8)
        pygame.draw.rect(surface, (25, 32, 45), pbar_rect, border_radius=4)
        if completed_c > 0:
            fill_w = int(pbar_rect.width * prog_ratio)
            pygame.draw.rect(surface, (80, 235, 120), (pbar_rect.x, pbar_rect.y, fill_w, pbar_rect.height), border_radius=4)

        # ---------------------------------------------------------------------
        # Quest List (Y: 122 to 376)
        # ---------------------------------------------------------------------
        start_y = header_rect.bottom + 40
        item_h = 24
        for idx, q in enumerate(self.quests):
            iy = start_y + idx * item_h
            i_rect = pygame.Rect(panel_rect.x + 8, iy, panel_w - 16, item_h - 2)
            is_active = (idx == self.active_idx)
            is_hov = i_rect.collidepoint(m_pos)

            # Item background
            if is_active:
                pygame.draw.rect(surface, (30, 42, 65), i_rect, border_radius=4)
                pygame.draw.rect(surface, COLOR_BORDER_GOLD, i_rect, 1, border_radius=4)
            elif is_hov:
                pygame.draw.rect(surface, (24, 32, 48), i_rect, border_radius=4)

            # Status Icon
            if q.completed:
                badge = sym_sm.render("✓", True, COLOR_TEXT_GREEN)
            elif is_active:
                pulse = 0.5 + 0.5 * math.sin(anim_time * 6.0)
                badge_col = (255, int(200 + 55 * pulse), 60)
                badge = fonts["small"].render("►", True, badge_col)
            else:
                badge = fonts["small"].render("•", True, COLOR_TEXT_MUTED)

            surface.blit(badge, (i_rect.x + 8, i_rect.centery - badge.get_height() // 2))

            # Title
            t_col = COLOR_TEXT_GREEN if q.completed else (COLOR_TEXT_GOLD if is_active else (COLOR_TEXT_WHITE if is_hov else COLOR_TEXT_MUTED))
            t_surf = fonts["small"].render(q.title, True, t_col)
            surface.blit(t_surf, (i_rect.x + 24, i_rect.centery - t_surf.get_height() // 2))

        # ---------------------------------------------------------------------
        # Active Quest Details Card (Y: 382 to 705)
        # ---------------------------------------------------------------------
        card_rect = pygame.Rect(panel_rect.x + 8, start_y + len(self.quests) * item_h + 6, panel_w - 16, 318)
        pygame.draw.rect(surface, (18, 24, 36), card_rect, border_radius=6)
        pygame.draw.rect(surface, (45, 60, 85), card_rect, 1, border_radius=6)

        cur_q = self.get_active_quest()

        # Category pill
        cat_surf = fonts["small"].render(f"[{cur_q.category}]", True, COLOR_TEXT_CYAN)
        surface.blit(cat_surf, (card_rect.x + 10, card_rect.y + 8))

        # Status text
        st_txt = "★ ВЫПОЛНЕНО ✓" if cur_q.completed else f"Цель: {cur_q.current_count} / {cur_q.target_count}"
        st_col = COLOR_TEXT_GREEN if cur_q.completed else COLOR_TEXT_GOLD
        st_surf = fonts["small"].render(st_txt, True, st_col)
        surface.blit(st_surf, (card_rect.right - st_surf.get_width() - 10, card_rect.y + 8))

        # Instruction text
        ins_y = card_rect.y + 28
        ins_lines = self._wrap_text(cur_q.instruction, fonts["small"], card_rect.width - 20)
        for line in ins_lines:
            ls = fonts["small"].render(line, True, COLOR_TEXT_WHITE)
            surface.blit(ls, (card_rect.x + 10, ins_y))
            ins_y += 16

        # Trajectory Preview Canvas (Y: ins_y + 4)
        prev_rect = pygame.Rect(card_rect.x + 10, ins_y + 4, card_rect.width - 20, 135)
        glyph_info = GUIDE_TRAJECTORIES.get(cur_q.glyph_key) if cur_q.glyph_key else None
        self.draw_trajectory_box(surface, prev_rect, glyph_info, anim_time, fonts)

        # Tactical Tip / Lore
        tip_y = prev_rect.bottom + 6
        tip_lines = self._wrap_text(cur_q.lore_tip, fonts["small"], card_rect.width - 20)
        for line in tip_lines:
            ts = fonts["small"].render(line, True, (255, 235, 120))
            surface.blit(ts, (card_rect.x + 10, tip_y))
            tip_y += 15

        # Navigation Bar at bottom of card
        btn_prev = pygame.Rect(card_rect.x + 8, card_rect.bottom - 36, 75, 28)
        btn_next = pygame.Rect(card_rect.x + 88, card_rect.bottom - 36, 75, 28)
        btn_ghost = pygame.Rect(card_rect.x + 168, card_rect.bottom - 36, card_rect.width - 176, 28)

        hov_p = btn_prev.collidepoint(m_pos)
        hov_n = btn_next.collidepoint(m_pos)
        hov_g = btn_ghost.collidepoint(m_pos)

        pygame.draw.rect(surface, (35, 45, 65) if hov_p else (24, 32, 46), btn_prev, border_radius=4)
        pygame.draw.rect(surface, (70, 90, 120), btn_prev, 1, border_radius=4)
        p_txt = fonts["small"].render("◄ Пред.", True, COLOR_TEXT_WHITE)
        surface.blit(p_txt, (btn_prev.centerx - p_txt.get_width() // 2, btn_prev.centery - p_txt.get_height() // 2))

        pygame.draw.rect(surface, (35, 45, 65) if hov_n else (24, 32, 46), btn_next, border_radius=4)
        pygame.draw.rect(surface, (70, 90, 120), btn_next, 1, border_radius=4)
        n_txt = fonts["small"].render("След. ►", True, COLOR_TEXT_WHITE)
        surface.blit(n_txt, (btn_next.centerx - n_txt.get_width() // 2, btn_next.centery - n_txt.get_height() // 2))

        g_bg = (30, 50, 40) if self.show_ghost_trajectory else (45, 30, 35)
        if hov_g:
            g_bg = (40, 65, 50) if self.show_ghost_trajectory else (60, 40, 45)
        pygame.draw.rect(surface, g_bg, btn_ghost, border_radius=4)
        g_border = COLOR_TEXT_GREEN if self.show_ghost_trajectory else (255, 90, 90)
        pygame.draw.rect(surface, g_border, btn_ghost, 1, border_radius=4)

        ghost_lbl = "Проекция [H]: ВКЛ" if self.show_ghost_trajectory else "Проекция [H]: ВЫКЛ"
        g_txt = fonts["small"].render(ghost_lbl, True, g_border)
        surface.blit(g_txt, (btn_ghost.centerx - g_txt.get_width() // 2, btn_ghost.centery - g_txt.get_height() // 2))

        # =====================================================================
        # 3. FLOATING COMPLETION BANNER / TOAST
        # =====================================================================
        if self.toast_timer > 0:
            alpha = min(255, int(self.toast_timer * 180))
            t_surf = fonts["med"].render(self.toast_text, True, self.toast_color)
            tw = t_surf.get_width() + 40
            th = 36
            tx = w // 2 - tw // 2
            ty = 48

            t_box = pygame.Surface((tw, th), pygame.SRCALPHA)
            t_box.fill((14, 18, 28, min(240, alpha)))
            pygame.draw.rect(t_box, (self.toast_color[0], self.toast_color[1], self.toast_color[2], alpha), (0, 0, tw, th), 1, border_radius=6)
            surface.blit(t_box, (tx, ty))
            surface.blit(t_surf, (w // 2 - t_surf.get_width() // 2, ty + 8))

    def _wrap_text(self, text, font, max_width):
        """Splits string into wrapped lines that fit within max_width."""
        words = text.split(" ")
        lines = []
        cur_line = ""
        for word in words:
            test_line = cur_line + (" " if cur_line else "") + word
            if font.size(test_line)[0] <= max_width:
                cur_line = test_line
            else:
                if cur_line:
                    lines.append(cur_line)
                cur_line = word
        if cur_line:
            lines.append(cur_line)
        return lines


# Global instance
TUTORIAL_MANAGER = TutorialManager()
