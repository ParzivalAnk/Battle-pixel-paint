import os
import math
import random
import pygame
from animations import load_or_generate_all_animations, load_or_generate_chalk_portal_frames

class ArtAssets:
    def __init__(self, width, height):
        self.width = width
        self.height = height

        # Load pixel art textures
        self.sprite_player = None
        self.sprite_golem = None
        self.sprite_inquisitor = None
        self.sprite_lich = None
        self.sprite_cultist = None
        self.tile_floor = None
        self.title_menu_bg = None
        self.sprite_shrine = None
        self.sprite_fountain = None
        self.sprite_sarcophagus = None
        self.sprite_alchemy = None
        self.sprite_barricade = None
        self.sprite_houses = None
        self.sprite_bench = None
        self.sprite_torch = None
        self.anims = {}
        self.portal_chalk_frames = []
        self._load_pixel_assets()

        # Dynamic lighting darkness mask
        self.light_mask = pygame.Surface((self.width, self.height), pygame.SRCALPHA)
        self.decals = []

    def _load_pixel_assets(self):
        try:
            if os.path.exists('assets/title_menu_bg.jpg'):
                raw_bg = pygame.image.load('assets/title_menu_bg.jpg').convert()
                self.title_menu_bg = pygame.transform.smoothscale(raw_bg, (1920, 1080))
            elif os.path.exists('assets/title_menu_bg.png'):
                raw_bg = pygame.image.load('assets/title_menu_bg.png').convert()
                self.title_menu_bg = pygame.transform.smoothscale(raw_bg, (1920, 1080))

            if os.path.exists('assets/player_tuned.png'):
                self.sprite_player = pygame.image.load('assets/player_tuned.png').convert_alpha()
            elif os.path.exists('assets/player.png'):
                self.sprite_player = pygame.image.load('assets/player.png').convert_alpha()

            if os.path.exists('assets/golem_giant.png'):
                self.sprite_golem = pygame.image.load('assets/golem_giant.png').convert_alpha()
            elif os.path.exists('assets/golem.png'):
                self.sprite_golem = pygame.image.load('assets/golem.png').convert_alpha()

            if os.path.exists('assets/inquisitor.png'):
                self.sprite_inquisitor = pygame.image.load('assets/inquisitor.png').convert_alpha()
            elif os.path.exists('assets/stalker.png'):
                self.sprite_inquisitor = pygame.image.load('assets/stalker.png').convert_alpha()

            if os.path.exists('assets/lich.png'):
                self.sprite_lich = pygame.image.load('assets/lich.png').convert_alpha()

            if os.path.exists('assets/cultist.png'):
                self.sprite_cultist = pygame.image.load('assets/cultist.png').convert_alpha()

            if os.path.exists('assets/floor.png'):
                self.tile_floor = pygame.image.load('assets/floor.png').convert()

            if os.path.exists('assets/decor_shrine.png'):
                self.sprite_shrine = pygame.image.load('assets/decor_shrine.png').convert_alpha()

            if os.path.exists('assets/decor_fountain.png'):
                self.sprite_fountain = pygame.image.load('assets/decor_fountain.png').convert_alpha()

            if os.path.exists('assets/decor_sarcophagus.png'):
                self.sprite_sarcophagus = pygame.image.load('assets/decor_sarcophagus.png').convert_alpha()

            if os.path.exists('assets/decor_alchemy.png'):
                raw_alchemy = pygame.image.load('assets/decor_alchemy.png').convert_alpha()
                self.sprite_alchemy = pygame.transform.smoothscale(raw_alchemy, (82, 66))

            if os.path.exists('assets/decor_barricade.png'):
                self.sprite_barricade = pygame.image.load('assets/decor_barricade.png').convert_alpha()
                self.sprites_barricade = {
                    'NORTH': self.sprite_barricade,
                    'SOUTH': pygame.transform.rotate(self.sprite_barricade, 180),
                    'WEST': pygame.transform.rotate(self.sprite_barricade, 90),
                    'EAST': pygame.transform.rotate(self.sprite_barricade, -90),
                }

            if os.path.exists('assets/decor_houses.png'):
                self.sprite_houses = pygame.image.load('assets/decor_houses.png').convert_alpha()
                self.sprites_houses = {
                    'NORTH': self.sprite_houses,
                    'SOUTH': pygame.transform.rotate(self.sprite_houses, 180),
                    'WEST': pygame.transform.rotate(self.sprite_houses, 90),
                    'EAST': pygame.transform.rotate(self.sprite_houses, -90),
                }

            if os.path.exists('assets/decor_bench.png'):
                self.sprite_bench = pygame.image.load('assets/decor_bench.png').convert_alpha()
                self.sprites_bench = {
                    'NORTH': self.sprite_bench,
                    'SOUTH': pygame.transform.rotate(self.sprite_bench, 180),
                    'WEST': pygame.transform.rotate(self.sprite_bench, 90),
                    'EAST': pygame.transform.rotate(self.sprite_bench, -90),
                }

            if os.path.exists('assets/decor_torch.png'):
                self.sprite_torch = pygame.image.load('assets/decor_torch.png').convert_alpha()

            # Load or generate 4-frame animations for player and all enemy archetypes
            base_dict = {
                "player": self.sprite_player,
                "golem": self.sprite_golem,
                "inquisitor": self.sprite_inquisitor,
                "cultist": self.sprite_cultist,
                "lich": self.sprite_lich,
            }
            self.anims = load_or_generate_all_animations(base_dict)

            # Load or generate 10th floor chalk ritual & glowing blue portal frames
            self.portal_chalk_frames = load_or_generate_chalk_portal_frames()
        except Exception as e:
            print(f"Asset loading info: {e}")

    def add_scorch_mark(self, x, y, radius=50):
        self.decals.append({'x': float(x), 'y': float(y), 'r': int(radius), 'type': 'scorch'})
        if len(self.decals) > 120:
            self.decals.pop(0)

    def add_blood_splatter(self, x, y, count=12):
        for _ in range(count):
            ox = x + random.randint(-35, 35)
            oy = y + random.randint(-35, 35)
            self.decals.append({'x': float(ox), 'y': float(oy), 'r': random.randint(3, 8), 'type': 'blood'})
        if len(self.decals) > 120:
            self.decals = self.decals[-120:]

    def render_decals(self, target_surface, offset_x, offset_y):
        tw, th = target_surface.get_size()
        for d in self.decals:
            dx = int(d['x'] + offset_x)
            dy = int(d['y'] + offset_y)
            if -80 <= dx <= tw + 80 and -80 <= dy <= th + 80:
                if d['type'] == 'scorch':
                    surf = pygame.Surface((d['r'] * 2, d['r'] * 2), pygame.SRCALPHA)
                    pygame.draw.circle(surf, (15, 12, 10, 160), (d['r'], d['r']), d['r'])
                    pygame.draw.circle(surf, (30, 20, 15, 120), (d['r'], d['r']), int(d['r'] * 0.6))
                    target_surface.blit(surf, (dx - d['r'], dy - d['r']))
                elif d['type'] == 'blood':
                    pygame.draw.circle(target_surface, (140, 15, 25), (dx, dy), d['r'])

    def render_lighting(self, target_surface, light_sources):
        tw, th = target_surface.get_size()
        if self.light_mask.get_size() != (tw, th):
            self.light_mask = pygame.Surface((tw, th), pygame.SRCALPHA)
        self.light_mask.fill((6, 8, 14, 225))
        for lx, ly, rad, color, intensity in light_sources:
            lx, ly = int(lx), int(ly)
            rad = int(rad)
            cookie = pygame.Surface((rad * 2, rad * 2), pygame.SRCALPHA)
            steps = 7
            for i in range(steps, 0, -1):
                frac = i / steps
                cur_r = int(rad * frac)
                alpha = int(255 * (1.0 - frac) * intensity)
                pygame.draw.circle(cookie, (color[0], color[1], color[2], alpha), (rad, rad), cur_r)
            self.light_mask.blit(cookie, (lx - rad, ly - rad), special_flags=pygame.BLEND_RGBA_SUB)
        target_surface.blit(self.light_mask, (0, 0))


def draw_player_character(surface, art, x, y, angle_rad, anim_time, weapon_color, is_fumbled, has_iframes, weapon_tier=2,
                          is_moving=False, is_casting=False, cast_timer=0.0, walk_time=0.0):
    x, y = int(x), int(y)

    # Rotating Runic Circle under feet matching weapon color
    rune_surf = pygame.Surface((64, 64), pygame.SRCALPHA)
    r_angle = anim_time * 2.5
    for i in range(4):
        a = r_angle + i * (math.pi / 2)
        rx = 32 + 20 * math.cos(a)
        ry = 32 + 20 * math.sin(a)
        pygame.draw.circle(rune_surf, (weapon_color[0], weapon_color[1], weapon_color[2], 130), (int(rx), int(ry)), 3)
    pygame.draw.circle(rune_surf, (weapon_color[0], weapon_color[1], weapon_color[2], 70), (32, 32), 22, 1)
    surface.blit(rune_surf, (x - 32, y - 32))

    # Divine White Aura (Tier 5) or Inferior Red/Orange Ember Aura (Tier 1)
    if weapon_tier == 5:
        # Brilliant Divine White Shimmer
        h_rad = int(24 + 5 * math.sin(anim_time * 6.0))
        pygame.draw.circle(surface, (255, 255, 255), (x, y), h_rad, 2)
        for i in range(4):
            sa = anim_time * 3.0 + i * (math.pi / 2)
            sx = x + int((h_rad + 5) * math.cos(sa))
            sy = y + int((h_rad + 5) * math.sin(sa))
            pygame.draw.circle(surface, (255, 255, 255), (sx, sy), 3)
    elif weapon_tier == 1:
        # Rusty Red-Orange Jagged Ember Ring
        h_rad = int(20 + 3 * math.sin(anim_time * 7.0))
        pygame.draw.circle(surface, (255, 75, 30), (x, y), h_rad, 1)

    # Select 4-frame animation based on player action state (Cast, Walk, Idle)
    p_anims = getattr(art, 'anims', {}).get('player', {})
    sp = None

    if is_casting or cast_timer > 0:
        c_frames = p_anims.get('cast', [])
        if c_frames:
            if cast_timer > 0:
                # Active release burst and recoil progression
                f_idx = min(3, max(0, int((1.0 - (cast_timer / 0.38)) * 4)))
            else:
                # Channeling / gesture drawing loop between gathering and surge
                f_idx = int(anim_time * 6.0) % 2
            sp = c_frames[f_idx]
    elif is_moving:
        w_frames = p_anims.get('walk', [])
        if w_frames:
            eff_wt = walk_time if walk_time > 0 else anim_time
            f_idx = int(eff_wt * 8.0) % 4
            sp = w_frames[f_idx]
    else:
        i_frames = p_anims.get('idle', [])
        if i_frames:
            f_idx = int(anim_time * 3.5) % 4
            sp = i_frames[f_idx]

    # Fallback to base static sprite if frames not available
    if not sp and art.sprite_player:
        sp = art.sprite_player

    if sp:
        if math.cos(angle_rad) < 0:
            sp = pygame.transform.flip(sp, True, False)
        sw, sh = sp.get_size()
        surface.blit(sp, (x - sw // 2, y - sh // 2))
    else:
        pygame.draw.circle(surface, (45, 55, 80), (x, y), 16)

    # Orbiting Weapon Focus
    w_orbit_angle = anim_time * 4.0
    orb_dist = 26 if weapon_tier < 5 else 30
    wx = x + int(orb_dist * math.cos(w_orbit_angle))
    wy = y + int(orb_dist * math.sin(w_orbit_angle))

    orb_r = 5 if weapon_tier < 4 else (7 if weapon_tier == 4 else 9)
    pygame.draw.circle(surface, weapon_color, (wx, wy), orb_r)
    pygame.draw.circle(surface, (255, 255, 255), (wx, wy), max(2, orb_r - 3))
    if weapon_tier == 5:
        # Cross sparkle on white divine weapon
        pygame.draw.line(surface, (255, 255, 255), (wx - 10, wy), (wx + 10, wy), 2)
        pygame.draw.line(surface, (255, 255, 255), (wx, wy - 10), (wx, wy + 10), 2)


def draw_enemy_sprite(surface, art, en, x, y, anim_time, angle_to_player):
    """Draws any enemy based on their sprite_base, scale, and tint using 4-frame animation."""
    x, y = int(x), int(y)
    scale = getattr(en, 'scale', 1.0)
    sprite_base = getattr(en, 'sprite_base', 'golem')
    tint = getattr(en, 'tint', (255, 255, 255))
    is_frozen = getattr(en, 'is_frozen', False)
    stun_timer = getattr(en, 'stun_timer', 0.0)

    # Shadow size depends on enemy scale
    shadow_w = int(48 * scale)
    shadow_h = int(18 * scale)
    pygame.draw.ellipse(surface, (8, 10, 15, 170), (x - shadow_w // 2, y + int(en.radius * 0.8), shadow_w, shadow_h))

    # Pick 4-frame animation based on state
    anims_dict = getattr(art, 'anims', {})
    lookup_base = "inquisitor" if sprite_base == "stalker" else sprite_base
    en_anims = anims_dict.get(lookup_base, anims_dict.get("golem", {}))

    sp = None
    if en_anims:
        is_boss = getattr(en, 'is_boss', False)
        if getattr(en, 'is_attacking', False) or getattr(en, 'windup_timer', 0.0) > 0:
            # 4-frame Attack / Cast / Slam cycle
            atk_frames = en_anims.get('attack', [])
            if atk_frames:
                max_w = 0.65 if is_boss else 0.85
                w_time = getattr(en, 'windup_timer', 0.0)
                f_idx = min(3, max(0, int((w_time / max(0.01, max_w)) * 4)))
                sp = atk_frames[f_idx]
        elif (math.hypot(getattr(en, 'vx', 0.0), getattr(en, 'vy', 0.0)) > 8 or getattr(en, 'walk_timer', 0.0) > 0) and not is_frozen and stun_timer <= 0:
            # 4-frame Walk / Run cycle
            walk_frames = en_anims.get('walk', [])
            if walk_frames:
                w_time = getattr(en, 'walk_timer', anim_time * 1.5)
                f_idx = int(w_time * 8.0) % 4
                sp = walk_frames[f_idx]
        else:
            # 4-frame Idle cycle
            idle_frames = en_anims.get('idle', [])
            if idle_frames:
                f_idx = int(anim_time * 3.5 + getattr(en, 'x', 0) * 0.01) % 4
                sp = idle_frames[f_idx]

    # Fallback to single static sprite if not found in animation dictionary
    if not sp:
        if sprite_base == "golem" and art.sprite_golem:
            sp = art.sprite_golem
        elif (sprite_base in ("inquisitor", "stalker")) and art.sprite_inquisitor:
            sp = art.sprite_inquisitor
        elif sprite_base == "lich" and art.sprite_lich:
            sp = art.sprite_lich
        elif sprite_base == "cultist" and art.sprite_cultist:
            sp = art.sprite_cultist
        elif art.sprite_inquisitor:
            sp = art.sprite_inquisitor

    if sp:
        sw, sh = sp.get_size()
        target_w = max(24, int(sw * (scale / (2.0 if sprite_base == "golem" else 1.0))))
        target_h = max(24, int(sh * (scale / (2.0 if sprite_base == "golem" else 1.0))))

        # Scale if needed
        scaled_sp = pygame.transform.scale(sp, (target_w, target_h))
        if math.cos(angle_to_player) < 0:
            scaled_sp = pygame.transform.flip(scaled_sp, True, False)

        # Tint effect for frozen or special factions
        if is_frozen:
            frozen_overlay = pygame.Surface((target_w, target_h), pygame.SRCALPHA)
            frozen_overlay.fill((140, 230, 255, 130))
            scaled_sp.blit(frozen_overlay, (0, 0), special_flags=pygame.BLEND_RGBA_MULT)
        elif tint != (255, 255, 255):
            tint_overlay = pygame.Surface((target_w, target_h), pygame.SRCALPHA)
            tint_overlay.fill((*tint, 255))
            scaled_sp.blit(tint_overlay, (0, 0), special_flags=pygame.BLEND_RGBA_MULT)

        surface.blit(scaled_sp, (x - target_w // 2, y - target_h // 2))
    else:
        # Fallback circle
        pygame.draw.circle(surface, tint, (x, y), en.radius)


def draw_obstacle(surface, obs, offset_x, offset_y, art=None, anim_time=0.0):
    """Draws stone pillars, altars, burning braziers, and detailed gothic decor structures."""
    ox = int(obs['x'] + offset_x)
    oy = int(obs['y'] + offset_y)
    r = obs['radius']
    obs_type = obs.get('type', 'PILLAR')

    if obs_type == 'SHRINE':
        # Gothic Runic Obelisk
        shrine_sp = getattr(art, 'sprite_shrine', None)
        if shrine_sp:
            sw, sh = shrine_sp.get_size()
            pygame.draw.ellipse(surface, (8, 10, 16, 200), (ox - sw // 2 + 10, oy - 6, sw - 20, 28))
            surface.blit(shrine_sp, (ox - sw // 2, oy - sh + 20))
        else:
            height = 80
            pygame.draw.ellipse(surface, (8, 10, 15, 180), (ox - r, oy + 10, r * 2, 24))
            pygame.draw.polygon(surface, (45, 50, 65), [(ox - r, oy), (ox + r, oy), (ox + r // 2, oy - height), (ox - r // 2, oy - height)])
            pygame.draw.polygon(surface, (70, 75, 95), [(ox - r // 2, oy - height), (ox + r // 2, oy - height), (ox, oy - height - 20)])
            pygame.draw.circle(surface, (140, 200, 255), (ox, oy - height // 2), 6)

    elif obs_type == 'FOUNTAIN':
        # Gargoyle Blood Fountain
        fountain_sp = getattr(art, 'sprite_fountain', None)
        if fountain_sp:
            sw, sh = fountain_sp.get_size()
            pygame.draw.ellipse(surface, (8, 10, 16, 210), (ox - sw // 2 + 6, oy - sh // 2 + 20, sw - 12, sh - 18))
            surface.blit(fountain_sp, (ox - sw // 2, oy - sh // 2))
            pulse = (math.sin(anim_time * 4.0) + 1.0) * 0.5
            pygame.draw.ellipse(surface, (255, 60, 60), (ox - 22, oy - 22, 44, 30), 1)
        else:
            pygame.draw.circle(surface, (40, 45, 55), (ox, oy), r)
            pygame.draw.circle(surface, (200, 30, 50), (ox, oy), int(r * 0.7))

    elif obs_type == 'SARCOPHAGUS':
        # Ancient Knight Crypt Tomb
        sarc_sp = getattr(art, 'sprite_sarcophagus', None)
        if sarc_sp:
            sw, sh = sarc_sp.get_size()
            pygame.draw.ellipse(surface, (8, 10, 16, 200), (ox - sw // 2 + 5, oy - sh // 2 + 18, sw - 10, sh - 20))
            surface.blit(sarc_sp, (ox - sw // 2, oy - sh // 2))
        else:
            w, h = int(r * 2.2), int(r * 1.6)
            pygame.draw.rect(surface, (36, 40, 52), (ox - w // 2, oy - h // 2, w, h))
            pygame.draw.rect(surface, (20, 22, 30), (ox - w // 2, oy - h // 2, w, h), 2)

    elif obs_type == 'ALCHEMY_TABLE':
        # Compact Alchemical Arcane Workbench
        alch_sp = getattr(art, 'sprite_alchemy', None)
        if alch_sp:
            sw, sh = alch_sp.get_size()
            pygame.draw.ellipse(surface, (8, 10, 16, 190), (ox - sw // 2 + 6, oy - sh // 2 + 12, sw - 12, sh - 16))
            surface.blit(alch_sp, (ox - sw // 2, oy - sh // 2))
            flicker = random.randint(-1, 1)
            pygame.draw.circle(surface, (255, 230, 120), (ox - int(sw * 0.31) + flicker, oy - int(sh * 0.29)), 2)
        else:
            w, h = int(r * 2.2), int(r * 1.4)
            pygame.draw.rect(surface, (55, 38, 28), (ox - w // 2, oy - h // 2, w, h))
            pygame.draw.circle(surface, (80, 255, 140), (ox, oy - 4), 5)

    elif obs_type == 'PILLAR':
        # Stone Pillar with 3D height
        height = 45
        pygame.draw.ellipse(surface, (8, 10, 15, 180), (ox - r - 4, oy - r // 2, (r + 4) * 2, r + 8))
        pygame.draw.rect(surface, (32, 36, 48), (ox - r, oy - height, r * 2, height))
        pygame.draw.rect(surface, (18, 22, 30), (ox - r, oy - height, r * 2, height), 2)
        pygame.draw.ellipse(surface, (55, 62, 80), (ox - r, oy - height - r // 2, r * 2, r))
        pygame.draw.ellipse(surface, (80, 90, 115), (ox - r, oy - height - r // 2, r * 2, r), 2)
        pygame.draw.line(surface, (100, 180, 255), (ox - 4, oy - height + 10), (ox + 4, oy - height + 24), 2)
        pygame.draw.circle(surface, (100, 180, 255), (ox, oy - height + 18), 3)

    elif obs_type == 'BRAZIER':
        # Gothic Forged Standing Torch Brazier (16-bit Pixel Art)
        torch_sp = getattr(art, 'sprite_torch', None)
        if torch_sp:
            tw, th = torch_sp.get_size()
            # 1. Base drop shadow on the stone floor
            pygame.draw.ellipse(surface, (8, 10, 16, 210), (ox - tw // 2 + 2, oy - 6, tw - 4, 18))
            # 2. Render 16-bit standing torch sprite
            surface.blit(torch_sp, (ox - tw // 2, oy - th + 8))
            
            # 3. Dynamic flickering fire core & rising pixel embers
            fire_cx = ox
            fire_cy = oy - th + 20
            flicker_x = math.sin(anim_time * 16.0 + ox * 0.4) * 1.5
            flicker_y = math.cos(anim_time * 20.0 + oy * 0.4) * 1.2
            
            # Inner hot ember glow
            pygame.draw.circle(surface, (255, 120, 20), (int(fire_cx + flicker_x), int(fire_cy + flicker_y)), 7)
            pygame.draw.circle(surface, (255, 210, 60), (int(fire_cx + flicker_x * 0.7), int(fire_cy + flicker_y * 0.7)), 4)
            pygame.draw.circle(surface, (255, 255, 200), (int(fire_cx), int(fire_cy - 1)), 2)
            
            # Floating pixel embers drifting upwards into the dark air
            for ei in range(3):
                e_seed = (ox * 37 + oy * 53 + ei * 107) % 1000
                e_prog = ((anim_time * 2.2 + e_seed * 0.001) % 1.0)
                em_y = int(fire_cy - 6 - e_prog * 24)
                em_x = int(fire_cx + math.sin(anim_time * 6.0 + ei * 2.3 + e_seed) * 5)
                if 0.05 < e_prog < 0.95:
                    col = (255, int(150 + 90 * (1.0 - e_prog)), int(40 + 40 * e_prog))
                    pygame.draw.rect(surface, col, (em_x, em_y, 2, 2))
        else:
            pygame.draw.ellipse(surface, (8, 10, 15, 160), (ox - r, oy + 4, r * 2, r))
            pygame.draw.polygon(surface, (45, 48, 58), [(ox - r, oy), (ox + r, oy), (ox + r // 2, oy + 18), (ox - r // 2, oy + 18)])
            for i in range(3):
                flame_h = random.randint(12, 22)
                flame_ox = ox + (i - 1) * 6
                pygame.draw.circle(surface, (255, 140, 30), (flame_ox, oy - flame_h // 2), 6)
                pygame.draw.circle(surface, (255, 230, 80), (flame_ox, oy - flame_h // 2), 3)

    elif obs_type == 'ALTAR':
        # Sacrificial Stone Altar
        w, h = r * 2, r
        pygame.draw.rect(surface, (38, 42, 54), (ox - w // 2, oy - h // 2, w, h))
        pygame.draw.rect(surface, (18, 20, 28), (ox - w // 2, oy - h // 2, w, h), 2)
        pygame.draw.circle(surface, (220, 40, 60), (ox, oy), 6)

    elif obs_type == 'BENCH_BARRICADE':
        # Stacked wooden benches barricade blocking city exit (oriented per district)
        district = obs.get('district', 'NORTH')
        bar_dict = getattr(art, 'sprites_barricade', None)
        bar_sp = bar_dict.get(district) if bar_dict else getattr(art, 'sprite_barricade', None)
        if bar_sp:
            bw, bh = bar_sp.get_size()
            pygame.draw.ellipse(surface, (6, 8, 12, 210), (ox - bw // 2 + 12, oy - bh // 2 + 12, bw - 24, bh - 24))
            surface.blit(bar_sp, (ox - bw // 2, oy - bh // 2))
        else:
            w, h = 100, 60
            pygame.draw.rect(surface, (45, 30, 20), (ox - w // 2, oy - h // 2, w, h))
            pygame.draw.rect(surface, (15, 10, 5), (ox - w // 2, oy - h // 2, w, h), 3)

    elif obs_type == 'BENCH':
        # Standalone wooden gothic street bench (oriented along sidewalk)
        district = obs.get('district', 'NORTH')
        bench_dict = getattr(art, 'sprites_bench', None)
        bench_sp = bench_dict.get(district) if bench_dict else getattr(art, 'sprite_bench', None)
        if bench_sp:
            bw, bh = bench_sp.get_size()
            pygame.draw.ellipse(surface, (6, 8, 12, 180), (ox - bw // 2 + 6, oy - bh // 2 + 8, bw - 12, bh - 14))
            surface.blit(bench_sp, (ox - bw // 2, oy - bh // 2))
        else:
            w, h = 48, 24
            pygame.draw.rect(surface, (60, 42, 28), (ox - w // 2, oy - h // 2, w, h))


def draw_arena_barrier(surface, width, height, offset_x, offset_y, anim_time, player_pos=None):
    """
    Renders an ornate, glowing magical runic barrier along the perimeter of the arena.
    Features:
    - Glowing neon boundary lines with rhythmic energy wave pulsation
    - Runic energy pylons / posts spaced along the perimeter
    - Corner anchor monoliths with crackling electric nodes
    - Dynamic interactive proximity wave: illuminates brighter and emits sparks when player approaches
    """
    x1 = int(offset_x + 50)
    y1 = int(offset_y + 50)
    x2 = int(offset_x + width - 50)
    y2 = int(offset_y + height - 50)
    bw = x2 - x1
    bh = y2 - y1

    # Check proximity to barrier for dynamic glow
    close_dist = 999.0
    impact_pt = None
    if player_pos:
        px, py = player_pos
        dl = abs(px - 50)
        dr = abs(px - (width - 50))
        dt = abs(py - 50)
        db = abs(py - (height - 50))
        min_d = min(dl, dr, dt, db)
        if min_d < 120:
            close_dist = min_d
            if min_d == dl: impact_pt = (x1, int(py + offset_y))
            elif min_d == dr: impact_pt = (x2, int(py + offset_y))
            elif min_d == dt: impact_pt = (int(px + offset_x), y1)
            else: impact_pt = (int(px + offset_x), y2)

    proximity_glow = max(0.0, 1.0 - (close_dist / 110.0))

    # 1. Base Boundary Lines
    base_pulse = 0.65 + 0.35 * math.sin(anim_time * 4.5)
    
    # Outer glow
    pygame.draw.rect(surface, (25, 70, 160), (x1 - 3, y1 - 3, bw + 6, bh + 6), 5)
    # Bright energetic core line
    core_brightness = min(255, int(180 + 75 * base_pulse + 50 * proximity_glow))
    core_col = (max(50, core_brightness // 2), core_brightness, 255)
    pygame.draw.rect(surface, core_col, (x1, y1, bw, bh), 2)
    # Inner energy shimmer line
    pygame.draw.rect(surface, (90, 180, 255), (x1 + 3, y1 + 3, bw - 6, bh - 6), 1)

    # 2. Runic Pylons / Energy Nodes along perimeter
    corners = [(x1, y1), (x2, y1), (x1, y2), (x2, y2)]
    for cx, cy in corners:
        p_pulse = 1.0 + 0.25 * math.sin(anim_time * 6.0 + (cx + cy) * 0.01)
        r_node = int(9 * p_pulse)
        pygame.draw.circle(surface, (15, 25, 45), (cx, cy), r_node + 4)
        pygame.draw.circle(surface, (60, 150, 255), (cx, cy), r_node, 2)
        pygame.draw.circle(surface, (210, 245, 255), (cx, cy), max(2, r_node - 4))

    # Perimeter intermediate posts (every 140 px)
    step = 140
    # Top & Bottom edges
    for sx in range(x1 + step, x2 - step // 2, step):
        t_phase = anim_time * 4.0 + sx * 0.02
        pulse = 0.5 + 0.5 * math.sin(t_phase)
        node_col = (int(80 + 120 * pulse), int(160 + 95 * pulse), 255)
        pygame.draw.circle(surface, node_col, (sx, y1), 4)
        pygame.draw.circle(surface, (220, 240, 255), (sx, y1), 2)

        b_pulse = 0.5 + 0.5 * math.sin(t_phase + 1.5)
        b_col = (int(80 + 120 * b_pulse), int(160 + 95 * b_pulse), 255)
        pygame.draw.circle(surface, b_col, (sx, y2), 4)
        pygame.draw.circle(surface, (220, 240, 255), (sx, y2), 2)

    # Left & Right edges
    for sy in range(y1 + step, y2 - step // 2, step):
        t_phase = anim_time * 4.0 + sy * 0.02
        l_pulse = 0.5 + 0.5 * math.sin(t_phase)
        l_col = (int(80 + 120 * l_pulse), int(160 + 95 * l_pulse), 255)
        pygame.draw.circle(surface, l_col, (x1, sy), 4)
        pygame.draw.circle(surface, (220, 240, 255), (x1, sy), 2)

        r_pulse = 0.5 + 0.5 * math.sin(t_phase + 2.0)
        r_col = (int(80 + 120 * r_pulse), int(160 + 95 * r_pulse), 255)
        pygame.draw.circle(surface, r_col, (x2, sy), 4)
        pygame.draw.circle(surface, (220, 240, 255), (x2, sy), 2)

    # 3. Dynamic Interactive Proximity Wave & Arcs
    if impact_pt and proximity_glow > 0.05:
        ix, iy = impact_pt
        ripple_r = int(24 + 32 * proximity_glow + 12 * math.sin(anim_time * 12.0))
        pygame.draw.circle(surface, (220, 245, 255), (ix, iy), ripple_r, 2)
        pygame.draw.circle(surface, (100, 200, 255), (ix, iy), max(4, ripple_r - 8), 1)
        for sp in range(4):
            ang = anim_time * 10.0 + sp * (math.pi / 2)
            arc_len = random.randint(10, 25)
            sp_x = ix + int(math.cos(ang) * arc_len)
            sp_y = iy + int(math.sin(ang) * arc_len)
            pygame.draw.line(surface, (255, 255, 255), (ix, iy), (sp_x, sp_y), 2)


def draw_city_perimeter(surface, width, height, offset_x, offset_y, art=None, anim_time=0.0):
    """
    Renders medieval gothic townhouses outside the barrier on all 4 sides,
    properly rotated so every district's facades and cobblestone sidewalks face the arena.
    """
    houses_sp = getattr(art, 'sprite_houses', None)
    if not houses_sp:
        return

    houses_dict = getattr(art, 'sprites_houses', None)
    sp_north = houses_dict.get('NORTH') if houses_dict else houses_sp
    sp_south = houses_dict.get('SOUTH') if houses_dict else pygame.transform.rotate(houses_sp, 180)
    sp_west = houses_dict.get('WEST') if houses_dict else pygame.transform.rotate(houses_sp, 90)
    sp_east = houses_dict.get('EAST') if houses_dict else pygame.transform.rotate(houses_sp, -90)

    # Symmetric X offsets for North & South rows (leaving center gate at width//2 and corners clean)
    horiz_x_offsets = [125, 395, 665, 1255, 1525, 1795]

    # North Border City Row (facades facing South into arena)
    north_y = int(offset_y - 140)
    for rx in horiz_x_offsets:
        surface.blit(sp_north, (int(offset_x + rx), north_y))

    # South Border City Row (rotated 180 deg: facades & sidewalk facing North into arena)
    south_y = int(offset_y + height - 100)
    for rx in horiz_x_offsets:
        surface.blit(sp_south, (int(offset_x + rx), south_y))

    # Symmetric Y offsets for West & East columns (leaving center gate at height//2 and corners clean)
    vert_y_offsets = [115, 385, 935, 1205]

    # West Border Houses (rotated 90 deg CCW: facades & sidewalk facing East into arena)
    west_x = int(offset_x - 140)
    for ry in vert_y_offsets:
        surface.blit(sp_west, (west_x, int(offset_y + ry)))

    # East Border Houses (rotated 90 deg CW: facades & sidewalk facing West into arena)
    east_x = int(offset_x + width - 100)
    for ry in vert_y_offsets:
        surface.blit(sp_east, (east_x, int(offset_y + ry)))


def draw_grimoire_lectern(surface, x, y, anim_time, offset_x, offset_y):
    """Draws an ancient glowing spellbook on a pedestal."""
    lx = int(x + offset_x)
    ly = int(y + offset_y)
    
    # Pedestal
    pygame.draw.rect(surface, (42, 48, 65), (lx - 12, ly - 10, 24, 28))
    pygame.draw.rect(surface, (20, 24, 34), (lx - 12, ly - 10, 24, 28), 2)
    
    # Floating open magical book
    float_y = ly - 28 + int(math.sin(anim_time * 3.5) * 4)
    # Open pages
    pygame.draw.polygon(surface, (240, 230, 200), [(lx, float_y + 4), (lx - 16, float_y - 6), (lx - 16, float_y + 8), (lx, float_y + 14)])
    pygame.draw.polygon(surface, (240, 230, 200), [(lx, float_y + 4), (lx + 16, float_y - 6), (lx + 16, float_y + 8), (lx, float_y + 14)])
    # Glowing magical aura
    pygame.draw.circle(surface, (120, 220, 255), (lx, float_y + 4), 18, 1)


def draw_portal(surface, x, y, anim_time, art=None, is_tenth_floor=False, ritual_timer=99.0):
    cx, cy = int(x), int(y)

    # 10th Floor: Frame-by-frame Chalk Ritual & Blue Igniting Portal above it!
    if is_tenth_floor and art and getattr(art, 'portal_chalk_frames', None):
        frames = art.portal_chalk_frames
        if len(frames) >= 12:
            if ritual_timer < 1.6:
                # Phase 1: Drawing chalk on the floor (Frames 0 to 3)
                f_idx = min(3, max(0, int((ritual_timer / 1.6) * 4)))
            elif ritual_timer < 2.8:
                # Phase 2: Chalk turns electric blue and glows (Frames 4 to 7)
                f_idx = 4 + min(3, max(0, int(((ritual_timer - 1.6) / 1.2) * 4)))
            else:
                # Phase 3: Dimensional portal hovers & swirls above the glowing blue seal (Frames 8 to 11)
                f_idx = 8 + int(anim_time * 8.0) % 4

            frame_surf = frames[f_idx]
            # Center of floor seal is at (100, 130) on 200x200 canvas
            surface.blit(frame_surf, (cx - 100, cy - 130))

            # Additional atmospheric radiant glow for 10th floor portal
            if ritual_timer >= 1.6:
                pulse = (math.sin(anim_time * 6.0) + 1.0) * 0.5
                ring_r = int(52 + pulse * 4)
                halo_surf = pygame.Surface((ring_r * 2 + 10, int(ring_r * 0.9) + 10), pygame.SRCALPHA)
                pygame.draw.ellipse(halo_surf, (40, 160, 255, int(60 + 50 * pulse)), (5, 5, ring_r * 2, int(ring_r * 0.85)), 2)
                surface.blit(halo_surf, (cx - ring_r - 5, cy - int(ring_r * 0.425) - 5))

            if ritual_timer >= 2.8:
                portal_y = cy - 65
                for i in range(4):
                    ray_angle = anim_time * 2.5 + i * (math.pi / 2)
                    rx = cx + int(38 * math.cos(ray_angle))
                    ry = portal_y + int(38 * math.sin(ray_angle))
                    pygame.draw.circle(surface, (200, 245, 255, 180), (rx, ry), 2)
            return

    # Regular floors (Default Portal)
    rad = int(38 + 6 * math.sin(anim_time * 4.0))
    portal_surf = pygame.Surface((rad * 2 + 10, rad * 2 + 10), pygame.SRCALPHA)
    for i in range(3):
        r_cur = rad - i * 8
        pygame.draw.circle(portal_surf, (80, 200, 255, 120 + i * 40), (rad + 5, rad + 5), r_cur, 3)
    surface.blit(portal_surf, (cx - rad - 5, cy - rad - 5))
    pygame.draw.circle(surface, (200, 240, 255), (cx, cy), 12)
