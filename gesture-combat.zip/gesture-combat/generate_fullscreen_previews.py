import os
import pygame

os.environ["SDL_VIDEODRIVER"] = "dummy"

from config import VIEW_WIDTH, VIEW_HEIGHT
from game_engine import Game
import hud
import menu
from dev_glyph_studio import DevGlyphStudio

def generate_previews():
    game = Game()
    artifact_dir = r"C:\Users\Parzi\Desktop\бэкап проекты антигравити\paint_remake\artifacts" if False else r"C:\Users\Parzi\.gemini\antigravity\brain\e1863129-f3a8-499f-bf5e-d134defe1c6c"
    os.makedirs(artifact_dir, exist_ok=True)

    fonts = {
        "title": game.font_title,
        "large": game.font_large,
        "med": game.font_med,
        "small": game.font_small,
        "sym_large": game.font_sym_large,
        "sym_med": game.font_sym_med,
        "sym_small": game.font_sym_small
    }

    # 1. Main Menu 16:9 Widescreen Preview (1280x720)
    surf_mm = pygame.Surface((VIEW_WIDTH, VIEW_HEIGHT))
    menu.draw_main_menu(surf_mm, 1.2, fonts, bg_image=game.art.title_menu_bg, dev_unlocked=True, is_fullscreen=False)
    p1 = os.path.join(artifact_dir, "main_menu_fullscreen_preview.png")
    pygame.image.save(surf_mm, p1)
    print(f"Saved: {p1}")

    # 2. In-Game Arena 16:9 Widescreen Preview with Full Lighting Mask (1280x720)
    # Demonstrates: 100% darkness coverage on right edge (NO light leak stripe) and natural 16:9 ratio
    game.state = 'PLAYING'
    game.is_fullscreen = False
    game.start_run()
    game.render()
    p_game = os.path.join(artifact_dir, "ingame_widescreen_lighting_preview.png")
    pygame.image.save(game.screen, p_game)
    print(f"Saved: {p_game}")

    # 3. Pause Menu 16:9 Widescreen Preview (1280x720)
    game.state = 'PAUSED'
    game.is_fullscreen = True
    game.render()
    p2 = os.path.join(artifact_dir, "pause_menu_fullscreen_preview.png")
    pygame.image.save(game.screen, p2)
    print(f"Saved: {p2}")

    # 4. Dev Glyph Studio 16:9 Widescreen Preview (1280x720)
    surf_dev = pygame.Surface((VIEW_WIDTH, VIEW_HEIGHT))
    game.is_fullscreen = False
    studio = DevGlyphStudio(game)
    studio.load_preset("CHRONO_HOURGLASS_KNOT")
    studio.render(surf_dev)
    p3 = os.path.join(artifact_dir, "dev_studio_fullscreen_preview.png")
    pygame.image.save(surf_dev, p3)
    print(f"Saved: {p3}")

if __name__ == "__main__":
    generate_previews()
