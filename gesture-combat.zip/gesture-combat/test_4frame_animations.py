"""
test_4frame_animations.py - Comprehensive verification of 4-frame animations
for player (walk, cast, idle) and enemies (walk, attack/slam/cast, idle).
"""

import os
import math
import pygame
import unittest

os.environ["SDL_VIDEODRIVER"] = "dummy"
pygame.init()
pygame.display.set_mode((1280, 720), pygame.NOFRAME)

from art import ArtAssets, draw_player_character, draw_enemy_sprite
from animations import load_or_generate_all_animations
from main import Player, Enemy

class Test4FrameAnimations(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.art = ArtAssets(1280, 720)
        cls.screen = pygame.Surface((1280, 720))

    def test_animation_structure_and_frame_counts(self):
        """Verify that every character archetype has exactly 4 frames per action."""
        self.assertIsNotNone(self.art.anims, "art.anims must be loaded")

        expected_archetypes = ["player", "golem", "inquisitor", "cultist", "lich", "stalker"]
        for arch in expected_archetypes:
            self.assertIn(arch, self.art.anims, f"Archetype '{arch}' must be present in art.anims")
            arch_data = self.art.anims[arch]

            actions = ["walk", "cast" if arch == "player" else "attack", "idle"]
            for action in actions:
                self.assertIn(action, arch_data, f"'{arch}' must contain '{action}' animation")
                frames = arch_data[action]
                self.assertEqual(len(frames), 4, f"'{arch}' '{action}' must have exactly 4 frames! Found: {len(frames)}")

                for idx, frame in enumerate(frames):
                    self.assertIsInstance(frame, pygame.Surface, f"Frame {idx} must be a pygame.Surface")
                    w, h = frame.get_size()
                    self.assertGreater(w, 20, f"Frame width {w} must be > 20")
                    self.assertGreater(h, 20, f"Frame height {h} must be > 20")

    def test_player_draw_all_states(self):
        """Test rendering player in Walk, Cast (channel & burst), and Idle states."""
        surf = pygame.Surface((200, 200), pygame.SRCALPHA)

        # 1. Idle (all 4 frames)
        for i in range(4):
            surf.fill((0, 0, 0, 0))
            draw_player_character(
                surf, self.art, 100, 100, 0.0, anim_time=i * 0.28,
                weapon_color=(100, 200, 255), is_fumbled=False, has_iframes=False,
                weapon_tier=3, is_moving=False, is_casting=False, cast_timer=0.0
            )
            self.assertGreater(surf.get_bounding_rect().width, 10)

        # 2. Walk (all 4 frames)
        for i in range(4):
            surf.fill((0, 0, 0, 0))
            draw_player_character(
                surf, self.art, 100, 100, 0.0, anim_time=0.0,
                weapon_color=(255, 200, 50), is_fumbled=False, has_iframes=False,
                weapon_tier=2, is_moving=True, is_casting=False, walk_time=i * 0.125
            )
            self.assertGreater(surf.get_bounding_rect().width, 10)

        # 3. Cast Active Burst (all 4 frames)
        for i in range(4):
            surf.fill((0, 0, 0, 0))
            rem_timer = 0.38 * (1.0 - (i + 0.1) / 4.0)
            draw_player_character(
                surf, self.art, 100, 100, 0.0, anim_time=0.0,
                weapon_color=(255, 255, 255), is_fumbled=False, has_iframes=False,
                weapon_tier=5, is_moving=False, is_casting=True, cast_timer=rem_timer
            )
            self.assertGreater(surf.get_bounding_rect().width, 10)

        # 4. Cast Channeling / Drawing Gesture
        for i in range(4):
            surf.fill((0, 0, 0, 0))
            draw_player_character(
                surf, self.art, 100, 100, 0.0, anim_time=i * 0.15,
                weapon_color=(200, 80, 255), is_fumbled=False, has_iframes=False,
                weapon_tier=4, is_moving=False, is_casting=True, cast_timer=0.0
            )
            self.assertGreater(surf.get_bounding_rect().width, 10)

    def test_enemy_draw_all_states(self):
        """Test rendering each enemy base in Walk, Attack, and Idle states."""
        surf = pygame.Surface((300, 300), pygame.SRCALPHA)

        enemies_to_test = [
            ("stone_sentry", "golem"),
            ("blood_inquisitor", "inquisitor"),
            ("cult_neophyte", "cultist"),
            ("archlich_mordecai", "lich"),
        ]

        for en_id, sprite_base in enemies_to_test:
            en = Enemy(150, 150, en_id)
            self.assertEqual(en.sprite_base, sprite_base)

            # 1. Idle
            en.is_attacking = False
            en.vx, en.vy = 0.0, 0.0
            surf.fill((0, 0, 0, 0))
            draw_enemy_sprite(surf, self.art, en, 150, 150, 0.5, 0.0)
            self.assertGreater(surf.get_bounding_rect().width, 10)

            # 2. Walk
            en.vx, en.vy = 50.0, 50.0
            en.walk_timer = 0.25
            surf.fill((0, 0, 0, 0))
            draw_enemy_sprite(surf, self.art, en, 150, 150, 0.5, math.pi)
            self.assertGreater(surf.get_bounding_rect().width, 10)

            # 3. Attack (all 4 frames)
            en.is_attacking = True
            for f_i in range(4):
                en.windup_timer = (f_i + 0.1) * (0.85 / 4.0)
                surf.fill((0, 0, 0, 0))
                draw_enemy_sprite(surf, self.art, en, 150, 150, 0.5, 0.0)
                self.assertGreater(surf.get_bounding_rect().width, 10)

    def test_in_game_combat_animation_montage(self):
        """Render a high-definition verification screenshot showcasing the 4 frames."""
        out_surf = pygame.Surface((1200, 700))
        out_surf.fill((12, 14, 20))

        # Title
        font_large = pygame.font.SysFont("Arial", 22, bold=True)
        font_med = pygame.font.SysFont("Arial", 16, bold=True)
        font_small = pygame.font.SysFont("Arial", 13)

        title = font_large.render("★ ПОКАДРОВАЯ АНИМАЦИЯ (4 КАДРА): БЕГ, КАСТ, АТАКИ ★", True, (255, 215, 60))
        out_surf.blit(title, (24, 18))

        categories = [
            ("Player Walk [Бег]", "player", "walk", [(255, 200, 50), 2]),
            ("Player Cast [Каст заклинания]", "player", "cast", [(100, 220, 255), 4]),
            ("Golem Walk [Тяжелая поступь]", "golem", "walk", [(180, 160, 140), 1]),
            ("Golem Attack [Сокрушительный удар]", "golem", "attack", [(255, 120, 40), 1]),
            ("Inquisitor Cross-Slash [Атака клинками]", "inquisitor", "attack", [(255, 60, 60), 1]),
            ("Lich Death Ray [Каст луча смерти]", "lich", "attack", [(120, 255, 180), 1]),
        ]

        row_y = 65
        for cat_label, char_key, act_key, extra in categories:
            lbl = font_med.render(cat_label, True, (210, 230, 255))
            out_surf.blit(lbl, (30, row_y + 35))

            frames = self.art.anims[char_key][act_key]
            for idx in range(4):
                bx = 380 + idx * 190
                by = row_y
                cell_rect = pygame.Rect(bx, by, 160, 90)
                pygame.draw.rect(out_surf, (22, 26, 36), cell_rect, border_radius=6)
                pygame.draw.rect(out_surf, (45, 52, 70), cell_rect, 1, border_radius=6)

                # Floor rune preview
                pygame.draw.ellipse(out_surf, (35, 42, 58), (bx + 30, by + 68, 100, 16))

                # Render character in this specific frame
                cx = bx + 80
                cy = by + 46
                if char_key == "player":
                    if act_key == "walk":
                        draw_player_character(
                            out_surf, self.art, cx, cy, 0.0, 0.0,
                            extra[0], False, False, weapon_tier=extra[1],
                            is_moving=True, is_casting=False, walk_time=idx * 0.125
                        )
                    else: # cast
                        c_timer = 0.38 * (1.0 - (idx + 0.1) / 4.0)
                        draw_player_character(
                            out_surf, self.art, cx, cy, 0.0, 0.0,
                            extra[0], False, False, weapon_tier=extra[1],
                            is_moving=False, is_casting=True, cast_timer=c_timer
                        )
                else: # enemy
                    en = Enemy(cx, cy, "stone_sentry" if char_key == "golem" else ("blood_inquisitor" if char_key == "inquisitor" else "archlich_mordecai"))
                    if act_key == "walk":
                        en.is_attacking = False
                        en.vx = 40.0
                        en.walk_timer = idx * 0.125
                    else:
                        en.is_attacking = True
                        en.windup_timer = (idx + 0.1) * (0.85 / 4.0)
                    draw_enemy_sprite(out_surf, self.art, en, cx, cy, 0.5, 0.0)

                badge = font_small.render(f"Кадр {idx + 1}/4", True, (160, 190, 230))
                out_surf.blit(badge, (bx + 8, by + 68))

            row_y += 100

        # Save verification screenshot
        preview_path = "assets/anim_frames/test_4frame_animations_preview.png"
        pygame.image.save(out_surf, preview_path)
        print(f"Saved test verification screenshot to: {preview_path}")

if __name__ == "__main__":
    unittest.main()
