import os
import pygame
import math
from game_engine import Game
from config import MAP_WIDTH, MAP_HEIGHT
from achievements import ACHIEVEMENT_MANAGER

def test_all():
    os.environ['SDL_VIDEODRIVER'] = 'dummy'
    pygame.init()
    game = Game()
    game.state = 'PLAYING'
    out_dir = r"C:\Users\Parzi\.gemini\antigravity\brain\479ac71d-3313-4bcf-ac56-8d3888ba42d4"
    os.makedirs(out_dir, exist_ok=True)

    print("=== TEST 1: SPEEDRUN TRIGGER & CONFIRMATION MODAL ===")
    assert not game.speedrun_confirm_active
    assert not game.speedrun_active

    # Simulate pressing '/' key
    slash_event = pygame.event.Event(pygame.KEYDOWN, key=pygame.K_SLASH, unicode='/')
    pygame.event.post(slash_event)
    game.handle_input()

    assert game.speedrun_confirm_active, "Expected speedrun confirmation modal to open on '/'"
    print("[PASS] Speedrun confirmation modal opened upon pressing '/'!")

    # Render frame with speedrun modal
    game.render()
    modal_path = os.path.join(out_dir, "speedrun_modal_preview.png")
    pygame.image.save(game.screen, modal_path)
    print(f"[PASS] Saved speedrun modal screenshot to {modal_path}")

    # Confirm speedrun start with ENTER
    enter_event = pygame.event.Event(pygame.KEYDOWN, key=pygame.K_RETURN)
    pygame.event.post(enter_event)
    game.handle_input()

    assert not game.speedrun_confirm_active
    assert game.speedrun_active
    assert game.speedrun_time == 0.0
    print("[PASS] Speedrun mode confirmed and started!")

    # Advance time and verify chronometer
    game.update(0.5)
    assert abs(game.speedrun_time - 0.5) < 0.01, f"Expected 0.5s, got {game.speedrun_time}"
    print(f"[PASS] Speedrun chronometer running: {game.speedrun_time:.3f}s")

    # Floor transition split
    game.load_floor(1)
    assert 1 in game.speedrun_splits
    print(f"[PASS] Floor 1 split recorded: {game.speedrun_splits[1]:.3f}s")

    print("\n=== TEST 2: MAP BARRICADES & STANDALONE BENCHES ===")
    barricades = [o for o in game.obstacles if o.get('type') == 'BENCH_BARRICADE']
    assert len(barricades) == 4, f"Expected 4 barricades, found {len(barricades)}"
    districts = {b['district'] for b in barricades}
    assert districts == {'NORTH', 'SOUTH', 'EAST', 'WEST'}, f"Expected 4 districts, got {districts}"
    print("[PASS] 4 city gate bench barricades verified (North, South, East, West)!")

    benches = [o for o in game.obstacles if o.get('type') == 'BENCH']
    assert len(benches) >= 8, f"Expected >= 8 benches, found {len(benches)}"
    print(f"[PASS] {len(benches)} standalone gothic street benches verified along sidewalks!")

    print("\n=== TEST 3: CITY HOUSES & BARRIER RENDERING ===")
    # Place player near West Gate barricade and city houses
    game.player.x = 220
    game.player.y = MAP_HEIGHT // 2
    game.cam_x = 0
    game.cam_y = game.player.y - 800 / 2
    game.anim_time = 2.4
    game.render()

    barrier_path = os.path.join(out_dir, "city_and_barrier_preview.png")
    pygame.image.save(game.screen, barrier_path)
    print(f"[PASS] Saved city and glowing barrier preview to {barrier_path}")

    print("\n=== TEST 4: ACHIEVEMENT 'КАК ТУТ ВЫЙТИ?!' (EXPLORE ALL HOUSES) ===")
    ach_id = "city_escape_attempt"
    # Ensure fresh state for test
    if ach_id in ACHIEVEMENT_MANAGER.achievements:
        ACHIEVEMENT_MANAGER.achievements[ach_id].unlocked = False

    game.visited_city_districts.clear()

    for idx, bar in enumerate(barricades):
        game.player.x = bar['x']
        game.player.y = bar['y'] + (40 if bar['y'] < 200 else -40 if bar['y'] > 1400 else 0)
        game.update(0.016)
        assert len(game.visited_city_districts) == idx + 1, f"Expected {idx+1} visited districts, got {len(game.visited_city_districts)}"

    assert ACHIEVEMENT_MANAGER.is_unlocked(ach_id), "Achievement 'city_escape_attempt' should be unlocked!"
    print("[PASS] Achievement 'Как тут выйти?!' successfully unlocked after visiting all 4 districts!")

    # Render frame with unlocked achievement toast
    ACHIEVEMENT_MANAGER.update_popups(0.1)
    game.render()
    ach_path = os.path.join(out_dir, "city_achievement_unlocked_preview.png")
    pygame.image.save(game.screen, ach_path)
    print(f"[PASS] Saved achievement toast screenshot to {ach_path}")

    print("\n=======================================================")
    print("   ALL TESTS FOR SPEEDRUN, BARRIER, CITY & ACHIEVEMENTS PASSED! ")
    print("=======================================================")

if __name__ == '__main__':
    test_all()
