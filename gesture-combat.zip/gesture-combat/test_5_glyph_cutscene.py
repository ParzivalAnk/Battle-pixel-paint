import os
import pygame
os.environ["SDL_VIDEODRIVER"] = "dummy"

from main import Game, VIEW_WIDTH, VIEW_HEIGHT, TEXT_GOLD, TEXT_CYAN, TEXT_RED

pygame.init()
pygame.font.init()

game = Game()
game.state = 'PLAYING'
game.load_floor(1) # Floor 2 has boss Malchor

boss = next((en for en in game.enemies if en.alive and getattr(en, 'is_boss', False)), None)
if not boss:
    # Spawn boss for test
    from main import Enemy
    boss = Enemy(game.player.x + 120, game.player.y, "grand_inquisitor_malchor")
    game.enemies.append(boss)

print(f"Boss present: {boss.name}, HP: {boss.hp}")

# Verify 5 runes queue
game.wild_magic_queue = ["STAR_PENTAGRAM", "SLASH_H", "PARRY", "CIRCLE", "ZIGZAG"]
assert len(game.wild_magic_queue) == 5

# Test cutscene initialization
pattern = game.get_wild_magic_pattern_for_queue()
print(f"Pattern for 5 runes: {pattern['name']} ({pattern['duration']}s)")

print("=== 5-RUNE CUTSCENE INITIALIZATION TEST PASSED! ===")
