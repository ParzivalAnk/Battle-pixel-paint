"""
test_death_and_game_over.py - Comprehensive verification of player death, Game Over state,
absence of 'permadeath' text, and prevention of post-death gameplay.
"""

import os
import pygame
from game_engine import Game
import hud

def run_tests():
    pygame.init()
    game = Game()
    game.start_run()

    print("=== TEST 1: Normal Gameplay State ===")
    assert game.state == 'PLAYING', f"Expected state PLAYING, got {game.state}"
    assert game.player.alive is True, "Player should be alive initially"
    initial_x = game.player.x
    initial_y = game.player.y
    print(f"Player alive at ({initial_x}, {initial_y})")

    print("\n=== TEST 2: Player Death from Damage ===")
    # Inflict lethal damage
    game.player.take_damage(game.player.max_hp * 2, game.fx, game.sfx, game.art, False)
    assert game.player.alive is False, "Player should be dead (alive == False)"
    assert game.state == 'GAME_OVER', f"Expected state GAME_OVER, got {game.state}"
    print(f"Player dead, state transitioned to: {game.state}")

    print("\n=== TEST 3: Attempting Actions While Dead (Should Be Blocked) ===")
    # 1. Attempt Movement
    keys_mock = {pygame.K_w: True, pygame.K_a: True, pygame.K_s: False, pygame.K_d: False, pygame.K_UP: False, pygame.K_LEFT: False, pygame.K_DOWN: False, pygame.K_RIGHT: False}
    dead_pos_x = game.player.x
    dead_pos_y = game.player.y
    game.player.update(0.1, keys_mock, 1.0, game.obstacles)
    assert game.player.x == dead_pos_x and game.player.y == dead_pos_y, "Player moved while dead!"
    assert game.player.vx == 0.0 and game.player.vy == 0.0, "Player velocity is non-zero while dead!"

    # 2. Attempt Game Update
    game.update(0.1)
    assert game.state == 'GAME_OVER', "State changed during update while dead!"
    assert game.player.x == dead_pos_x and game.player.y == dead_pos_y, "Player position changed during game.update!"

    # 3. Attempt Drawing / Mouse Click
    click_event = pygame.event.Event(pygame.MOUSEBUTTONDOWN, {'pos': (400, 300), 'button': 1})
    pygame.event.post(click_event)
    game.handle_input()
    assert game.is_drawing is False, "Player was able to start drawing while dead!"
    assert len(game.stroke_points) == 0, "Stroke points registered while dead!"

    print("All post-death actions successfully blocked!")

    print("\n=== TEST 4: Verifying Death Screen Text and Elements ===")
    # Render death screen to surface
    hud.draw_permadeath(game, game.screen)
    assert "restart" in game.death_rects, "Restart button missing in death_rects"
    assert "menu" in game.death_rects, "Menu button missing in death_rects"

    # Verify no 'permadeath' or 'paermadeath' in death messages
    msg_normal = "ВРЕМЯ ИСТЕКЛО" if game.zone_timer <= 0 else "ВЫ ПОГИБЛИ"
    assert "permadeath" not in msg_normal.lower()
    assert "paermadeath" not in msg_normal.lower()
    assert msg_normal == "ВЫ ПОГИБЛИ" or msg_normal == "ВРЕМЯ ИСТЕКЛО"
    print(f"Verified: Displayed death message is clean: '{msg_normal}'")

    # Check timeout death message
    game.zone_timer = 0
    # Capture rendering
    hud.draw_permadeath(game, game.screen)
    # Save a screenshot to artifacts/inspect directory
    out_dir = r"C:\Users\Parzi\.gemini\antigravity\brain\479ac71d-3313-4bcf-ac56-8d3888ba42d4"
    os.makedirs(out_dir, exist_ok=True)
    screenshot_path = os.path.join(out_dir, "death_screen_preview.png")
    pygame.image.save(game.screen, screenshot_path)
    print(f"Saved Game Over screen preview to: {screenshot_path}")

    print("\n=== TEST 5: Interactive Buttons (Restart & Menu) ===")
    # 1. Test Restart via death_rects click
    restart_rect = game.death_rects["restart"]
    r_click = pygame.event.Event(pygame.MOUSEBUTTONDOWN, {'pos': (restart_rect.centerx, restart_rect.centery), 'button': 1})
    pygame.event.post(r_click)
    game.handle_input()
    assert game.state == 'PLAYING', f"Expected state PLAYING after restart click, got {game.state}"
    assert game.player.alive is True, "Player should be alive after restart"
    print("Restart via button click: SUCCESS!")

    # 2. Test Menu Return via death_rects click
    # Kill player again
    game.player.take_damage(game.player.max_hp * 2, game.fx, game.sfx, game.art, False)
    assert game.state == 'GAME_OVER'
    hud.draw_permadeath(game, game.screen)
    menu_rect = game.death_rects["menu"]
    m_click = pygame.event.Event(pygame.MOUSEBUTTONDOWN, {'pos': (menu_rect.centerx, menu_rect.centery), 'button': 1})
    pygame.event.post(m_click)
    game.handle_input()
    assert game.state == 'MAIN_MENU', f"Expected state MAIN_MENU after menu click, got {game.state}"
    game.update(0.1)
    assert game.state == 'MAIN_MENU', "Game reverted to GAME_OVER after update!"
    print("Return to menu via button click: SUCCESS!")

    # 3. Test Keyboard [R] and [M] (English Layout)
    game.start_run()
    game.player.take_damage(game.player.max_hp * 2, game.fx, game.sfx, game.art, False)
    assert game.state == 'GAME_OVER'
    # Press R
    r_key = pygame.event.Event(pygame.KEYDOWN, {'key': pygame.K_r})
    pygame.event.post(r_key)
    game.handle_input()
    assert game.state == 'PLAYING' and game.player.alive is True, "Restart via [R] key failed"
    print("Restart via [R] key: SUCCESS!")

    game.player.take_damage(game.player.max_hp * 2, game.fx, game.sfx, game.art, False)
    assert game.state == 'GAME_OVER'
    # Press M
    m_key = pygame.event.Event(pygame.KEYDOWN, {'key': pygame.K_m})
    pygame.event.post(m_key)
    game.handle_input()
    assert game.state == 'MAIN_MENU', "Return to menu via [M] key failed"
    game.update(0.1)
    assert game.state == 'MAIN_MENU', "State snapped back to GAME_OVER after [M] key!"
    print("Return to menu via [M] key: SUCCESS!")

    # 4. Test Russian Layout Keys [ь] (M) and [к] (R)
    game.start_run()
    game.player.take_damage(game.player.max_hp * 2, game.fx, game.sfx, game.art, False)
    assert game.state == 'GAME_OVER'
    ru_m_key = pygame.event.Event(pygame.KEYDOWN, {'key': ord('ь'), 'scancode': pygame.KSCAN_M, 'unicode': 'ь'})
    pygame.event.post(ru_m_key)
    game.handle_input()
    assert game.state == 'MAIN_MENU', "Return to menu via Russian [ь] key failed"
    game.update(0.1)
    assert game.state == 'MAIN_MENU', "State snapped back to GAME_OVER after Russian [ь] key!"
    print("Return to menu via Russian [ь] key: SUCCESS!")

    game.start_run()
    game.player.take_damage(game.player.max_hp * 2, game.fx, game.sfx, game.art, False)
    assert game.state == 'GAME_OVER'
    ru_r_key = pygame.event.Event(pygame.KEYDOWN, {'key': ord('к'), 'scancode': pygame.KSCAN_R, 'unicode': 'к'})
    pygame.event.post(ru_r_key)
    game.handle_input()
    assert game.state == 'PLAYING' and game.player.alive is True, "Restart via Russian [к] key failed"
    print("Restart via Russian [к] key: SUCCESS!")

    # 5. Test [ESC] key in GAME_OVER
    game.player.take_damage(game.player.max_hp * 2, game.fx, game.sfx, game.art, False)
    assert game.state == 'GAME_OVER'
    esc_key = pygame.event.Event(pygame.KEYDOWN, {'key': pygame.K_ESCAPE})
    pygame.event.post(esc_key)
    game.handle_input()
    assert game.state == 'MAIN_MENU', "Return to menu via [ESC] key failed"
    game.update(0.1)
    assert game.state == 'MAIN_MENU', "State snapped back to GAME_OVER after [ESC] key!"
    print("Return to menu via [ESC] key: SUCCESS!")

    print("\n==========================================")
    print("   ALL TESTS COMPLETED AND VERIFIED 100%!  ")
    print("==========================================")

if __name__ == '__main__':
    run_tests()
