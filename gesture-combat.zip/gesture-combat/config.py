"""
config.py - Game configurations, arena boundaries, colors, mutators, and floor waves.
Part of the GLYPH-BLADE modular architecture.
"""

# Virtual Arena Bounds (Big map with camera scrolling)
MAP_WIDTH = 2200
MAP_HEIGHT = 1600

# Display Resolutions (FHD 1080p, 2K 1440p, HD 720p)
RESOLUTIONS = {
    "FHD": (1920, 1080),  # Full HD 1080p (Crystal Clear / Optimal)
    "2K":  (2560, 1440),  # 2K Quad HD 1440p
    "HD":  (1280, 720),   # HD 720p (Compact / Windowed)
}
RESOLUTION_ORDER = ["FHD", "2K", "HD"]
DEFAULT_RESOLUTION = "FHD"

VIEW_WIDTH = 1920
VIEW_HEIGHT = 1080
FPS = 60

# Common UI Colors
TEXT_WHITE = (240, 245, 255)
TEXT_GOLD = (255, 220, 60)
TEXT_RED = (255, 75, 75)
TEXT_CYAN = (80, 225, 255)
TEXT_PURPLE = (220, 120, 255)

# Arena Mutators
MUTATORS = [
    {"name": "«Стабильная Зона»", "desc": "Нормальный эфир.", "color": (100, 230, 160), "timer_mult": 1.0, "inertia_mult": 1.0, "jitter": 0.0},
    {"name": "«Магнитные Аномалии»", "desc": "Помехи эфира курсора.", "color": (170, 110, 255), "timer_mult": 1.0, "inertia_mult": 1.0, "jitter": 4.5},
    {"name": "«Кислотная Буря»", "desc": "Таймер сгорает на 35% быстрее!", "color": (255, 185, 45), "timer_mult": 1.35, "inertia_mult": 1.0, "jitter": 0.0},
    {"name": "«Плотный Эфир»", "desc": "Тяжелая инерция тел и оружия.", "color": (90, 190, 255), "timer_mult": 1.0, "inertia_mult": 1.5, "jitter": 0.0}
]

# Glyph Complexity Weights (used in Wild Magic tier determination)
GLYPH_COMPLEXITY = {
    # Weight 1: simple directional slashes / thrust
    "SLASH_H": 1,
    "SLASH_V": 1,
    "THRUST": 1,
    # Weight 2: directional / multi-stroke gestures
    "UPPERCUT": 2,
    "PARRY": 2,
    "ZIGZAG": 2,
    "CROSS": 2,
    "TRIANGLE": 2,
    # Weight 3: circular / sacred / multi-directional gestures
    "CIRCLE": 3,
    "SHIELD_BLOCK": 3,
    "HOURGLASS_SWAP": 3,
    "STAR_PENTAGRAM": 3,
    "INFINITY": 3,
    "CUSTOM_GLYPH": 3,
}

# Wave compositions per floor
FLOOR_WAVES = [
    {
        "floor": 1,
        "name": "«Катакомбы Новичка»",
        "mutator_idx": 0,
        "waves": [
            ["cult_neophyte", "cult_neophyte", "stone_sentry"],
            ["cult_zealot", "blood_inquisitor", "ember_wisp"],
            ["crimson_executioner", "blood_inquisitor", "stone_sentry"]
        ]
    },
    {
        "floor": 2,
        "name": "«Зал Кровавой Инквизиции»",
        "mutator_idx": 1,
        "waves": [
            ["blood_inquisitor", "blood_inquisitor", "shadow_drinker"],
            ["cult_zealot", "cult_zealot", "possessed_monk", "bishop_of_agony"],
            ["grand_inquisitor_malchor", "blood_inquisitor", "crimson_executioner"]
        ]
    },
    {
        "floor": 3,
        "name": "«Чрево Колоссов»",
        "mutator_idx": 2,
        "waves": [
            ["magma_golem", "stone_sentry", "fissure_breaker"],
            ["obsidian_juggernaut", "quake_titan", "frost_shardling"],
            ["goliath_prime_titan", "magma_golem", "runic_automaton"]
        ]
    },
    {
        "floor": 4,
        "name": "«Некрополь Архилича»",
        "mutator_idx": 3,
        "waves": [
            ["plague_skeleton", "plague_skeleton", "bone_legionnaire"],
            ["crypt_wraith", "rot_bomber", "death_knight", "banshee_screamer"],
            ["archlich_mordecai", "death_knight", "lich_archivist"]
        ]
    },
    {
        "floor": 5,
        "name": "«Трон Первородного Хаоса»",
        "mutator_idx": 0,
        "waves": [
            ["void_stalker", "mind_flayer", "abyssal_burrower"],
            ["void_overlord", "gravity_oculus", "plasma_vortex_entity"],
            ["avatar_of_chaos", "goliath_prime_titan", "grand_inquisitor_malchor"]
        ]
    },
    {
        "floor": 6,
        "name": "«Арена Владычицы Клинков»",
        "mutator_idx": 1,
        "waves": [
            ["blood_inquisitor", "shadow_drinker", "crimson_executioner"],
            ["possessed_monk", "bishop_of_agony", "blood_inquisitor"],
            ["bladesovereign_valeria", "blood_inquisitor", "cult_zealot"]
        ]
    },
    {
        "floor": 7,
        "name": "«Бездна Левиафана»",
        "mutator_idx": 3,
        "waves": [
            ["void_stalker", "obsidian_juggernaut", "gravity_oculus"],
            ["void_overlord", "fissure_breaker", "rot_bomber"],
            ["abyssal_drakon_nadir", "void_overlord", "goliath_prime_titan"]
        ]
    }
]


def get_floor_data(floor_idx: int) -> dict:
    """Returns wave and metadata configuration for a given 0-indexed floor."""
    if floor_idx < len(FLOOR_WAVES):
        return FLOOR_WAVES[floor_idx]
    elif floor_idx == 49:  # Floor 50!
        return {
            "floor": 50,
            "name": "«Чертог Истины: 50-й Уровень»",
            "mutator_idx": 1,
            "waves": [
                ["judge_of_truth"]
            ]
        }
    return {
        "floor": floor_idx + 1,
        "name": f"«Бесконечная Бездна: Этаж {floor_idx + 1}»",
        "mutator_idx": floor_idx % len(MUTATORS),
        "waves": [
            ["void_overlord", "goliath_prime_titan"],
            ["avatar_of_chaos", "archlich_mordecai", "grand_inquisitor_malchor"]
        ]
    }
