"""
hud.py - In-game Heads-Up Display (HUD), Boss Health Bars, Status Indicators, and Menu Overlays.
Part of the GLYPH-BLADE modular architecture.
"""

import math
import pygame

from config import VIEW_WIDTH, VIEW_HEIGHT, TEXT_GOLD, TEXT_WHITE, TEXT_CYAN, TEXT_RED
from difficulty import DIFFICULTY_MANAGER
from challenges import CHALLENGE_MANAGER
from bestiary import BESTIARY
from recognizer import SKILL_INFO
from effects import render_mixed_text
from perks import draw_cracked_cursed_card, draw_double_edged_card
from menu import draw_pixel_button, get_pixel_icon


def get_boss_info_text(game):
    """Finds active or upcoming boss name on current floor."""
    boss_ids = {
        "grand_inquisitor_malchor", "goliath_prime_titan", "archlich_mordecai",
        "void_overlord", "avatar_of_chaos", "bladesovereign_valeria",
        "abyssal_drakon_nadir", "judge_of_truth"
    }

    # 1. Active boss alive on the battlefield right now
    active_boss = next((en for en in game.enemies if en.alive and (en.id in boss_ids or "БОСС" in getattr(en, 'name', ''))), None)
    if active_boss:
        clean = active_boss.name.replace(" [БОСС 50 ЭТАЖА]", "").replace(" [ЭТАЖ 50 БОСС]", "").replace(" [БОСС]", "").replace(" [МЕГА-БОСС]", "").replace(" [ГИГАНТ-БОСС]", "").replace("«", "").replace("»", "").strip()
        return f"БОСС: {clean}"

    # 2. Check scheduled boss for current floor waves
    f_data = game.current_floor_data
    if f_data and "waves" in f_data:
        for w_list in f_data["waves"]:
            for e_id in w_list:
                b_data = BESTIARY.get(e_id, {})
                b_name = b_data.get("name", "")
                if e_id in boss_ids or "БОСС" in b_name:
                    clean = b_name.replace(" [БОСС 50 ЭТАЖА]", "").replace(" [ЭТАЖ 50 БОСС]", "").replace(" [БОСС]", "").replace(" [МЕГА-БОСС]", "").replace(" [ГИГАНТ-БОСС]", "").replace("«", "").replace("»", "").strip()
                    return f"БОСС: {clean}"
        # Fallback to strongest enemy in final wave if no formal boss
        if f_data["waves"]:
            final_wave = f_data["waves"][-1]
            strongest_id = max(final_wave, key=lambda eid: BESTIARY.get(eid, {}).get("hp", 0), default=None)
            if strongest_id and strongest_id in BESTIARY:
                clean = BESTIARY[strongest_id]["name"].replace(" [БОСС]", "").replace(" [МЕГА-БОСС]", "").replace("«", "").replace("»", "").strip()
                return f"БОСС: {clean}"
    return None


def draw_hud(game, surface=None):
    """Renders main in-game heads-up display: timers, wave info, wild magic slots, health, and weapons."""
    if surface is None:
        surface = game.screen

    sw, sh = surface.get_width(), surface.get_height()

    fonts_dict = {
        "title": game.font_title,
        "large": game.font_large,
        "med": game.font_med,
        "small": game.font_small,
        "sym_large": game.font_sym_large,
        "sym_med": game.font_sym_med,
        "sym_small": game.font_sym_small
    }

    # Top Banner: Survival Countdown & Floor Info
    f_data = game.current_floor_data
    if game.state == 'DOJO':
        mode_surf = game.font_large.render("ТРЕНИРОВОЧНОЕ ДОДЗЁ • ИНТЕРАКТИВНОЕ ОБУЧЕНИЕ", True, TEXT_CYAN)
        surface.blit(mode_surf, (sw // 2 - mode_surf.get_width() // 2, 10))

        sub_controls = game.font_small.render("[ESC] Выход в Меню   [TAB] Список Заданий   [H] Проекция на поле   [◄ / ►] Смена Урока   [1-3] Оружие   [C] Алтарь", True, (180, 205, 235))
        surface.blit(sub_controls, (sw // 2 - sub_controls.get_width() // 2, 34))

        if hasattr(game, 'tutorial_manager'):
            # 1. In-world ethereal projection on ground near player
            game.tutorial_manager.draw_in_world_projection(surface, game.cam_x, game.cam_y, game.player, game.anim_time, fonts_dict)

            # 2. Left side interactive quest panel & active lesson card
            game.tutorial_manager.draw_dojo_tutorial(surface, game.anim_time, fonts_dict)
    else:
        timer_color = TEXT_WHITE if game.zone_timer > 15 else TEXT_RED
        mins = int(game.zone_timer) // 60
        secs = game.zone_timer % 60
        timer_str = f"ТАЙМЕР: {mins:02d}:{secs:05.2f}"
        timer_surf = game.font_large.render(timer_str, True, timer_color)
        surface.blit(timer_surf, (sw // 2 - timer_surf.get_width() // 2, 10))

        # Wave Counter & Boss Badge (Top Center)
        total_w = len(f_data["waves"])
        cur_w = game.current_wave_idx + 1
        boss_info = get_boss_info_text(game)
        boss_part = f"  |  {boss_info}" if boss_info else ""
        wave_txt = f"ЭТАЖ {f_data['floor']}  •  ВОЛНА {cur_w}/{total_w}{boss_part}"
        wave_surf = game.font_med.render(wave_txt, True, TEXT_GOLD)
        surface.blit(wave_surf, (sw // 2 - wave_surf.get_width() // 2, 38))

    # -------------------------------------------------------------
    # COMBO SIGN ACCUMULATION HUD BAR
    # -------------------------------------------------------------
    if game.state in ('PLAYING', 'DOJO'):
        bar_w = 480
        bar_h = 32
        bar_x = sw // 2 - bar_w // 2
        bar_y = 66

        # Background panel with glassmorphic aesthetic
        pygame.draw.rect(surface, (14, 18, 28), (bar_x, bar_y, bar_w, bar_h), border_radius=6)
        pygame.draw.rect(surface, (50, 75, 115), (bar_x, bar_y, bar_w, bar_h), 1, border_radius=6)

        # 1. Mode Badge / Toggle Button
        mode_rect = pygame.Rect(bar_x + 6, bar_y + 4, 110, 24)
        if getattr(game, 'wild_magic_mode', True):
            pygame.draw.rect(surface, (36, 30, 16), mode_rect, border_radius=4)
            pygame.draw.rect(surface, (230, 180, 50), mode_rect, 1, border_radius=4)
            m_txt = render_mixed_text("★ ДИКАЯ МАГИЯ", game.font_small, game.font_sym_small, TEXT_GOLD)
        else:
            pygame.draw.rect(surface, (20, 24, 34), mode_rect, border_radius=4)
            pygame.draw.rect(surface, (70, 85, 110), mode_rect, 1, border_radius=4)
            m_txt = render_mixed_text("⚔ МГНОВЕННО", game.font_small, game.font_sym_small, (160, 180, 205))
        surface.blit(m_txt, (mode_rect.centerx - m_txt.get_width() // 2, mode_rect.centery - m_txt.get_height() // 2))

        # 2. 5 Glyph Slots in center
        slot_size = 24
        slot_gap = 5
        slots_x = bar_x + 122
        for idx in range(5):
            s_rect = pygame.Rect(slots_x + idx * (slot_size + slot_gap), bar_y + 4, slot_size, slot_size)
            if idx < len(game.wild_magic_queue):
                gid = game.wild_magic_queue[idx]
                sinfo = SKILL_INFO.get(gid, {})
                col = sinfo.get("color", (100, 220, 255))
                sym = sinfo.get("symbol", "?")
                pygame.draw.rect(surface, (min(255, col[0] // 4), min(255, col[1] // 4), min(255, col[2] // 4)), s_rect, border_radius=4)
                pygame.draw.rect(surface, col, s_rect, 1, border_radius=4)
                sym_s = game.font_sym_small.render(sym, True, col)
                surface.blit(sym_s, (s_rect.centerx - sym_s.get_width() // 2, s_rect.centery - sym_s.get_height() // 2))
            else:
                pygame.draw.rect(surface, (18, 22, 32), s_rect, border_radius=4)
                pygame.draw.rect(surface, (45, 55, 75), s_rect, 1, border_radius=4)
                dot_s = game.font_small.render("·", True, (70, 80, 100))
                surface.blit(dot_s, (s_rect.centerx - dot_s.get_width() // 2, s_rect.centery - dot_s.get_height() // 2))

        # 3. [▶ СТАРТ] Button
        btn_start_rect = pygame.Rect(bar_x + 270, bar_y + 4, 88, 24)
        if len(game.wild_magic_queue) >= 1:
            pulse = (math.sin(game.anim_time * 6.0) + 1.0) * 0.5
            b_col = (int(255 - 40 * pulse), int(210 + 45 * pulse), 60)
            pygame.draw.rect(surface, (45, 36, 16), btn_start_rect, border_radius=4)
            pygame.draw.rect(surface, b_col, btn_start_rect, 2, border_radius=4)
            start_s = render_mixed_text("▶ СТАРТ", game.font_med, game.font_sym_med, TEXT_GOLD)
        else:
            pygame.draw.rect(surface, (18, 22, 30), btn_start_rect, border_radius=4)
            pygame.draw.rect(surface, (45, 55, 70), btn_start_rect, 1, border_radius=4)
            start_s = game.font_small.render("СТАРТ", True, (90, 105, 120))
        surface.blit(start_s, (btn_start_rect.centerx - start_s.get_width() // 2, btn_start_rect.centery - start_s.get_height() // 2))

        # 4. Clear Button [✕]
        btn_clear_rect = pygame.Rect(bar_x + 364, bar_y + 4, 24, 24)
        pygame.draw.rect(surface, (24, 20, 24), btn_clear_rect, border_radius=4)
        pygame.draw.rect(surface, (70, 50, 60), btn_clear_rect, 1, border_radius=4)
        cl_s = render_mixed_text("✕", game.font_small, game.font_sym_small, (180, 130, 130))
        surface.blit(cl_s, (btn_clear_rect.centerx - cl_s.get_width() // 2, btn_clear_rect.centery - cl_s.get_height() // 2))

        # 5. Hotkey tag [ПРОБЕЛ]
        hint_s = game.font_small.render("[ПРОБЕЛ]", True, (130, 150, 180))
        surface.blit(hint_s, (bar_x + 396, bar_y + 8))

        game.wild_magic_rects = {
            "mode": mode_rect,
            "start": btn_start_rect,
            "clear": btn_clear_rect
        }

    # Grand Boss Health Bar for Floor 50 Boss (Верховный Судия Истины)
    judge_boss = next((en for en in game.enemies if en.alive and en.id == "judge_of_truth"), None)
    if judge_boss:
        b_bar_w = 660
        b_bar_h = 24
        bx = sw // 2 - b_bar_w // 2
        by = 104
        pygame.draw.rect(surface, (15, 18, 28), (bx, by, b_bar_w, b_bar_h), border_radius=4)
        ratio = max(0.0, min(1.0, judge_boss.hp / judge_boss.max_hp))
        b_col = (255, 60, 60) if getattr(judge_boss, 'enraged', False) else (255, 215, 60)
        pygame.draw.rect(surface, b_col, (bx, by, int(b_bar_w * ratio), b_bar_h), border_radius=4)
        pygame.draw.rect(surface, (255, 230, 100), (bx, by, b_bar_w, b_bar_h), 2, border_radius=4)

        b_status = " [В ЯРОСТИ ОТ ЛЖИ: +25% SPD]" if getattr(judge_boss, 'enraged', False) else ""
        sym_s = game.font_sym_med.render("⚖", True, (255, 220, 80))
        boss_txt = game.font_med.render(f" ВЕРХОВНЫЙ СУДИЯ ИСТИНЫ{b_status}  HP: {int(judge_boss.hp)} / {judge_boss.max_hp} ", True, (255, 255, 255))
        tot_w = sym_s.get_width() * 2 + boss_txt.get_width()
        start_x = sw // 2 - tot_w // 2
        surface.blit(sym_s, (start_x, by + 3))
        surface.blit(boss_txt, (start_x + sym_s.get_width(), by + 3))
        surface.blit(sym_s, (start_x + sym_s.get_width() + boss_txt.get_width(), by + 3))

    # Bullet Time Banner
    if game.bullet_time_timer > 0 and getattr(game, 'wild_magic_state', None) != 'RITUAL':
        bt_str = f"⚡ SLO-MO x5: {game.bullet_time_timer:.1f}s ⚡"
        bt_surf = game.font_med.render(bt_str, True, TEXT_GOLD)
        banner_rect = pygame.Rect(sw // 2 - bt_surf.get_width() // 2 - 12, 104, bt_surf.get_width() + 24, 26)
        pygame.draw.rect(surface, (20, 20, 10, 220), banner_rect)
        pygame.draw.rect(surface, TEXT_GOLD, banner_rect, 2)
        surface.blit(bt_surf, (sw // 2 - bt_surf.get_width() // 2, 106))

    # Mutator Badge (Top Right)
    if game.state != 'DOJO':
        mut = game.current_mutator
        mut_surf = game.font_med.render(f"Аномалия: {mut['name']}", True, mut['color'])
        surface.blit(mut_surf, (sw - mut_surf.get_width() - 35, 12))

    pause_hint = game.font_small.render("[ESC] ПАУЗА  •  [/] СПИДРАН  •  [C] АЛТАРЬ", True, (170, 185, 205))
    surface.blit(pause_hint, (sw - pause_hint.get_width() - 35, 36))

    # -------------------------------------------------------------
    # SPEEDRUN CHRONOMETER WIDGET (TOP-LEFT)
    # -------------------------------------------------------------
    if getattr(game, 'speedrun_active', False):
        s_time = getattr(game, 'speedrun_time', 0.0)
        s_m = int(s_time // 60)
        s_s = int(s_time % 60)
        s_ms = int((s_time * 1000) % 1000)
        sp_time_str = f"{s_m:02d}:{s_s:02d}.{s_ms:03d}"

        sp_box_w, sp_box_h = 240, 56
        sp_box_x, sp_box_y = 24, 12
        sp_rect = pygame.Rect(sp_box_x, sp_box_y, sp_box_w, sp_box_h)

        pygame.draw.rect(surface, (12, 16, 26, 230), sp_rect, border_radius=6)
        pulse = 0.5 + 0.5 * math.sin(game.anim_time * 6.0)
        sp_border = (255, int(190 + 65 * pulse), 60)
        pygame.draw.rect(surface, sp_border, sp_rect, 2, border_radius=6)

        cur_fl = getattr(game, 'current_floor_idx', 0) + 1
        hdr_txt = f"СПИДРАН • ЭТАЖ {cur_fl}"
        hdr_surf = game.font_small.render(hdr_txt, True, (255, 220, 90))
        surface.blit(hdr_surf, (sp_box_x + 10, sp_box_y + 6))

        time_surf = game.font_large.render(sp_time_str, True, (255, 245, 140))
        surface.blit(time_surf, (sp_box_x + 10, sp_box_y + 24))

        pb_time = getattr(game, 'speedrun_best_time', None)
        if pb_time:
            pb_m = int(pb_time // 60)
            pb_s = int(pb_time % 60)
            pb_ms = int((pb_time * 1000) % 1000)
            pb_txt = f"PB: {pb_m:02d}:{pb_s:02d}.{pb_ms:03d}"
            pb_surf = game.font_small.render(pb_txt, True, (130, 230, 255))
            surface.blit(pb_surf, (sp_rect.right - pb_surf.get_width() - 10, sp_box_y + 6))

    if game.sealed_ultra_combo:
        sc_txt = f"★ [F] ЗАПЕЧАТАНО: {game.sealed_ultra_combo['name']}"
        sc_surf = game.font_small.render(sc_txt, True, game.sealed_ultra_combo['color'])
        surface.blit(sc_surf, (sw - sc_surf.get_width() - 35, 58))

    # -------------------------------------------------------------
    # BOTTOM-LEFT HUD: HEALTH & COOLDOWN (STACKED), WEAPON & SWITCH
    # -------------------------------------------------------------
    hud_left_x = 24
    bar_w = 210
    bar_h = 20
    gap = 6
    hp_y = sh - 16 - bar_h - gap - bar_h
    cd_y = sh - 16 - bar_h

    # Badges above health bar (Difficulty, Challenges, Curses)
    badge_y = hp_y - 20
    diff = DIFFICULTY_MANAGER.current
    diff_h = game.font_small.render(f"{diff.badge}", True, diff.color)
    surface.blit(diff_h, (hud_left_x, badge_y))

    badge_offset_x = hud_left_x + diff_h.get_width() + 8
    ch_active = CHALLENGE_MANAGER.get_active_count()
    if ch_active > 0:
        ch_badge = render_mixed_text(f"+ ☠ {ch_active} УСЛОЖН.", game.font_small, game.font_sym_small, (255, 85, 100))
        surface.blit(ch_badge, (badge_offset_x, badge_y))
        badge_offset_x += ch_badge.get_width() + 8

    if getattr(game.player, 'curse_count', 0) > 0:
        c_surf = render_mixed_text(f"☠ ПРОКЛЯТИЙ: {game.player.curse_count}", game.font_small, game.font_sym_small, (230, 90, 255))
        surface.blit(c_surf, (badge_offset_x, badge_y))

    # 1. Player Health Bar (Полоска Жизни)
    pygame.draw.rect(surface, (22, 26, 36), (hud_left_x, hp_y, bar_w, bar_h), border_radius=4)
    hp_ratio = max(0.0, min(1.0, game.player.hp / max(1, game.player.max_hp)))
    hp_fill_w = int(bar_w * hp_ratio)
    hp_col = (60, 225, 95) if hp_ratio > 0.4 else ((255, 195, 45) if hp_ratio > 0.2 else (255, 60, 60))
    if hp_fill_w > 0:
        pygame.draw.rect(surface, hp_col, (hud_left_x, hp_y, hp_fill_w, bar_h), border_radius=4)
    pygame.draw.rect(surface, (65, 80, 105), (hud_left_x, hp_y, bar_w, bar_h), 1, border_radius=4)
    hp_txt = game.font_small.render(f"HP: {int(game.player.hp)} / {game.player.max_hp}", True, TEXT_WHITE)
    surface.blit(hp_txt, (hud_left_x + 8, hp_y + 2))

    # 2. Drawing Cooldown Bar (Полоска КД, строго под полоской жизни)
    pygame.draw.rect(surface, (22, 26, 38), (hud_left_x, cd_y, bar_w, bar_h), border_radius=4)
    if getattr(game, 'draw_cooldown', 0.0) > 0:
        prog = 1.0 - (game.draw_cooldown / max(0.01, getattr(game, 'max_draw_cooldown', 0.85)))
        fill_w = int(bar_w * max(0.0, min(1.0, prog)))
        pygame.draw.rect(surface, (255, 130, 45), (hud_left_x, cd_y, fill_w, bar_h), border_radius=4)
        pygame.draw.rect(surface, (255, 170, 70), (hud_left_x, cd_y, bar_w, bar_h), 1, border_radius=4)
        cd_txt = game.font_small.render(f"КД ЗНАКА: {game.draw_cooldown:.1f}с", True, (255, 235, 205))
        surface.blit(cd_txt, (hud_left_x + 8, cd_y + 2))
    else:
        pygame.draw.rect(surface, (30, 160, 200), (hud_left_x, cd_y, bar_w, bar_h), border_radius=4)
        pygame.draw.rect(surface, (90, 230, 255), (hud_left_x, cd_y, bar_w, bar_h), 1, border_radius=4)
        cd_txt = game.font_small.render("ЧЕРЧЕНИЕ: ГОТОВО [ЛКМ]", True, (240, 255, 255))
        surface.blit(cd_txt, (hud_left_x + 8, cd_y + 2))

    # 3. Weapon Name & Stats + Switching Belt
    wep_x = hud_left_x + bar_w + 18
    act_w = game.player.weapon

    w_prefix = "[БОЖЕСТВЕННЫЙ РАНГ] " if act_w.tier == 5 else ""
    w_perk = f"  •  {act_w.perk_desc}" if act_w.perk_desc else ""
    w_info = f"{w_prefix}{act_w.name}  |  {act_w.short_tier}  |  УРОН x{act_w.damage_mult:.2f}  |  {act_w.weight} кг{w_perk}"
    w_info_s = game.font_small.render(w_info, True, act_w.glow_color)
    surface.blit(w_info_s, (wep_x, hp_y + 2))

    if game.player.combo_count > 0:
        mult = 1.0 + (game.player.combo_count - 1) * 0.30
        combo_surf = game.font_small.render(f"СЕРИЯ x{game.player.combo_count}! (УРОН x{mult:.2f})", True, TEXT_GOLD)
        surface.blit(combo_surf, (wep_x, badge_y))

    cur_slot = getattr(game.player, 'active_weapon_slot', 1)
    slot_w = 110
    slot_h = 20
    slot_gap = 6

    for s_idx in (1, 2, 3):
        s_rect = pygame.Rect(wep_x + (s_idx - 1) * (slot_w + slot_gap), cd_y, slot_w, slot_h)
        s_wep = game.player.weapon_slots.get(s_idx, game.player.weapon)
        is_active_s = (s_idx == cur_slot)

        bg_c = (35, 45, 68) if is_active_s else (16, 20, 30)
        pygame.draw.rect(surface, bg_c, s_rect, border_radius=3)

        bdr_c = (255, 255, 255) if (is_active_s and s_wep.tier == 5) else (s_wep.glow_color if is_active_s else (55, 65, 85))
        bdr_w = 2 if is_active_s else 1
        pygame.draw.rect(surface, bdr_c, s_rect, bdr_w, border_radius=3)

        k_txt = f"[{s_idx}] "
        k_s = game.font_small.render(k_txt, True, TEXT_GOLD if is_active_s else (150, 160, 180))

        clean_name = s_wep.name.replace("«", "").replace("»", "")
        if len(clean_name) > 8:
            clean_name = clean_name[:7] + ".."
        w_s = game.font_small.render(clean_name, True, s_wep.glow_color)

        surface.blit(k_s, (s_rect.x + 4, s_rect.y + 2))
        surface.blit(w_s, (s_rect.x + 4 + k_s.get_width(), s_rect.y + 2))

    hint_x = wep_x + 3 * (slot_w + slot_gap) + 8
    hint_s = game.font_small.render("(Смена: [1]-[3])", True, (140, 155, 180))
    surface.blit(hint_s, (hint_x, cd_y + 2))

    # Live Accuracy Feedback Box
    if game.last_accuracy_info:
        info = game.last_accuracy_info
        acc_box_w, acc_box_h = 145, 46
        acc_box_x = sw - acc_box_w - 24
        acc_box_y = sh - acc_box_h - 16
        pygame.draw.rect(surface, (16, 20, 30), (acc_box_x, acc_box_y, acc_box_w, acc_box_h), border_radius=4)
        pygame.draw.rect(surface, (45, 55, 75), (acc_box_x, acc_box_y, acc_box_w, acc_box_h), 1, border_radius=4)
        acc_title = game.font_small.render(f"{info['name']}", True, info['color'])
        surface.blit(acc_title, (acc_box_x + 8, acc_box_y + 4))
        tier_color = TEXT_GOLD if info['tier'] == "PERFECT" else (TEXT_CYAN if info['tier'] == "CLEAN" else TEXT_RED)
        acc_val = game.font_med.render(f"{info['score']}% [{info['tier']}]", True, tier_color)
        surface.blit(acc_val, (acc_box_x + 8, acc_box_y + 22))


def draw_tome_of_synthesis(game, surface=None):
    """Renders the Tome of Synthesis grimoire modal overlay."""
    if surface is None:
        surface = game.screen

    sw, sh = surface.get_width(), surface.get_height()
    overlay = pygame.Surface((sw, sh), pygame.SRCALPHA)
    overlay.fill((8, 10, 16, 240))
    surface.blit(overlay, (0, 0))

    tome_rect = pygame.Rect(sw // 2 - 470, 25, 940, 670)
    pygame.draw.rect(surface, (20, 24, 38), tome_rect)
    pygame.draw.rect(surface, (60, 90, 140), tome_rect, 3)

    t_title = render_mixed_text("📖 ДРЕВНИЙ ГРИМУАР СИНТЕЗА КОМБО", game.font_title, game.font_sym_large, TEXT_GOLD)
    surface.blit(t_title, (tome_rect.centerx - t_title.get_width() // 2, 50))

    sub_t = game.font_med.render("Соединяй знаки подряд в течение 1.5 сек для получения сверх-заклинаний:", True, TEXT_WHITE)
    surface.blit(sub_t, (tome_rect.centerx - sub_t.get_width() // 2, 95))

    recipes = [
        ("❄ КРИО-МЕТЕОРИТ [| + V]", "Черти Метеор (|), затем сразу Ледяной знак (V).", "Метеорит обрушивается на арену и ВЫЗЫВАЕТ ВОЛНУ ЗАМОРОЗКИ по площади!", (140, 230, 255)),
        ("🔥 ОГНЕННЫЙ КОЛЛАПС [O + ^]", "Черти Черную дыру (O), затем сразу Инферно (^).", "Сингулярность воспламеняется, сжигая монстров и детонируя взрывом сверхновой!", (255, 140, 30)),
        ("🌌 ПРОСТРАНСТВЕННЫЙ РАЗРЫВ [X + —]", "Черти Крест (X), затем сразу Срез (—).", "Рассекает экран световыми трещинами по диагоналям и горизонтали арены (+155% урона)!", (140, 240, 255)),
        ("⏳ АБСОЛЮТНЫЙ ХРОНО-СТАЗИС [🛡 + ⌛]", "Черти Щит (🛡), затем сразу Песочные часы (⌛).", "Полная остановка времени на 4.5 секунды! Все враги и боссы замирают на месте!", (210, 100, 255)),
        ("☀ СВЕТОВОЙ КАТАКЛИЗМ [△ + ★]", "Черти Призму (△), затем сразу Звезду (★).", "Ослепляющая божественная вспышка на всю арену, детонирующая нежить и порождения тьмы!", (255, 255, 180))
    ]

    ry = 165
    for r_head, r_how, r_eff, r_col in recipes:
        pygame.draw.rect(surface, (28, 34, 52), (tome_rect.x + 30, ry, tome_rect.width - 60, 88))
        pygame.draw.rect(surface, r_col, (tome_rect.x + 30, ry, tome_rect.width - 60, 88), 1)

        h_s = render_mixed_text(r_head, game.font_med, game.font_sym_med, r_col)
        surface.blit(h_s, (tome_rect.x + 45, ry + 8))
        hw_s = render_mixed_text(f"Как начертить: {r_how}", game.font_small, game.font_sym_small, TEXT_GOLD)
        surface.blit(hw_s, (tome_rect.x + 45, ry + 34))
        ef_s = game.font_small.render(f"Эффект: {r_eff}", True, (210, 220, 240))
        surface.blit(ef_s, (tome_rect.x + 45, ry + 58))

        ry += 98

    exit_h = game.font_med.render("Нажми [ESC] или [E], чтобы закрыть книгу и вернуться в бой", True, (160, 180, 200))
    surface.blit(exit_h, (tome_rect.centerx - exit_h.get_width() // 2, ry + 10))


def draw_custom_glyph_forge(game, surface=None):
    """Renders the Custom Glyph Studio overlay."""
    if surface is None:
        surface = game.screen

    sw, sh = surface.get_width(), surface.get_height()
    overlay = pygame.Surface((sw, sh), pygame.SRCALPHA)
    overlay.fill((8, 10, 18, 245))
    surface.blit(overlay, (0, 0))

    title = render_mixed_text("✦ КУЗНИЦА СВОИХ ЗНАКОВ (CUSTOM GLYPH STUDIO) ✦", game.font_title, game.font_sym_large, TEXT_GOLD)
    surface.blit(title, (sw // 2 - title.get_width() // 2, 30))

    sub1 = game.font_med.render("Зажми ЛКМ/ПКМ и нарисуй В СВОБОДНОЙ ФОРМЕ любой свой знак комбо!", True, TEXT_WHITE)
    surface.blit(sub1, (sw // 2 - sub1.get_width() // 2, 75))

    box_w, box_h = 440, 440
    box_x = sw // 2 - box_w // 2
    box_y = 115
    canvas_rect = pygame.Rect(box_x, box_y, box_w, box_h)
    pygame.draw.rect(surface, (16, 20, 32), canvas_rect)
    pygame.draw.rect(surface, (255, 220, 80), canvas_rect, 3)

    pygame.draw.line(surface, (35, 45, 68), (box_x, box_y + box_h // 2), (box_x + box_w, box_y + box_h // 2), 1)
    pygame.draw.line(surface, (35, 45, 68), (box_x + box_w // 2, box_y), (box_x + box_w // 2, box_y + box_h), 1)
    pygame.draw.circle(surface, (45, 55, 85), (box_x + box_w // 2, box_y + box_h // 2), 140, 1)

    if len(game.custom_points) > 1:
        pygame.draw.lines(surface, (255, 235, 90), False, game.custom_points, 6)
        pygame.draw.lines(surface, (255, 255, 255), False, game.custom_points, 2)
        for pt in game.custom_points:
            pygame.draw.circle(surface, (255, 200, 50), pt, 4)

    fb_col = TEXT_GOLD if "СОХРАНЕН" in game.custom_glyph_feedback else TEXT_CYAN
    fb_surf = game.font_large.render(game.custom_glyph_feedback, True, fb_col)
    surface.blit(fb_surf, (sw // 2 - fb_surf.get_width() // 2, box_y + box_h + 18))

    controls_surf = game.font_med.render("[ENTER] — Сохранить знак в память  |  [BACKSPACE] — Очистить  |  [ESC / K] — Назад в игру", True, (180, 195, 220))
    surface.blit(controls_surf, (sw // 2 - controls_surf.get_width() // 2, box_y + box_h + 50))


def draw_pause_menu(game, surface=None):
    """Renders the Pause menu overlay with gameplay grimoire hints."""
    if surface is None:
        surface = game.screen

    sw, sh = surface.get_width(), surface.get_height()
    overlay = pygame.Surface((sw, sh), pygame.SRCALPHA)
    overlay.fill((6, 8, 14, 235))
    surface.blit(overlay, (0, 0))

    title = game.font_title.render("ПАУЗА В ИГРЕ", True, TEXT_GOLD)
    surface.blit(title, (sw // 2 - title.get_width() // 2, 22))

    # Fullscreen interactive toggle button in Pause Menu
    is_fs = getattr(game, 'is_fullscreen', False)
    btn_w = 270
    btn_h = 32
    btn_fs = pygame.Rect(sw // 2 - btn_w - 8, 60, btn_w, btn_h)
    m_pos = pygame.mouse.get_pos()
    is_fs_hov = btn_fs.collidepoint(m_pos)
    game.pause_rects = getattr(game, 'pause_rects', {})
    game.pause_rects["fullscreen"] = btn_fs

    fs_bg = (32, 48, 72) if is_fs_hov else (18, 28, 42)
    fs_bdr = TEXT_CYAN if is_fs else (70, 110, 160)
    fs_status = "ПОЛНЫЙ" if is_fs else "ОКОННЫЙ"
    pygame.draw.rect(surface, fs_bg, btn_fs, border_radius=6)
    pygame.draw.rect(surface, fs_bdr, btn_fs, 2 if is_fs else 1, border_radius=6)
    fs_lbl = game.font_small.render(f"[F11] ЭКРАН: {fs_status}", True, TEXT_CYAN if is_fs else TEXT_WHITE)
    surface.blit(fs_lbl, (btn_fs.centerx - fs_lbl.get_width() // 2, btn_fs.centery - fs_lbl.get_height() // 2))

    # Resolution interactive toggle button in Pause Menu
    cur_res = getattr(game, 'resolution_key', 'FHD')
    btn_res = pygame.Rect(sw // 2 + 8, 60, btn_w, btn_h)
    is_res_hov = btn_res.collidepoint(m_pos)
    game.pause_rects["resolution"] = btn_res

    res_bg = (40, 36, 68) if is_res_hov else (20, 22, 38)
    res_bdr = (255, 215, 80) if is_res_hov else (90, 80, 130)
    pygame.draw.rect(surface, res_bg, btn_res, border_radius=6)
    pygame.draw.rect(surface, res_bdr, btn_res, 1, border_radius=6)
    res_lbl = game.font_small.render(f"[F10] КАЧЕСТВО: {cur_res} (1080p/2K)", True, TEXT_GOLD)
    surface.blit(res_lbl, (btn_res.centerx - res_lbl.get_width() // 2, btn_res.centery - res_lbl.get_height() // 2))

    opts = [
        "[ESC / P] — Продолжить бой",
        "[F5] — Тест: Прыжок на 50-й этаж к Боссу Истины",
        "[F6] — Тест: Получить 20 урона  |  [F7] — Сбросить урон (0 HP No-Hit)",
        "[T] — Войти в Тренировочный Зал (Додзё)  |  [K] — Кузница Своих Знаков",
        "[R] — Начать забег заново  |  [M] — Главное Меню  |  [Q] — Выйти из игры"
    ]
    oy = 100
    for opt in opts:
        s = game.font_med.render(opt, True, TEXT_GOLD if "[F5]" in opt else TEXT_WHITE)
        surface.blit(s, (sw // 2 - s.get_width() // 2, oy))
        oy += 22

    guide_rect = pygame.Rect(sw // 2 - 490, 218, 980, 480)
    pygame.draw.rect(surface, (15, 20, 32), guide_rect)
    pygame.draw.rect(surface, (45, 60, 90), guide_rect, 2)

    gt_surf = game.font_large.render("ГРИМУАР СМЕРТЕЛЬНОГО ЧЕРЧЕНИЯ", True, TEXT_CYAN)
    surface.blit(gt_surf, (guide_rect.centerx - gt_surf.get_width() // 2, 230))

    grimoire_entries = [
        ("🛡 Блок Бастиона:", "Контур щита. Блокирует урон и включает Slo-Mo в 5 раз!"),
        ("⌛ Теневая Рокировка:", "Песочные часы. Меняет местами тебя и врага (BACKSTAB +200%)!"),
        ("★ Звезда Катаклизма:", "Пятиконечная звезда. Орбитальный взрыв на всю арену +15s таймера!"),
        ("⚔ Крестовой Разруб [X]:", "Крест 'X'. Пробивает броню и наносит двойной критический урон!"),
        ("△ Эгида Призмы [△]:", "Треугольник. Призматический щит, отбрасывающий врагов."),
        ("∞ Петля Омнислеш [∞]:", "Восьмерка / Петля. Шквал из 10 фантомных клинковых срезов!"),
        ("✦ Твой Знак Владыки [✦]:", "Собственный знак из Кузницы [K]! Сверхкритический урон x3!"),
        ("❄ Крио-Метеорит [| + V]:", "СИНТЕЗ: Метеор + Лед => Метеорит с ЗАМОРОЗКОЙ ВСЕХ ВРАГОВ ПО ОБЛАСТИ!"),
        ("🔥 Инферно-Коллапс [O + ^]:", "СИНТЕЗ: Черная дыра + Огонь => Пылающая гравитационная воронка!"),
        ("🌌 Пространство [X + —]:", "СИНТЕЗ: Крест + Срез => Световые трещины по всей арене!"),
        ("⏳ Хроно-Стазис [🛡 + ⌛]:", "СИНТЕЗ: Щит + Часы => Полная остановка времени на 4.5 сек!")
    ]
    gy = 264
    for sym, desc in grimoire_entries:
        s1 = render_mixed_text(sym, game.font_med, game.font_sym_med, TEXT_GOLD)
        surface.blit(s1, (guide_rect.x + 25, gy))
        s2 = render_mixed_text(desc, game.font_small, game.font_sym_small, (210, 220, 240))
        surface.blit(s2, (guide_rect.x + 270, gy + 3))
        gy += 38


def draw_perk_selection(game, surface=None):
    """Renders the Floor Cleared perk/offering selection screen."""
    if surface is None:
        surface = game.screen

    sw, sh = surface.get_width(), surface.get_height()
    overlay = pygame.Surface((sw, sh), pygame.SRCALPHA)
    overlay.fill((8, 12, 20, 245))
    surface.blit(overlay, (0, 0))

    fl_win = game.font_title.render(f"ЭТАЖ {game.current_floor_data['floor']} ЗАЧИЩЕН!", True, TEXT_GOLD)
    surface.blit(fl_win, (sw // 2 - fl_win.get_width() // 2, 35))

    if CHALLENGE_MANAGER.should_offer_only_curses():
        sub = render_mixed_text("☠ ЧЕРТОГ ЧИСТИЛИЩА: ТОЛЬКО ДЕБАФФЫ (0 БАФФОВ)! ☠", game.font_large, game.font_sym_large, (255, 90, 130))
    else:
        sub = game.font_large.render("ВРАТА БЕЗДНЫ: ВЫБЕРИ ДВУЕДИНЫЙ ПАКТ ИЛИ ПРОКЛЯТЫЙ ДАР:", True, TEXT_WHITE)
    surface.blit(sub, (sw // 2 - sub.get_width() // 2, 78))

    fonts_dict = {
        "large": game.font_large,
        "med": game.font_med,
        "small": game.font_small,
        "sym_large": game.font_sym_large,
        "sym_med": game.font_sym_med,
        "sym_small": game.font_sym_small
    }

    card_w = 780
    card_h = 118
    card_x = sw // 2 - card_w // 2
    card_y_start = 125
    card_gap = 135
    m_pos = pygame.mouse.get_pos()

    offerings = getattr(game, 'current_portal_offerings', [])
    for idx, offering in enumerate(offerings):
        c_rect = pygame.Rect(card_x, card_y_start + idx * card_gap, card_w, card_h)
        is_hov = c_rect.collidepoint(m_pos)

        if offering.is_cursed:
            draw_cracked_cursed_card(surface, c_rect, offering, game.anim_time, is_hov, fonts_dict)
        else:
            draw_double_edged_card(surface, c_rect, offering, game.anim_time, is_hov, fonts_dict)

        badge_rect = pygame.Rect(c_rect.right - 58, c_rect.y + 12, 44, 30)
        badge_col = (230, 100, 255) if offering.is_cursed else TEXT_GOLD
        pygame.draw.rect(surface, (12, 14, 22), badge_rect)
        pygame.draw.rect(surface, badge_col, badge_rect, 2)
        k_surf = game.font_large.render(f"[{idx + 1}]", True, badge_col)
        surface.blit(k_surf, (badge_rect.centerx - k_surf.get_width() // 2, badge_rect.centery - k_surf.get_height() // 2))

    hint = game.font_med.render("Нажми клавишу [1], [2] или [3] на клавиатуре, либо нажми ЛКМ по карточке", True, (170, 190, 215))
    surface.blit(hint, (sw // 2 - hint.get_width() // 2, 555))

    if CHALLENGE_MANAGER.should_offer_only_curses():
        c_badge = render_mixed_text("☠ АКТИВНО УСЛОЖНЕНИЕ «ТОЛЬКО ДЕБАФФЫ» — ПОРТАЛ ПРЕДЛАГАЕТ ЛИШЬ ПРОКЛЯТИЯ! ☠", game.font_med, game.font_sym_med, (255, 80, 120))
        surface.blit(c_badge, (sw // 2 - c_badge.get_width() // 2, 590))
    elif getattr(game.player, 'curse_count', 0) > 0:
        c_badge = render_mixed_text(f"☠ НАКОПЛЕННЫЕ ПРОКЛЯТИЯ БЕЗДНЫ: {game.player.curse_count} (Суммарные дебаффы активны) ☠", game.font_med, game.font_sym_med, (240, 90, 255))
        surface.blit(c_badge, (sw // 2 - c_badge.get_width() // 2, 590))


def draw_permadeath(game, surface=None):
    """Renders the game over screen with interactive buttons."""
    if surface is None:
        surface = game.screen

    sw, sh = surface.get_width(), surface.get_height()
    overlay = pygame.Surface((sw, sh), pygame.SRCALPHA)
    overlay.fill((8, 10, 16, 230))
    surface.blit(overlay, (0, 0))

    death_msg = "ВРЕМЯ ИСТЕКЛО" if game.zone_timer <= 0 else "ВЫ ПОГИБЛИ"

    # Shadow and title text
    title_shadow = game.font_title.render(death_msg, True, (40, 10, 15))
    surface.blit(title_shadow, (sw // 2 - title_shadow.get_width() // 2 + 3, sh // 2 - 93))
    death_surf = game.font_title.render(death_msg, True, TEXT_RED)
    surface.blit(death_surf, (sw // 2 - death_surf.get_width() // 2, sh // 2 - 95))

    floor_num = game.current_floor_data.get('floor', 1) if getattr(game, 'current_floor_data', None) else 1
    score_surf = game.font_large.render(f"Достигнут Этаж: {floor_num}", True, TEXT_GOLD)
    surface.blit(score_surf, (sw // 2 - score_surf.get_width() // 2, sh // 2 - 32))

    diff_obj = getattr(DIFFICULTY_MANAGER, 'current', None)
    if diff_obj:
        diff_info = f"Сложность: {diff_obj.name.upper()}"
        diff_surf = game.font_med.render(diff_info, True, (185, 205, 230))
        surface.blit(diff_surf, (sw // 2 - diff_surf.get_width() // 2, sh // 2 + 10))

    # Interactive Retro Buttons
    btn_w, btn_h = 240, 52
    btn_y = sh // 2 + 65
    btn_restart = pygame.Rect(sw // 2 - btn_w - 15, btn_y, btn_w, btn_h)
    btn_menu = pygame.Rect(sw // 2 + 15, btn_y, btn_w, btn_h)

    game.death_rects = {
        "restart": btn_restart,
        "menu": btn_menu
    }

    fonts = {
        "title": game.font_title,
        "large": game.font_large,
        "med": game.font_med,
        "small": game.font_small,
    }

    m_pos = pygame.mouse.get_pos()
    is_hover_r = btn_restart.collidepoint(m_pos)
    is_hover_m = btn_menu.collidepoint(m_pos)

    draw_pixel_button(
        surface, btn_restart, "ЗАНОВО",
        key_badge="[R]",
        icon_surface=get_pixel_icon("SWORD"),
        theme_color=(100, 235, 255),
        is_hover=is_hover_r,
        fonts=fonts,
        anim_time=getattr(game, 'anim_time', 0.0)
    )

    draw_pixel_button(
        surface, btn_menu, "В МЕНЮ",
        key_badge="[M]",
        icon_surface=get_pixel_icon("BACK"),
        theme_color=(255, 215, 80),
        is_hover=is_hover_m,
        fonts=fonts,
        anim_time=getattr(game, 'anim_time', 0.0)
    )

    hint_surf = game.font_small.render("Нажми клавишу [R] для перезапуска или [M] / [ESC] для выхода в главное меню", True, (140, 160, 185))
    surface.blit(hint_surf, (sw // 2 - hint_surf.get_width() // 2, sh // 2 + 138))


draw_game_over = draw_permadeath


def draw_cursor_recharge(game, surface=None):
    """Renders the radial recharge gauge around the mouse cursor when on cooldown."""
    if surface is None:
        surface = game.screen

    if game.state in ('PLAYING', 'DOJO'):
        mx, my = pygame.mouse.get_pos()
        if getattr(game, 'draw_cooldown', 0.0) > 0:
            prog = 1.0 - (game.draw_cooldown / max(0.01, getattr(game, 'max_draw_cooldown', 0.85)))
            pygame.draw.circle(surface, (255, 80, 40), (mx, my), 16, 2)
            arc_rect = pygame.Rect(mx - 16, my - 16, 32, 32)
            arc_ang = max(0.05, prog * 2 * math.pi)
            pygame.draw.arc(surface, (100, 235, 255), arc_rect, -math.pi/2, -math.pi/2 + arc_ang, 3)


def draw_restart_confirmation_modal(game, surface=None):
    """
    Renders an in-game confirmation modal when the player attempts to restart an active run.
    Prevents accidental progress loss during gameplay.
    """
    if surface is None:
        surface = game.screen

    sw, sh = surface.get_width(), surface.get_height()
    # 1. Dark semi-transparent backdrop
    overlay = pygame.Surface((sw, sh), pygame.SRCALPHA)
    overlay.fill((6, 8, 14, 225))
    surface.blit(overlay, (0, 0))

    # 2. Centered Modal Box
    mw, mh = 640, 270
    mx = sw // 2 - mw // 2
    my = sh // 2 - mh // 2
    modal_rect = pygame.Rect(mx, my, mw, mh)

    # Base Fill & Beveled Borders
    pygame.draw.rect(surface, (14, 18, 28), modal_rect, border_radius=8)
    pygame.draw.rect(surface, (255, 140, 40), modal_rect, 2, border_radius=8)

    # Inner subtle rim
    inner_rect = pygame.Rect(mx + 4, my + 4, mw - 8, mh - 8)
    pygame.draw.rect(surface, (45, 65, 95), inner_rect, 1, border_radius=6)

    # Metallic corner rivets
    for (rx, ry) in [(mx + 8, my + 8), (modal_rect.right - 12, my + 8),
                     (mx + 8, modal_rect.bottom - 12), (modal_rect.right - 12, modal_rect.bottom - 12)]:
        pygame.draw.rect(surface, (8, 10, 16), (rx - 1, ry - 1, 6, 6))
        pygame.draw.rect(surface, (255, 215, 80), (rx, ry, 3, 3))

    # 3. Warning Title
    title_surf = game.font_large.render("ПОДТВЕРЖДЕНИЕ ПЕРЕЗАПУСКА", True, TEXT_GOLD)
    surface.blit(title_surf, (modal_rect.centerx - title_surf.get_width() // 2, my + 24))

    # Decorative header divider line
    div_y = my + 64
    pygame.draw.line(surface, (60, 85, 125), (mx + 30, div_y), (modal_rect.right - 30, div_y), 1)
    pygame.draw.line(surface, (255, 215, 80), (modal_rect.centerx - 70, div_y), (modal_rect.centerx + 70, div_y), 2)

    # 4. Prompt Messages
    msg_line1 = game.font_med.render("Вы действительно хотите начать забег заново?", True, TEXT_WHITE)
    surface.blit(msg_line1, (modal_rect.centerx - msg_line1.get_width() // 2, my + 82))

    msg_line2 = game.font_med.render("Текущий этаж, руны и экипировка будут сброшены!", True, (255, 130, 120))
    surface.blit(msg_line2, (modal_rect.centerx - msg_line2.get_width() // 2, my + 116))

    # 5. Interactive Action Buttons
    btn_w, btn_h = 250, 52
    btn_y = my + 172
    btn_confirm = pygame.Rect(mx + 45, btn_y, btn_w, btn_h)
    btn_cancel = pygame.Rect(modal_rect.right - btn_w - 45, btn_y, btn_w, btn_h)

    fonts = {
        "title": game.font_title,
        "large": game.font_large,
        "med": game.font_med,
        "small": game.font_small,
    }

    m_pos = pygame.mouse.get_pos()
    is_hov_conf = btn_confirm.collidepoint(m_pos)
    is_hov_canc = btn_cancel.collidepoint(m_pos)

    # Confirm Button (Red Warning)
    draw_pixel_button(
        surface, btn_confirm, "ПЕРЕЗАПУСК",
        key_badge="[Y]",
        icon_surface=get_pixel_icon("SWORD"),
        theme_color=(255, 75, 75),
        is_hover=is_hov_conf,
        fonts=fonts,
        anim_time=getattr(game, 'anim_time', 0.0)
    )

    # Cancel Button (Cyan Return)
    draw_pixel_button(
        surface, btn_cancel, "ОТМЕНА",
        key_badge="[ESC]",
        icon_surface=get_pixel_icon("BACK"),
        theme_color=(100, 235, 255),
        is_hover=is_hov_canc,
        fonts=fonts,
        anim_time=getattr(game, 'anim_time', 0.0)
    )

    # Sub-hint
    hint_surf = game.font_small.render("Нажми [Y / ENTER] для сброса забега  |  [ESC / N] для отмены", True, (140, 165, 195))
    surface.blit(hint_surf, (modal_rect.centerx - hint_surf.get_width() // 2, my + 236))

    return {
        "modal_rect": modal_rect,
        "confirm": btn_confirm,
        "cancel": btn_cancel
    }


def draw_speedrun_confirmation_modal(game, surface=None):
    """
    Renders an in-game confirmation modal when the player triggers Speedrun mode via '/'.
    Ensures the player confirms starting a speedrun, resetting progress to floor 1 with a live chronometer.
    """
    if surface is None:
        surface = game.screen

    sw, sh = surface.get_width(), surface.get_height()
    overlay = pygame.Surface((sw, sh), pygame.SRCALPHA)
    overlay.fill((6, 8, 14, 225))
    surface.blit(overlay, (0, 0))

    mw, mh = 660, 290
    mx = sw // 2 - mw // 2
    my = sh // 2 - mh // 2
    modal_rect = pygame.Rect(mx, my, mw, mh)

    pygame.draw.rect(surface, (14, 18, 28), modal_rect, border_radius=8)
    pulse = 0.5 + 0.5 * math.sin(game.anim_time * 6.0)
    border_col = (255, int(190 + 65 * pulse), 60)
    pygame.draw.rect(surface, border_col, modal_rect, 2, border_radius=8)

    inner_rect = pygame.Rect(mx + 4, my + 4, mw - 8, mh - 8)
    pygame.draw.rect(surface, (28, 36, 56), inner_rect, 1, border_radius=6)

    # Metallic corner rivets
    for (rx, ry) in [(mx + 8, my + 8), (modal_rect.right - 12, my + 8),
                     (mx + 8, modal_rect.bottom - 12), (modal_rect.right - 12, modal_rect.bottom - 12)]:
        pygame.draw.rect(surface, (8, 10, 16), (rx - 1, ry - 1, 6, 6))
        pygame.draw.rect(surface, (255, 215, 80), (rx, ry, 3, 3))

    title_surf = game.font_large.render("СТАРТ РЕЖИМА СПИДРАНА", True, (255, 215, 80))
    surface.blit(title_surf, (modal_rect.centerx - title_surf.get_width() // 2, my + 22))

    div_y = my + 60
    pygame.draw.line(surface, (60, 85, 125), (mx + 30, div_y), (modal_rect.right - 30, div_y), 1)
    pygame.draw.line(surface, (255, 215, 80), (modal_rect.centerx - 70, div_y), (modal_rect.centerx + 70, div_y), 2)

    msg1 = game.font_med.render("Запустить скоростной забег с миллисекундным таймером?", True, TEXT_WHITE)
    surface.blit(msg1, (modal_rect.centerx - msg1.get_width() // 2, my + 80))

    msg2 = game.font_small.render("Забег начнется с 1-го этажа со сбросом времени и фиксацией сплитов!", True, (160, 225, 255))
    surface.blit(msg2, (modal_rect.centerx - msg2.get_width() // 2, my + 114))

    pb_time = getattr(game, 'speedrun_best_time', None)
    if pb_time:
        pb_m = int(pb_time // 60)
        pb_s = int(pb_time % 60)
        pb_ms = int((pb_time * 1000) % 1000)
        msg_pb = game.font_small.render(f"Ваш лучший рекорд (PB): {pb_m:02d}:{pb_s:02d}.{pb_ms:03d}", True, (255, 215, 80))
        surface.blit(msg_pb, (modal_rect.centerx - msg_pb.get_width() // 2, my + 140))

    btn_w, btn_h = 250, 52
    btn_y = my + 188
    btn_confirm = pygame.Rect(mx + 45, btn_y, btn_w, btn_h)
    btn_cancel = pygame.Rect(modal_rect.right - btn_w - 45, btn_y, btn_w, btn_h)

    fonts = {
        "title": game.font_title,
        "large": game.font_large,
        "med": game.font_med,
        "small": game.font_small,
    }

    m_pos = pygame.mouse.get_pos()
    is_hov_conf = btn_confirm.collidepoint(m_pos)
    is_hov_canc = btn_cancel.collidepoint(m_pos)

    draw_pixel_button(
        surface, btn_confirm, "СТАРТ",
        key_badge="[ENTER]",
        icon_surface=get_pixel_icon("SWORD"),
        theme_color=(255, 215, 60),
        is_hover=is_hov_conf,
        fonts=fonts,
        anim_time=getattr(game, 'anim_time', 0.0)
    )

    draw_pixel_button(
        surface, btn_cancel, "ОТМЕНА",
        key_badge="[ESC]",
        icon_surface=get_pixel_icon("BACK"),
        theme_color=(100, 235, 255),
        is_hover=is_hov_canc,
        fonts=fonts,
        anim_time=getattr(game, 'anim_time', 0.0)
    )

    hint_surf = game.font_small.render("Нажми [ENTER / Y] для старта  |  [ESC / N] для отмены", True, (140, 165, 195))
    surface.blit(hint_surf, (modal_rect.centerx - hint_surf.get_width() // 2, my + 252))

    return {
        "modal_rect": modal_rect,
        "confirm": btn_confirm,
        "cancel": btn_cancel
    }

