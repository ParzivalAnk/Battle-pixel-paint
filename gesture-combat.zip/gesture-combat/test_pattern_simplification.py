import math
from recognizer import Point, resample, scale_and_center

def build_all():
    patterns = {}

    # 1. CRESCENT_BLADE (Tier 1 - 1 glyph, simple slash / thrust)
    pts_cres = []
    for i in range(32):
        t = i / 31.0
        x = 20.0 + 60.0 * t
        y = 50.0 - 32.0 * math.sin(math.pi * t)
        pts_cres.append(Point(x, y))
    for i in range(32):
        t = i / 31.0
        x = 80.0 - 60.0 * t
        y = 50.0 + 14.0 * math.sin(math.pi * t)
        pts_cres.append(Point(x, y))
    patterns["CRESCENT_BLADE"] = {
        "id": "CRESCENT_BLADE",
        "name": "Серповидный Клинок: Дуга Ветра",
        "symbol": "🌙",
        "color": (120, 240, 255),
        "desc": "Плавная серповидная дуга рассекающего ветра. Простой и быстрый росчерк!",
        "is_closed": True,
        "duration": 18.0,
        "boss_req": 0,
        "resampled": scale_and_center(resample(pts_cres, 64), 100.0),
        "raw_verts": [(20, 50), (50, 18), (80, 50), (50, 64), (20, 50)]
    }

    # 2. TRIANGLE_APEX (Tier 1 - 1 glyph, vertical meteor / uppercut)
    v_tri = [(50, 16), (84, 82), (16, 82), (50, 16)]
    pts_tri = []
    for i in range(len(v_tri) - 1):
        x1, y1 = v_tri[i]; x2, y2 = v_tri[i+1]
        for s in range(12):
            t = s / 12.0
            pts_tri.append(Point(x1 + t*(x2-x1), y1 + t*(y2-y1)))
    pts_tri.append(Point(v_tri[-1][0], v_tri[-1][1]))
    patterns["TRIANGLE_APEX"] = {
        "id": "TRIANGLE_APEX",
        "name": "Пирамида Стихий: Клинок Зари",
        "symbol": "△",
        "color": (255, 210, 80),
        "desc": "Священный треугольник стихий. 3 четкие грани и вершины!",
        "is_closed": True,
        "duration": 18.0,
        "boss_req": 0,
        "resampled": scale_and_center(resample(pts_tri, 64), 100.0),
        "raw_verts": v_tri
    }

    # 3. DIAMOND_SEAL (Tier 2 - 2 glyphs)
    v_dia = [(50, 14), (86, 50), (50, 86), (14, 50), (50, 14)]
    pts_dia = []
    for i in range(len(v_dia) - 1):
        x1, y1 = v_dia[i]; x2, y2 = v_dia[i+1]
        for s in range(12):
            t = s / 12.0
            pts_dia.append(Point(x1 + t*(x2-x1), y1 + t*(y2-y1)))
    pts_dia.append(Point(v_dia[-1][0], v_dia[-1][1]))
    patterns["DIAMOND_SEAL"] = {
        "id": "DIAMOND_SEAL",
        "name": "Алмаз Равновесия: Ромб Света",
        "symbol": "✦",
        "color": (255, 180, 50),
        "desc": "Четырехконечный алмазный кристалл. Четкий контур четырех сторон!",
        "is_closed": True,
        "duration": 19.0,
        "boss_req": 0,
        "resampled": scale_and_center(resample(pts_dia, 64), 100.0),
        "raw_verts": v_dia
    }

    # 4. HEXAGRAM_SEAL (Tier 2 - 2 glyphs)
    v_hex = [
        (50, 6), (68, 36), (94, 36), (72, 54),
        (82, 86), (50, 66), (18, 86), (28, 54),
        (6, 36), (32, 36), (50, 6)
    ]
    pts_hex = []
    for i in range(len(v_hex) - 1):
        x1, y1 = v_hex[i]; x2, y2 = v_hex[i+1]
        for s in range(8):
            t = s / 8.0
            pts_hex.append(Point(x1 + t*(x2-x1), y1 + t*(y2-y1)))
    pts_hex.append(Point(v_hex[-1][0], v_hex[-1][1]))
    patterns["HEXAGRAM_SEAL"] = {
        "id": "HEXAGRAM_SEAL",
        "name": "Гексаграмма Равновесия: Печать Соломона",
        "symbol": "✡",
        "color": (255, 160, 60),
        "desc": "Уникурсальная шестиконечная печать гармонии материи и духа!",
        "is_closed": True,
        "duration": 19.0,
        "boss_req": 0,
        "resampled": scale_and_center(resample(pts_hex, 64), 100.0),
        "raw_verts": v_hex
    }

    # 5. AETHER_LEMNISCATE (Tier 2 - 2 glyphs)
    pts_lem = []
    for i in range(72):
        t = (2.0 * math.pi * i) / 71.0
        x = 50.0 + 38.0 * math.sin(t)
        y = 50.0 + 38.0 * math.sin(t) * math.cos(t)
        pts_lem.append(Point(x, y))
    patterns["AETHER_LEMNISCATE"] = {
        "id": "AETHER_LEMNISCATE",
        "name": "Омни-Петля: Бесконечность",
        "symbol": "∞",
        "color": (190, 130, 255),
        "desc": "Плавная непрерывная петля бесконечности. Вечный ток маны!",
        "is_closed": True,
        "duration": 20.0,
        "boss_req": 0,
        "resampled": scale_and_center(resample(pts_lem, 64), 100.0),
        "raw_verts": [(50, 50), (88, 50), (50, 50), (12, 50), (50, 50)]
    }

    # 6. CROWN_SERAPHIM (Tier 2 - 2 glyphs)
    v_crown = [
        (18, 80), (15, 36), (32, 56), (50, 14), (68, 56), (85, 36), (82, 80), (18, 80)
    ]
    pts_crown = []
    for i in range(len(v_crown) - 1):
        x1, y1 = v_crown[i]; x2, y2 = v_crown[i+1]
        for s in range(8):
            t = s / 8.0
            pts_crown.append(Point(x1 + t*(x2-x1), y1 + t*(y2-y1)))
    pts_crown.append(Point(v_crown[-1][0], v_crown[-1][1]))
    patterns["CROWN_SERAPHIM"] = {
        "id": "CROWN_SERAPHIM",
        "name": "Венец Серафима: Божественный Суд",
        "symbol": "👑",
        "color": (255, 220, 60),
        "desc": "Трехзубчатая священная корона с прямым основанием!",
        "is_closed": True,
        "duration": 20.0,
        "boss_req": 0,
        "resampled": scale_and_center(resample(pts_crown, 64), 100.0),
        "raw_verts": v_crown
    }

    # 7. OCULUS_VOID (Tier 3 - 3 glyphs) - Single continuous almond mystic eye!
    pts_eye = []
    # Upper arch with outer flare
    for i in range(32):
        t = i / 31.0
        x = 12.0 + 76.0 * t
        y = 50.0 - 32.0 * math.sin(math.pi * t)
        pts_eye.append(Point(x, y))
    # Lower arch returning
    for i in range(32):
        t = i / 31.0
        x = 88.0 - 76.0 * t
        y = 50.0 + 32.0 * math.sin(math.pi * t)
        pts_eye.append(Point(x, y))
    patterns["OCULUS_VOID"] = {
        "id": "OCULUS_VOID",
        "name": "Око Бездны: Взгляд Пустоты",
        "symbol": "❂",
        "color": (180, 80, 255),
        "desc": "Мистический контур ока Бездны. Плавная непрерывная миндалевидная дуга!",
        "is_closed": True,
        "duration": 22.0,
        "boss_req": 0,
        "resampled": scale_and_center(resample(pts_eye, 64), 100.0),
        "raw_verts": [(12, 50), (50, 18), (88, 50), (50, 82), (12, 50)]
    }

    # 8. CHRONO_HOURGLASS_KNOT (Tier 3 - 3 glyphs, Boss 1 Unlock)
    v_hg = [(25, 20), (75, 20), (25, 80), (75, 80), (25, 20)]
    pts_hg = []
    for i in range(len(v_hg) - 1):
        x1, y1 = v_hg[i]; x2, y2 = v_hg[i+1]
        for s in range(12):
            t = s / 12.0
            pts_hg.append(Point(x1 + t*(x2-x1), y1 + t*(y2-y1)))
    pts_hg.append(Point(v_hg[-1][0], v_hg[-1][1]))
    patterns["CHRONO_HOURGLASS_KNOT"] = {
        "id": "CHRONO_HOURGLASS_KNOT",
        "name": "Хроно-Разлом: Временной Узел",
        "symbol": "⌛",
        "color": (90, 235, 255),
        "desc": "Песочные часы времени. 4 прямые грани с верхним и нижним основанием!",
        "is_closed": True,
        "duration": 22.0,
        "boss_req": 1,
        "resampled": scale_and_center(resample(pts_hg, 64), 100.0),
        "raw_verts": v_hg
    }

    # 9. VALKIRIA_BLADE_CREST (Tier 3 - 3 glyphs, Boss 2 Unlock)
    v_valk = [
        (50, 12), (75, 40), (88, 75), (50, 60), (12, 75), (25, 40), (50, 12)
    ]
    pts_valk = []
    for i in range(len(v_valk) - 1):
        x1, y1 = v_valk[i]; x2, y2 = v_valk[i+1]
        for s in range(10):
            t = s / 10.0
            pts_valk.append(Point(x1 + t*(x2-x1), y1 + t*(y2-y1)))
    pts_valk.append(Point(v_valk[-1][0], v_valk[-1][1]))
    patterns["VALKIRIA_BLADE_CREST"] = {
        "id": "VALKIRIA_BLADE_CREST",
        "name": "Герб Владычицы Клинков: Танец Стали",
        "symbol": "⚔",
        "color": (255, 130, 70),
        "desc": "Крылатый шеврон клинков Валькирии. 100% пробивание брони!",
        "is_closed": True,
        "duration": 23.0,
        "boss_req": 2,
        "resampled": scale_and_center(resample(pts_valk, 64), 100.0),
        "raw_verts": v_valk
    }

    # 10. HEPTAGRAM_CHAOS (Tier 4 - 4 glyphs)
    order_hept = [0, 3, 6, 2, 5, 1, 4, 0]
    v_hept = []
    for k in order_hept:
        ang = -math.pi / 2.0 + k * (2.0 * math.pi / 7.0)
        v_hept.append((50.0 + 40.0 * math.cos(ang), 50.0 + 40.0 * math.sin(ang)))
    pts_hept = []
    for i in range(len(v_hept) - 1):
        x1, y1 = v_hept[i]; x2, y2 = v_hept[i+1]
        for s in range(10):
            t = s / 10.0
            pts_hept.append(Point(x1 + t*(x2-x1), y1 + t*(y2-y1)))
    pts_hept.append(Point(v_hept[-1][0], v_hept[-1][1]))
    patterns["HEPTAGRAM_CHAOS"] = {
        "id": "HEPTAGRAM_CHAOS",
        "name": "Семиконечная Звезда Хаоса {7/3}",
        "symbol": "★",
        "color": (255, 60, 85),
        "desc": "Древняя семиконечная печать {7/3}. Непрерывно обведи все 7 лучей звезды!",
        "is_closed": True,
        "duration": 22.0,
        "boss_req": 0,
        "resampled": scale_and_center(resample(pts_hept, 64), 100.0),
        "raw_verts": v_hept
    }

    # 11. NECRO_SPIRE_SIGIL (Tier 4 - 4 glyphs, Boss 3 Unlock)
    v_necro = [(50, 92), (18, 32), (82, 32), (50, 92), (50, 8), (50, 92)]
    pts_necro = []
    for i in range(len(v_necro) - 1):
        x1, y1 = v_necro[i]; x2, y2 = v_necro[i+1]
        for s in range(10):
            t = s / 10.0
            pts_necro.append(Point(x1 + t*(x2-x1), y1 + t*(y2-y1)))
    pts_necro.append(Point(v_necro[-1][0], v_necro[-1][1]))
    patterns["NECRO_SPIRE_SIGIL"] = {
        "id": "NECRO_SPIRE_SIGIL",
        "name": "Печать Архилича: Шпиль Скверны",
        "symbol": "☠",
        "color": (120, 255, 140),
        "desc": "Перевернутая пирамида душ со сквозным шпилем некромантии!",
        "is_closed": True,
        "duration": 24.0,
        "boss_req": 3,
        "resampled": scale_and_center(resample(pts_necro, 64), 100.0),
        "raw_verts": v_necro
    }

    # 12. COSMIC_PENTACLE_SUPREME (Tier 5 - 5 glyphs! Ultimate Finisher!)
    order_star = [0, 2, 4, 1, 3, 0]
    v_star = []
    for idx in order_star:
        ang = -math.pi / 2.0 + idx * (2.0 * math.pi / 5.0)
        v_star.append((50.0 + 38.0 * math.cos(ang), 50.0 + 38.0 * math.sin(ang)))
    pts_star = []
    for i in range(len(v_star) - 1):
        x1, y1 = v_star[i]; x2, y2 = v_star[i+1]
        for s in range(12):
            t = s / 12.0
            pts_star.append(Point(x1 + t*(x2-x1), y1 + t*(y2-y1)))
    pts_star.append(Point(v_star[-1][0], v_star[-1][1]))
    patterns["COSMIC_PENTACLE_SUPREME"] = {
        "id": "COSMIC_PENTACLE_SUPREME",
        "name": "Сверхновая Пяти Стихий: Великая Печать",
        "symbol": "✦",
        "color": (255, 235, 90),
        "desc": "Великая пятиконечная печать стихийного синтеза. Активирует финишер катсцены!",
        "is_closed": True,
        "duration": 25.0,
        "boss_req": 0,
        "resampled": scale_and_center(resample(pts_star, 64), 100.0),
        "raw_verts": v_star
    }

    # 13. JUDGEMENT_SCALES (Tier 5 - 5 glyphs, Boss 4 / 50 Unlock)
    v_judge = [
        (50, 10), (14, 28), (86, 28), (50, 10),
        (50, 88), (24, 88), (76, 88), (50, 88),
        (14, 28), (4, 56), (24, 56), (14, 28),
        (86, 28), (76, 56), (96, 56), (86, 28),
        (50, 10)
    ]
    pts_judge = []
    for i in range(len(v_judge) - 1):
        x1, y1 = v_judge[i]; x2, y2 = v_judge[i+1]
        for s in range(8):
            t = s / 8.0
            pts_judge.append(Point(x1 + t*(x2-x1), y1 + t*(y2-y1)))
    pts_judge.append(Point(v_judge[-1][0], v_judge[-1][1]))
    patterns["JUDGEMENT_SCALES"] = {
        "id": "JUDGEMENT_SCALES",
        "name": "Весы Истины: Абсолютный Вердикт",
        "symbol": "⚖",
        "color": (255, 240, 150),
        "desc": "Небесные Весы Правосудия. Абсолютное уничтожение всей арены!",
        "is_closed": True,
        "duration": 25.0,
        "boss_req": 4,
        "resampled": scale_and_center(resample(pts_judge, 64), 100.0),
        "raw_verts": v_judge
    }

    return patterns

if __name__ == '__main__':
    p = build_all()
    print(f'Successfully verified {len(p)} patterns!')
    for pid, data in p.items():
        print(f'{pid}: duration={data["duration"]}s, boss_req={data["boss_req"]}')
