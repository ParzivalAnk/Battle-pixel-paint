"""
entities.py - Game Actors and Entities: Player, Enemy, and PentagramCataclysm.
Part of the GLYPH-BLADE modular architecture.
"""

import math
import random
import pygame

from config import MAP_WIDTH, MAP_HEIGHT, TEXT_GOLD, TEXT_CYAN, TEXT_RED, TEXT_WHITE
from difficulty import DIFFICULTY_MANAGER
from challenges import CHALLENGE_MANAGER
from achievements import ACHIEVEMENT_MANAGER
from weapons import WEAPONS
from bestiary import BESTIARY, DAMAGE_CATEGORIES, get_spell_damage_categories
from bosses import init_boss_combat_state, update_boss_ai, check_and_perform_boss_dodge


class Player:
    def __init__(self, x, y):
        self.x = float(x)
        self.y = float(y)
        self.vx = 0.0
        self.vy = 0.0
        self.radius = 16
        diff = DIFFICULTY_MANAGER.current
        self.max_hp = diff.player_hp
        self.hp = diff.player_hp
        self.weapon_slots = {
            1: WEAPONS[1],
            2: WEAPONS[2],
            3: WEAPONS[3]
        }
        self.active_weapon_slot = 2
        self.weapon = self.weapon_slots[2]
        self.damage_taken_in_wave = False
        self.total_damage_taken_run = 0.0
        self.total_hits_taken_run = 0
        
        self.bonus_damage_mult = 1.0
        self.bonus_time_per_floor = 0.0
        self.speed_mult = 1.0
        self.damage_taken_mult = 1.0
        self.timer_drain_mult = 1.0
        self.bonus_jitter = 0.0
        self.lifesteal_per_kill = 0
        self.lifesteal_percent = 0.0
        self.freeze_duration_bonus = 0.0
        self.cataclysm_execute = False
        self.fusion_damage_bonus = 0.0
        self.curse_count = 0

        self.recovery_timer = 0.0
        self.fumble_timer = 0.0
        self.i_frame_timer = 0.0
        self.combo_count = 0
        self.combo_timer = 0.0
        self.alive = True
        self.aim_angle = 0.0
        self.cast_anim_timer = 0.0
        self.walk_timer = 0.0

    def switch_weapon_slot(self, slot: int) -> bool:
        if slot in self.weapon_slots and self.weapon_slots[slot]:
            self.active_weapon_slot = slot
            self.weapon = self.weapon_slots[slot]
            return True
        return False

    def equip_weapon(self, new_weapon, slot=None):
        if slot is None:
            slot = self.active_weapon_slot
        old_weapon = self.weapon_slots.get(slot)
        self.weapon_slots[slot] = new_weapon
        if slot == self.active_weapon_slot:
            self.weapon = new_weapon
        return old_weapon

    def update(self, dt, keys, inertia_mult, obstacles):
        if not self.alive:
            self.vx = 0.0
            self.vy = 0.0
            return

        if self.recovery_timer > 0:
            self.recovery_timer = max(0.0, self.recovery_timer - dt)
        if self.fumble_timer > 0:
            self.fumble_timer = max(0.0, self.fumble_timer - dt)
        if self.i_frame_timer > 0:
            self.i_frame_timer = max(0.0, self.i_frame_timer - dt)

        if self.combo_timer > 0:
            self.combo_timer = max(0.0, self.combo_timer - dt)
            if self.combo_timer <= 0:
                self.combo_count = 0

        move_x = 0.0
        move_y = 0.0
        if self.fumble_timer <= 0:
            if keys[pygame.K_w] or keys[pygame.K_UP]:
                move_y -= 1.0
            if keys[pygame.K_s] or keys[pygame.K_DOWN]:
                move_y += 1.0
            if keys[pygame.K_a] or keys[pygame.K_LEFT]:
                move_x -= 1.0
            if keys[pygame.K_d] or keys[pygame.K_RIGHT]:
                move_x += 1.0

        length = math.hypot(move_x, move_y)
        if length > 0:
            move_x /= length
            move_y /= length

        target_speed = 300.0 * self.weapon.speed_mult * getattr(self, 'speed_mult', 1.0)
        accel = 12.0 / (1.0 + (self.weapon.weight * 0.05 * inertia_mult))

        self.vx += (move_x * target_speed - self.vx) * accel * dt
        self.vy += (move_y * target_speed - self.vy) * accel * dt

        self.x += self.vx * dt
        self.y += self.vy * dt

        # Obstacle collision
        for obs in obstacles:
            dist = math.hypot(self.x - obs['x'], self.y - obs['y'])
            min_dist = self.radius + obs['radius']
            if dist < min_dist:
                overlap = min_dist - dist
                nx = (self.x - obs['x']) / max(dist, 0.001)
                ny = (self.y - obs['y']) / max(dist, 0.001)
                self.x += nx * overlap
                self.y += ny * overlap
                self.vx *= 0.5
                self.vy *= 0.5

        # Bounds
        pad = 60
        self.x = max(pad, min(MAP_WIDTH - pad, self.x))
        self.y = max(pad, min(MAP_HEIGHT - pad, self.y))

        # 4-frame animation clocks
        current_spd = math.hypot(self.vx, self.vy)
        if current_spd > 15:
            self.walk_timer += dt * (current_spd / 180.0)
        if self.cast_anim_timer > 0:
            self.cast_anim_timer = max(0.0, self.cast_anim_timer - dt)

    def take_damage(self, amount, fx, sfx, art, is_shielded):
        if self.i_frame_timer > 0 or not self.alive:
            return
        if is_shielded:
            fx.spawn_sparks(self.x, self.y, (255, 230, 80), count=25, speed=260)
            fx.add_floating_text("БЛОКИРОВАНО! (БАСТИОН)", self.x, self.y - 35, TEXT_GOLD, size=24)
            sfx.play("parry")
            return

        effective_dmg = amount * getattr(self, 'damage_taken_mult', 1.0)
        self.hp = max(0, self.hp - effective_dmg)
        self.damage_taken_in_wave = True
        self.total_damage_taken_run += effective_dmg
        self.total_hits_taken_run += 1
        if getattr(self, 'game', None):
            CHALLENGE_MANAGER.on_player_damage_taken(self.game, effective_dmg)
        fx.add_screen_shake(14.0)
        fx.spawn_sparks(self.x, self.y, (255, 60, 60), count=18)
        art.add_blood_splatter(self.x, self.y, count=12)
        fx.add_floating_text(f"-{int(effective_dmg)} HP", self.x, self.y - 30, (255, 60, 60), size=26)
        sfx.play("hit")
        if self.hp <= 0:
            self.alive = False
            if getattr(self, 'game', None) and hasattr(self.game, 'on_player_death'):
                self.game.on_player_death()


class Enemy:
    def __init__(self, x, y, bestiary_id, hp_scale=1.0):
        self.x = float(x)
        self.y = float(y)
        self.vx = 0.0
        self.vy = 0.0

        data = BESTIARY.get(bestiary_id, BESTIARY["stone_sentry"])
        self.data = data
        self.id = data["id"]
        self.name = data["name"]
        self.sprite_base = data["sprite_base"]
        self.tint = data["tint"]
        self.scale = data["scale"]
        self.radius = int(22 * self.scale)
        self.max_hp = int(data["hp"] * hp_scale)
        self.hp = self.max_hp
        diff = DIFFICULTY_MANAGER.current
        self.speed = data["speed"] * diff.enemy_speed_mult * CHALLENGE_MANAGER.get_enemy_speed_mult()
        self.damage = data["damage"] * diff.enemy_damage_mult * CHALLENGE_MANAGER.get_enemy_damage_mult()
        self.special = data["special"]
        self.alive = True

        self.attack_cooldown = random.uniform(1.2, 2.5)
        self.windup_timer = 0.0
        self.stun_timer = 0.0
        self.exhausted_timer = 0.0
        self.is_attacking = False
        self.innate_immunities = set(data.get("immunities", []))
        self._is_frozen = False
        self.backstab_vulnerable = False
        self.combo_step = 0
        self.internal_clock = 0.0
        self.dodge_i_frames = 0.0
        self.is_dodging = False
        self.spell_hits = {}
        self.spell_immunities = {}
        self.walk_timer = random.uniform(0.0, 1.0)
        self.is_boss = (self.scale > 1.35 or "БОСС" in self.name or "Титан" in self.name or "Владычица" in self.name or "Инквизитор" in self.name or self.id in ("grand_inquisitor_malchor", "goliath_prime_titan", "archlich_mordecai", "void_overlord", "avatar_of_chaos", "bladesovereign_valeria", "abyssal_drakon_nadir", "judge_of_truth"))
        if self.is_boss:
            init_boss_combat_state(self)

    def is_immune_to(self, category):
        innate = getattr(self, 'innate_immunities', None)
        return bool(innate and category in innate)

    @property
    def is_frozen(self):
        return getattr(self, '_is_frozen', False)

    @is_frozen.setter
    def is_frozen(self, val):
        if val and self.is_immune_to("ICE"):
            self._is_frozen = False
            return
        self._is_frozen = bool(val)

    def update(self, dt, player, fx, sfx, art, is_shielded, obstacles):
        if not self.alive or not player.alive:
            return

        if getattr(self, 'is_training_dummy', False):
            self.internal_clock = getattr(self, 'internal_clock', 0.0) + dt
            if getattr(self, 'spell_immunities', None):
                expired = []
                for stag, rem in list(self.spell_immunities.items()):
                    new_rem = rem - dt
                    if new_rem <= 0:
                        expired.append(stag)
                    else:
                        self.spell_immunities[stag] = new_rem
                for stag in expired:
                    del self.spell_immunities[stag]
                    fx.add_floating_text(f"ИММУНИТЕТ К [{stag}] ИСТЕК!", self.x, self.y - 45, (160, 255, 200), size=20)
                    sfx.play("parry")

            if getattr(self, 'is_frozen', False):
                self.vx = 0.0
                self.vy = 0.0
                return

            if self.stun_timer > 0:
                self.stun_timer = max(0.0, self.stun_timer - dt)

            # Gentle anchor spring towards designated practice area
            anchor_x = getattr(self, 'anchor_x', self.x)
            anchor_y = getattr(self, 'anchor_y', self.y)
            self.vx += (anchor_x - self.x) * 1.6 * dt
            self.vy += (anchor_y - self.y) * 1.6 * dt

            self.vx *= 0.88
            self.vy *= 0.88
            self.x += self.vx * dt
            self.y += self.vy * dt
            return

        if getattr(self, 'is_boss', False):
            game_abs = getattr(player, 'game', None).active_abilities if (player and getattr(player, 'game', None)) else []
            update_boss_ai(self, dt, player, game_abs, fx, sfx, art, obstacles)

        self.internal_clock = getattr(self, 'internal_clock', 0.0) + dt
        if getattr(self, 'spell_immunities', None):
            expired = []
            for stag, rem in list(self.spell_immunities.items()):
                new_rem = rem - dt
                if new_rem <= 0:
                    expired.append(stag)
                else:
                    self.spell_immunities[stag] = new_rem
            for stag in expired:
                del self.spell_immunities[stag]
                fx.add_floating_text(f"ИММУНИТЕТ К [{stag}] ИСТЕК!", self.x, self.y - 45, (160, 255, 200), size=20)
                sfx.play("parry")

        if getattr(self, 'is_frozen', False):
            self.vx = 0.0
            self.vy = 0.0
            return

        if self.exhausted_timer > 0:
            self.exhausted_timer = max(0.0, self.exhausted_timer - dt)
            if random.random() < 0.25:
                fx.spawn_sparks(self.x, self.y, (255, 220, 80), count=2, speed=45)
            self.vx *= 0.82
            self.vy *= 0.82
            self.x += self.vx * dt
            self.y += self.vy * dt
            return

        if self.stun_timer > 0:
            self.stun_timer = max(0.0, self.stun_timer - dt)
            self.vx *= 0.88
            self.vy *= 0.88
            self.x += self.vx * dt
            self.y += self.vy * dt
            return

        self.vx *= 0.90
        self.vy *= 0.90
        self.x += self.vx * dt
        self.y += self.vy * dt

        # Obstacle collision
        for obs in obstacles:
            dist = math.hypot(self.x - obs['x'], self.y - obs['y'])
            min_dist = self.radius + obs['radius']
            if dist < min_dist:
                overlap = min_dist - dist
                nx = (self.x - obs['x']) / max(dist, 0.001)
                ny = (self.y - obs['y']) / max(dist, 0.001)
                self.x += nx * overlap
                self.y += ny * overlap

        dist = math.hypot(player.x - self.x, player.y - self.y)
        dx = (player.x - self.x) / max(dist, 1.0)
        dy = (player.y - self.y) / max(dist, 1.0)

        # Multi-hit Boss Combo Sequences vs Regular Attacks
        is_boss = (self.scale > 1.35 or "БОСС" in self.name or "Титан" in self.name)
        if self.is_attacking:
            self.windup_timer += dt
            if random.random() < 0.35:
                fx.spawn_sparks(self.x, self.y, self.tint, count=3, speed=70)

            max_windup = 0.65 if is_boss else 0.85
            if self.windup_timer >= max_windup:
                self.windup_timer = 0.0
                reach = self.radius + player.radius + (50 if self.scale > 1.4 else 25)

                if is_boss:
                    self.combo_step += 1

                    # Unique Signature Combo Names per Boss!
                    if self.id == "grand_inquisitor_malchor":
                        combo_names = ["1/3: КРОВАВЫЙ ВЫПАД!", "2/3: ТРИБУНАЛ МУЧЕНИКА!", "3/3 ФИНИШЕР: БАГРОВАЯ КАЗНЬ!"]
                    elif self.id == "goliath_prime_titan":
                        combo_names = ["1/3: СЕЙСМИЧЕСКИЙ ТОПОТ!", "2/3: ТИТАНИЧЕСКИЙ ЗАМАХ!", "3/3 ФИНИШЕР: РАСКОЛ НЕБЕС!"]
                    elif self.id == "archlich_mordecai":
                        combo_names = ["1/3: ПРИЗЫВ ПРИЗРАКОВ!", "2/3: ЛЕДЯНАЯ ГРОБНИЦА!", "3/3 ФИНИШЕР: ЛУЧ СМЕРТИ!"]
                    elif self.id == "void_overlord":
                        combo_names = ["1/3: ТЕНЕВОЙ БЛИНК!", "2/3: ГРАВИТАЦИОННЫЙ РАЗРЫВ!", "3/3 ФИНИШЕР: СВЕРХНОВАЯ БЕЗДНЫ!"]
                    elif self.id == "avatar_of_chaos":
                        combo_names = ["1/3: ПЛАМЕННЫЙ ЗАЛП!", "2/3: ГРОЗОВОЙ РАЗРЯД!", "3/3 ФИНИШЕР: АПОКАЛИПСИС ХАОСА!"]
                    elif self.id == "bladesovereign_valeria":
                        combo_names = ["1/3: МГНОВЕННЫЙ ШАГ!", "2/3: ТАНЕЦ БАГРОВЫХ ЛЕЗВИЙ!", "3/3 ФИНИШЕР: ОМНИСЛЕШ: 1000 ПОРЕЗОВ!"]
                    elif self.id == "abyssal_drakon_nadir":
                        combo_names = ["1/3: ПРИЛИВ ТЬМЫ!", "2/3: ХВОСТОВОЙ СМЕТ!", "3/3 ФИНИШЕР: ДЫХАНИЕ СИНГУЛЯРНОСТИ!"]
                    elif self.id == "judge_of_truth":
                        combo_names = ["1/3: КАРА ЗА ЛОЖЬ!", "2/3: ВЕСЫ ПРАВОСУДИЯ!", "3/3 ФИНИШЕР: АБСОЛЮТНЫЙ ВЕРДИКТ!"]
                    else:
                        combo_names = [f"1/3: {self.name.split()[0]}!", "2/3: РАЗРЕЗ!", "3/3 ФИНИШЕР: СОКРУШЕНИЕ!"]

                    # Step 1: Initial Rush / Leap Strike
                    if self.combo_step == 1:
                        fx.add_floating_text(combo_names[0], self.x, self.y - 45, self.tint, size=24)
                        fx.add_screen_shake(14.0)
                        if self.id in ("grand_inquisitor_malchor", "bladesovereign_valeria"):
                            self.x += dx * 140  # Speed dash
                            self.y += dy * 140
                        if dist < reach + 40:
                            player.take_damage(self.damage * 0.80, fx, sfx, art, is_shielded)

                    # Step 2: Cleave / Flurry
                    elif self.combo_step == 2:
                        fx.add_floating_text(combo_names[1], self.x, self.y - 45, (255, 140, 40), size=24)
                        fx.add_screen_shake(18.0)
                        if dist < reach + 35:
                            player.take_damage(self.damage * 1.05, fx, sfx, art, is_shielded)

                    # Step 3: Obliteration Finisher!
                    elif self.combo_step >= 3:
                        fx.add_floating_text(combo_names[2], self.x, self.y - 50, TEXT_RED, size=28)
                        fx.add_screen_shake(28.0)
                        art.add_scorch_mark(self.x, self.y, radius=70)
                        if dist < reach + 65:
                            player.take_damage(self.damage * 1.65, fx, sfx, art, is_shielded)
                            player.vx += dx * 580
                            player.vy += dy * 580

                        self.is_attacking = False
                        self.combo_step = 0
                        self.exhausted_timer = CHALLENGE_MANAGER.get_boss_exhaustion_time(random.uniform(2.8, 3.8))  # Downtime window!
                        self.attack_cooldown = self.exhausted_timer + 0.8
                        fx.add_floating_text("БОСС ИСТОЩЕН! [ОКНО ДЛЯ КОНТРАТАКИ]", self.x, self.y - 65, TEXT_GOLD, size=24)
                else:
                    self.is_attacking = False
                    self.attack_cooldown = random.uniform(1.8, 2.8)
                    if dist < reach:
                        player.take_damage(self.damage, fx, sfx, art, is_shielded)
                        player.vx += dx * 280
                        player.vy += dy * 280
        else:
            self.attack_cooldown -= dt
            if dist > 55:
                self.x += dx * self.speed * dt
                self.y += dy * self.speed * dt
                self.walk_timer = getattr(self, 'walk_timer', 0.0) + dt * (self.speed / 120.0)

            trigger = 90 if self.scale > 1.4 else 75
            if dist <= trigger and self.attack_cooldown <= 0:
                self.is_attacking = True
                self.windup_timer = 0.0

    def take_hit(self, damage, knockback_x, knockback_y, stun_sec, is_launcher, fx, sfx, spell_tag="АТАКА", player=None):
        # 0. Check active boss dodge i-frames
        if getattr(self, 'dodge_i_frames', 0.0) > 0:
            fx.spawn_sparks(self.x, self.y, (140, 240, 255), count=14, speed=220)
            fx.add_floating_text("★ УВЕРНУЛСЯ! [0 УРОНА]", self.x, self.y - 45, (140, 240, 255), size=24)
            sfx.play("parry")
            return

        # 0b. Boss reaction dodge trigger (65% chance if off cooldown)
        if getattr(self, 'is_boss', False) and getattr(self, 'boss_dodge_cooldown', 0.0) <= 0 and not getattr(self, 'is_frozen', False) and getattr(self, 'exhausted_timer', 0.0) <= 0:
            if random.random() < 0.65:
                px = player.x if player else self.x + random.uniform(-100, 100)
                py = player.y if player else self.y + random.uniform(-100, 100)
                if check_and_perform_boss_dodge(self, px, py, fx, sfx):
                    return

        # 0c. Check innate elemental immunities
        if getattr(self, 'innate_immunities', None):
            incoming_cats = get_spell_damage_categories(spell_tag)
            immune_matches = [cat for cat in incoming_cats if cat in self.innate_immunities]
            if immune_matches:
                # If all components are immune or pure single-element attack
                if len(immune_matches) == len(incoming_cats):
                    cat_key = immune_matches[0]
                    cat_info = DAMAGE_CATEGORIES.get(cat_key, {"display": cat_key, "color": (255, 215, 80)})
                    fx.spawn_sparks(self.x, self.y, cat_info["color"], count=24, speed=280)
                    fx.add_floating_text("0", self.x, self.y - 35, cat_info["color"], size=24)
                    sfx.play("parry")
                    return
                else:
                    # Partial immunity for hybrid/combo spell
                    damage *= 0.5
                    cat_key = immune_matches[0]
                    cat_info = DAMAGE_CATEGORIES.get(cat_key, {"display": cat_key, "color": (255, 215, 80)})
                    fx.spawn_sparks(self.x, self.y, cat_info["color"], count=14, speed=180)
                    fx.add_floating_text(f"-{int(damage)}", self.x, self.y - 35, (255, 200, 100), size=24)
                    sfx.play("parry")

        # 1. Check active temporary immunity
        if hasattr(self, 'spell_immunities') and spell_tag in self.spell_immunities and self.spell_immunities[spell_tag] > 0:
            fx.spawn_sparks(self.x, self.y, (230, 110, 255), count=18, speed=220)
            rem = self.spell_immunities[spell_tag]
            fx.add_floating_text(f"★ ИММУНИТЕТ К [{spell_tag}]! [0 УРОНА, {rem:.1f}с]", self.x, self.y - 45, (245, 100, 255), size=26)
            sfx.play("parry")
            return

        # Rotated element hit achievement trigger:
        if getattr(self, 'spell_immunities', None) and len(self.spell_immunities) > 0 and spell_tag not in self.spell_immunities:
            ACHIEVEMENT_MANAGER.unlock("anti_spam_break", fx, sfx)

        # 2. Check hit frequency / spam adaptation (window: 6.5s)
        now = getattr(self, 'internal_clock', 0.0)
        if not hasattr(self, 'spell_hits'):
            self.spell_hits = {}
        if spell_tag not in self.spell_hits:
            self.spell_hits[spell_tag] = []

        self.spell_hits[spell_tag] = [t for t in self.spell_hits[spell_tag] if (now - t) < 6.5]
        self.spell_hits[spell_tag].append(now)
        hits_count = len(self.spell_hits[spell_tag])

        is_boss = (self.scale > 1.3 or "БОСС" in self.name or "Титан" in self.name or "Владычица" in self.name or "Инквизитор" in self.name)
        diff = DIFFICULTY_MANAGER.current
        norm_thr, boss_thr = CHALLENGE_MANAGER.get_spam_thresholds(diff.spam_threshold_normal, diff.spam_threshold_boss)
        immunity_threshold = boss_thr if is_boss else norm_thr

        if hits_count >= immunity_threshold:
            dur = 8.0 if CHALLENGE_MANAGER.is_active("HYPER_ADAPTATION") else (7.0 if is_boss else 5.0)
            if not hasattr(self, 'spell_immunities'):
                self.spell_immunities = {}
            self.spell_immunities[spell_tag] = dur
            self.spell_hits[spell_tag] = []
            fx.add_screen_shake(16.0)
            fx.spawn_sparks(self.x, self.y, (240, 90, 255), count=35, speed=320)
            fx.add_floating_text(f"★ ВРАГ ПОЛУЧИЛ ИММУНИТЕТ К [{spell_tag}] НА {int(dur)}с! [СПАМ]", self.x, self.y - 65, (255, 90, 255), size=26)
            sfx.play("crit")
            return
        elif hits_count == 2:
            damage *= 0.75
            fx.add_floating_text(f"ВРАГ ПРИВЫКАЕТ К [{spell_tag}]! (-25%)", self.x, self.y - 40, (255, 180, 80), size=22)
        elif hits_count == 3:
            damage *= 0.50
            fx.add_floating_text(f"АДАПТАЦИЯ К [{spell_tag}] (-50%)! [СПАМ]", self.x, self.y - 45, (255, 100, 100), size=24)

        if getattr(self, 'exhausted_timer', 0.0) > 0:
            damage *= 1.5
            fx.add_floating_text(f"★ УДАР ПО ИСТОЩЕНИЮ +50%! -{int(damage)}", self.x, self.y - 65, TEXT_GOLD, size=24)

        if self.backstab_vulnerable:
            damage *= 3.0
            self.backstab_vulnerable = False
            fx.add_floating_text(f"★ BACKSTAB CRIT x3! -{int(damage)}", self.x, self.y - 45, (255, 80, 240), size=28)
            fx.add_screen_shake(16.0)
            fx.spawn_sparks(self.x, self.y, (255, 100, 240), count=25, speed=260)
            sfx.play("crit")

        if player and getattr(player, 'cataclysm_execute', False) and spell_tag in ("КАТАКЛИЗМ", "ЗВЕЗДА"):
            if self.hp / max(1, self.max_hp) < 0.35:
                damage = self.hp + 999.0
                fx.add_floating_text("★ МГНОВЕННАЯ КАЗНЬ КАТАКЛИЗМА! ★", self.x, self.y - 75, (255, 50, 50), size=30)
                fx.add_screen_shake(24.0)

        self.hp = max(0, self.hp - damage)
        self.vx += knockback_x / (1.0 + self.scale * 0.5)
        self.vy += knockback_y / (1.0 + self.scale * 0.5)
        self.stun_timer = max(self.stun_timer, stun_sec)

        total_ls = getattr(player, 'lifesteal_percent', 0.0) + (getattr(player.weapon, 'lifesteal_bonus', 0.0) if player and getattr(player, 'weapon', None) else 0.0)
        if total_ls > 0 and damage > 0:
            heal = int(damage * total_ls)
            if heal > 0:
                player.hp = min(player.max_hp, player.hp + heal)
                if random.random() < 0.35:
                    fx.add_floating_text(f"+{heal} HP", player.x, player.y - 30, (80, 255, 140), size=20)

        if self.hp <= 0:
            if getattr(self, 'is_training_dummy', False):
                self.hp = self.max_hp
                self.alive = True
                fx.spawn_sparks(self.x, self.y, (140, 240, 255), count=25, speed=200)
                fx.add_floating_text("★ МАНЕКЕН ВОССТАНОВЛЕН (100% HP)", self.x, self.y - 45, TEXT_CYAN, size=22)
                return

            self.alive = False
            self.is_frozen = False
            fx.spawn_sparks(self.x, self.y, (255, 70, 70), count=40, speed=260)
            sfx.play("crit")
            if is_boss:
                ACHIEVEMENT_MANAGER.unlock("boss_slayer", fx, sfx)
                if player and hasattr(player, 'game') and player.game:
                    player.game.check_wild_magic_boss_unlocks(player.game.current_floor_idx + 1)
            if player and getattr(player, 'lifesteal_per_kill', 0) > 0:
                player.hp = min(player.max_hp, player.hp + player.lifesteal_per_kill)
                fx.add_floating_text(f"+{player.lifesteal_per_kill} HP (ЖНЕЦ)!", player.x, player.y - 45, (80, 255, 140), size=24)


class PentagramCataclysm:
    def __init__(self, x, y, damage_mult):
        self.x = float(x)
        self.y = float(y)
        self.duration = 1.8
        self.age = 0.0
        self.damage_mult = damage_mult
        self.alive = True
        self.has_detonated = False

    def update(self, dt, enemies, player, fx, sfx, art, obstacles=None):
        self.age += dt
        if self.age >= 0.70 and not self.has_detonated:
            self.has_detonated = True
            fx.add_screen_shake(26.0)
            fx.spawn_sparks(self.x, self.y, (255, 60, 40), count=60, speed=400)
            art.add_scorch_mark(self.x, self.y, radius=85)
            sfx.play("crit")

            for en in enemies:
                if en.alive:
                    dist = math.hypot(en.x - self.x, en.y - self.y)
                    if dist < 320:
                        dmg = 175.0 * self.damage_mult
                        en.take_hit(dmg, (en.x - self.x) * 3.5, (en.y - self.y) * 3.5, 1.6, True, fx, sfx, spell_tag="КАТАКЛИЗМ", player=player)
                        art.add_blood_splatter(en.x, en.y, count=16)
                        fx.add_floating_text(f"★ КАТАКЛИЗМ! -{int(dmg)}", en.x, en.y - 45, (255, 60, 40), size=28)

        if self.age >= self.duration:
            self.alive = False

    def draw(self, surface, offset_x=0, offset_y=0):
        cx = int(self.x + offset_x)
        cy = int(self.y + offset_y)
        t = min(1.0, self.age / 0.70)
        radius = int(90 + 30 * t)
        
        star_surf = pygame.Surface((radius * 2 + 10, radius * 2 + 10), pygame.SRCALPHA)
        pts = []
        rot = self.age * 3.0
        for i in range(5):
            a = rot + i * (2 * math.pi * 2 / 5)
            px = (radius + 5) + radius * math.cos(a)
            py = (radius + 5) + radius * math.sin(a)
            pts.append((px, py))
        
        alpha = int(220 * (1.0 - (self.age / self.duration)))
        if len(pts) >= 5:
            pygame.draw.polygon(star_surf, (255, 60, 40, alpha // 3), pts)
            pygame.draw.lines(star_surf, (255, 230, 80, alpha), True, pts, width=3)
            pygame.draw.circle(star_surf, (255, 120, 40, alpha), (radius + 5, radius + 5), radius, width=2)
        surface.blit(star_surf, (cx - (radius + 5), cy - (radius + 5)))

    def get_light(self):
        return (self.x, self.y, 280, (255, 80, 40), 0.95)
