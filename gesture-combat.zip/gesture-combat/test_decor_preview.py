import os
import pygame
from game_engine import Game
from config import MAP_WIDTH, MAP_HEIGHT

def main():
    os.environ['SDL_VIDEODRIVER'] = 'dummy'
    pygame.init()
    game = Game()
    game.state = 'PLAYING'
    game.enemies.clear() # clear enemies so view is crystal clear
    
    # View 1: Blood Fountain & Alchemy Table
    game.player.x = MAP_WIDTH // 2 - 280
    game.player.y = MAP_HEIGHT // 2
    game.cam_x = game.player.x - 1200 / 2
    game.cam_y = game.player.y - 800 / 2
    game.anim_time = 2.5
    game.render()
    
    out_dir = r"C:\Users\Parzi\.gemini\antigravity\brain\479ac71d-3313-4bcf-ac56-8d3888ba42d4"
    os.makedirs(out_dir, exist_ok=True)
    out_path1 = os.path.join(out_dir, "map_decor_preview_fountain_alchemy.png")
    pygame.image.save(game.screen, out_path1)

    # View 2: Gothic Shrine & Sarcophagus
    game.player.x = MAP_WIDTH // 2 - 140
    game.player.y = 300
    game.cam_x = game.player.x - 1200 / 2 + 140
    game.cam_y = 280 - 800 / 2
    game.anim_time = 3.8
    game.render()
    out_path2 = os.path.join(out_dir, "map_decor_preview_shrine_sarcophagus.png")
    pygame.image.save(game.screen, out_path2)
    print("Saved previews:", out_path1, out_path2)

if __name__ == '__main__':
    main()
