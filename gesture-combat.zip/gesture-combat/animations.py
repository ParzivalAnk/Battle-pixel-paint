import os
import math
import random
import pygame

ANIM_FRAMES_DIR = "assets/anim_frames"

# =============================================================================
# 1. PLAYER 4-FRAME GENERATOR (WALK, CAST, IDLE)
# =============================================================================
def generate_player_frames(base_surf):
    w, h = base_surf.get_size()
    pad = 12
    fw, fh = w + pad * 2, h + pad * 2
    ox, oy = pad, pad

    # Anatomical slices
    head_sub = base_surf.subsurface((0, 0, w, 24)).copy()
    torso_sub = base_surf.subsurface((0, 24, w, 15)).copy()
    legs_left = base_surf.subsurface((0, 39, w // 2 + 2, h - 39)).copy()
    legs_right = base_surf.subsurface((w // 2 - 2, 39, w - (w // 2 - 2), h - 39)).copy()

    # --- 4-FRAME WALK CYCLE ---
    # F0: Left stride forward, right back, slight drop
    # F1: Passing step, body rises to apex
    # F2: Right stride forward, left back, slight drop
    # F3: Passing step, body rises to apex
    walk_frames = []
    walk_configs = [
        ( 1,  1,  3, -1, -3,  1,  2.5, "left"),
        (-2, -2,  0, -2,  1,  0,  0.0, None),
        ( 1,  1, -3,  1,  3, -1, -2.5, "right"),
        (-2, -2,  1,  0,  0, -2,  0.0, None),
    ]
    for idx, (h_dy, t_dy, l_dx, l_dy, r_dx, r_dy, tilt, dust) in enumerate(walk_configs):
        f = pygame.Surface((fw, fh), pygame.SRCALPHA)
        # Legs
        f.blit(legs_left, (ox + l_dx, oy + 39 + l_dy))
        f.blit(legs_right, (ox + w // 2 - 2 + r_dx, oy + 39 + r_dy))

        # Torso & Head
        upper = pygame.Surface((w, 39), pygame.SRCALPHA)
        upper.blit(torso_sub, (0, 24 + t_dy))
        upper.blit(head_sub, (0, h_dy))
        if tilt != 0:
            rot = pygame.transform.rotate(upper, tilt)
            rw, rh = rot.get_size()
            f.blit(rot, (ox + (w - rw) // 2, oy + (39 - rh) // 2))
        else:
            f.blit(upper, (ox, oy))

        # Dynamic footstep dust puff
        if dust == "left":
            px = ox + w // 2 - 12
            py = oy + h - 2
            pygame.draw.circle(f, (220, 215, 200, 180), (px, py), 2)
            pygame.draw.circle(f, (180, 175, 160, 140), (px - 2, py - 1), 1)
        elif dust == "right":
            px = ox + w // 2 + 10
            py = oy + h - 2
            pygame.draw.circle(f, (220, 215, 200, 180), (px, py), 2)
            pygame.draw.circle(f, (180, 175, 160, 140), (px + 2, py - 1), 1)

        walk_frames.append(f)

    # --- 4-FRAME CAST CYCLE ---
    # F0: Gathering energy - crouch, arms in, ground rune circle forms
    # F1: Channel peak - torso rises, arcane sigil flares, glowing eyes
    # F2: Release / Blast - forward thrust, radiant energy burst & rays!
    # F3: Recovery - recoil back, lingering mana sparks dissolving
    cast_frames = []
    # F0
    f0 = pygame.Surface((fw, fh), pygame.SRCALPHA)
    f0.blit(base_surf, (ox, oy + 1))
    pygame.draw.ellipse(f0, (60, 160, 255, 130), (ox + 8, oy + h - 6, w - 16, 7), 1)
    pygame.draw.circle(f0, (140, 220, 255, 220), (ox + w // 2 + 4, oy + 28), 3)
    pygame.draw.circle(f0, (255, 255, 255, 255), (ox + w // 2 + 4, oy + 28), 1)
    cast_frames.append(f0)

    # F1
    f1 = pygame.Surface((fw, fh), pygame.SRCALPHA)
    stretched = pygame.transform.scale(base_surf, (w, h + 2))
    f1.blit(stretched, (ox, oy - 2))
    cx, cy = ox + w // 2 + 8, oy + 22
    pygame.draw.circle(f1, (80, 200, 255, 200), (cx, cy), 7, 1)
    pygame.draw.circle(f1, (200, 240, 255, 240), (cx, cy), 4, 1)
    for a in [0, 90, 180, 270]:
        rad = math.radians(a + 45)
        rx = cx + int(7 * math.cos(rad))
        ry = cy + int(7 * math.sin(rad))
        pygame.draw.circle(f1, (255, 255, 255, 255), (rx, ry), 1)
    pygame.draw.circle(f1, (100, 235, 255, 255), (ox + w // 2 - 2, oy + 14), 2)
    cast_frames.append(f1)

    # F2
    f2 = pygame.Surface((fw, fh), pygame.SRCALPHA)
    f2.blit(base_surf, (ox + 3, oy))
    bx, by = ox + w // 2 + 16, oy + 24
    pygame.draw.circle(f2, (255, 255, 255, 255), (bx, by), 5)
    pygame.draw.circle(f2, (100, 220, 255, 220), (bx, by), 8, 2)
    pygame.draw.circle(f2, (60, 140, 255, 140), (bx, by), 12, 1)
    pygame.draw.line(f2, (255, 255, 255, 240), (bx, by), (bx + 14, by - 6), 2)
    pygame.draw.line(f2, (120, 220, 255, 200), (bx, by), (bx + 18, by), 2)
    pygame.draw.line(f2, (255, 255, 255, 240), (bx, by), (bx + 14, by + 6), 2)
    cast_frames.append(f2)

    # F3
    f3 = pygame.Surface((fw, fh), pygame.SRCALPHA)
    f3.blit(base_surf, (ox - 1, oy))
    for sp_x, sp_y in [(bx - 2, by - 8), (bx + 4, by - 12), (bx + 8, by + 4), (bx - 4, by + 8)]:
        pygame.draw.circle(f3, (120, 200, 255, 160), (sp_x, sp_y), 2)
        pygame.draw.circle(f3, (255, 255, 255, 220), (sp_x, sp_y), 1)
    cast_frames.append(f3)

    # --- 4-FRAME IDLE CYCLE ---
    idle_frames = []
    for dy, sy_adj in [(0, 0), (-1, 1), (-1, 1), (0, 0)]:
        f = pygame.Surface((fw, fh), pygame.SRCALPHA)
        if sy_adj != 0:
            scaled = pygame.transform.scale(base_surf, (w, h + sy_adj))
            f.blit(scaled, (ox, oy + dy))
        else:
            f.blit(base_surf, (ox, oy + dy))
        idle_frames.append(f)

    return {"walk": walk_frames, "cast": cast_frames, "idle": idle_frames}


# =============================================================================
# 2. GOLEM 4-FRAME GENERATOR (WALK, ATTACK/SLAM, IDLE)
# =============================================================================
def generate_golem_frames(base_surf):
    w, h = base_surf.get_size()
    pad = 16
    fw, fh = w + pad * 2, h + pad * 2
    ox, oy = pad, pad

    upper_sub = base_surf.subsurface((0, 0, w, 65)).copy()
    leg_left = base_surf.subsurface((0, 65, w // 2, h - 65)).copy()
    leg_right = base_surf.subsurface((w // 2, 65, w - w // 2, h - 65)).copy()

    # --- 4-FRAME WALK CYCLE (HEAVY STOMP) ---
    walk_frames = []
    walk_configs = [
        (-3, -2,  3,  2, -3.5,  1, "left"),
        ( 0,  0,  0,  0,  0.0, -2, None),
        ( 3,  2, -3, -2,  3.5,  1, "right"),
        ( 0,  0,  0,  0,  0.0, -2, None),
    ]
    for l_dx, l_dy, r_dx, r_dy, tilt, u_dy, stomp in walk_configs:
        f = pygame.Surface((fw, fh), pygame.SRCALPHA)
        f.blit(leg_left, (ox + l_dx, oy + 65 + l_dy))
        f.blit(leg_right, (ox + w // 2 + r_dx, oy + 65 + r_dy))

        if tilt != 0:
            rot = pygame.transform.rotate(upper_sub, tilt)
            rw, rh = rot.get_size()
            f.blit(rot, (ox + (w - rw) // 2, oy + (65 - rh) // 2 + u_dy))
        else:
            f.blit(upper_sub, (ox, oy + u_dy))

        if stomp == "left":
            px = ox + w // 4
            py = oy + h - 3
            pygame.draw.circle(f, (190, 165, 140, 200), (px, py), 4)
            pygame.draw.circle(f, (150, 130, 110, 160), (px - 5, py - 1), 3)
            pygame.draw.circle(f, (150, 130, 110, 160), (px + 5, py - 1), 2)
        elif stomp == "right":
            px = ox + 3 * (w // 4)
            py = oy + h - 3
            pygame.draw.circle(f, (190, 165, 140, 200), (px, py), 4)
            pygame.draw.circle(f, (150, 130, 110, 160), (px + 5, py - 1), 3)
            pygame.draw.circle(f, (150, 130, 110, 160), (px - 5, py - 1), 2)

        walk_frames.append(f)

    # --- 4-FRAME ATTACK / EARTHSHAKER SLAM ---
    attack_frames = []
    # F0: Windup
    f0 = pygame.Surface((fw, fh), pygame.SRCALPHA)
    f0.blit(base_surf, (ox, oy - 3))
    pygame.draw.line(f0, (255, 140, 40, 220), (ox + w // 2 - 8, oy + 32), (ox + w // 2 + 10, oy + 38), 2)
    attack_frames.append(f0)

    # F1: Apex Energy Charge
    f1 = pygame.Surface((fw, fh), pygame.SRCALPHA)
    f1.blit(base_surf, (ox, oy - 6))
    pygame.draw.line(f1, (255, 200, 60, 240), (ox + w // 2 - 12, oy + 28), (ox + w // 2 + 14, oy + 34), 3)
    pygame.draw.circle(f1, (255, 160, 50, 200), (ox + 16, oy + 20), 6)
    pygame.draw.circle(f1, (255, 240, 120, 240), (ox + 16, oy + 20), 3)
    pygame.draw.circle(f1, (255, 160, 50, 200), (ox + w - 16, oy + 20), 6)
    pygame.draw.circle(f1, (255, 240, 120, 240), (ox + w - 16, oy + 20), 3)
    attack_frames.append(f1)

    # F2: Ground Slam Impact!
    f2 = pygame.Surface((fw, fh), pygame.SRCALPHA)
    f2.blit(base_surf, (ox + 2, oy + 4))
    ground_y = oy + h - 4
    pygame.draw.ellipse(f2, (255, 180, 50, 220), (ox + 4, ground_y - 6, w + 8, 12), 2)
    pygame.draw.ellipse(f2, (255, 250, 160, 255), (ox + 16, ground_y - 4, w - 16, 8), 2)
    for dx, dy, col in [(-12, -8, (255, 140, 30)), (14, -10, (255, 200, 60)), (-20, -4, (200, 100, 30)), (22, -6, (255, 160, 40))]:
        pygame.draw.circle(f2, col, (ox + w // 2 + dx, ground_y + dy), 2)
    attack_frames.append(f2)

    # F3: Reset
    f3 = pygame.Surface((fw, fh), pygame.SRCALPHA)
    f3.blit(base_surf, (ox, oy + 1))
    attack_frames.append(f3)

    # --- 4-FRAME IDLE ---
    idle_frames = []
    for dy in [0, -1, -2, -1]:
        f = pygame.Surface((fw, fh), pygame.SRCALPHA)
        f.blit(base_surf, (ox, oy + dy))
        idle_frames.append(f)

    return {"walk": walk_frames, "attack": attack_frames, "idle": idle_frames}


# =============================================================================
# 3. INQUISITOR 4-FRAME GENERATOR (WALK, CROSS-SLASH, IDLE)
# =============================================================================
def generate_inquisitor_frames(base_surf):
    w, h = base_surf.get_size()
    pad = 14
    fw, fh = w + pad * 2, h + pad * 2
    ox, oy = pad, pad

    upper_sub = base_surf.subsurface((0, 0, w, 48)).copy()
    leg_left = base_surf.subsurface((0, 48, w // 2, h - 48)).copy()
    leg_right = base_surf.subsurface((w // 2, 48, w - w // 2, h - 48)).copy()

    # --- 4-FRAME WALK CYCLE (STALKING RUN) ---
    walk_frames = []
    walk_configs = [
        ( 4, -1, -4,  1,  3.0,  1),
        ( 0, -2,  1,  0,  0.0, -2),
        (-4,  1,  4, -1, -3.0,  1),
        ( 1,  0,  0, -2,  0.0, -2),
    ]
    for l_dx, l_dy, r_dx, r_dy, tilt, u_dy in walk_configs:
        f = pygame.Surface((fw, fh), pygame.SRCALPHA)
        f.blit(leg_left, (ox + l_dx, oy + 48 + l_dy))
        f.blit(leg_right, (ox + w // 2 + r_dx, oy + 48 + r_dy))

        if tilt != 0:
            rot = pygame.transform.rotate(upper_sub, tilt)
            rw, rh = rot.get_size()
            f.blit(rot, (ox + (w - rw) // 2, oy + (48 - rh) // 2 + u_dy))
        else:
            f.blit(upper_sub, (ox, oy + u_dy))

        walk_frames.append(f)

    # --- 4-FRAME ATTACK / CROSS-SLASH ---
    attack_frames = []
    # F0
    f0 = pygame.Surface((fw, fh), pygame.SRCALPHA)
    f0.blit(base_surf, (ox - 2, oy))
    pygame.draw.circle(f0, (255, 40, 50, 240), (ox + w // 2 - 2, oy + 12), 2)
    attack_frames.append(f0)

    # F1
    f1 = pygame.Surface((fw, fh), pygame.SRCALPHA)
    f1.blit(base_surf, (ox + 4, oy + 1))
    attack_frames.append(f1)

    # F2: Dual Cross-Slash!
    f2 = pygame.Surface((fw, fh), pygame.SRCALPHA)
    f2.blit(base_surf, (ox + 5, oy))
    sx, sy = ox + w // 2 + 10, oy + 28
    pygame.draw.line(f2, (255, 255, 255, 255), (sx - 12, sy - 14), (sx + 14, sy + 14), 3)
    pygame.draw.line(f2, (255, 40, 60, 220), (sx - 16, sy - 18), (sx + 18, sy + 18), 2)
    pygame.draw.line(f2, (255, 255, 255, 255), (sx - 12, sy + 14), (sx + 14, sy - 14), 3)
    pygame.draw.line(f2, (255, 40, 60, 220), (sx - 16, sy + 18), (sx + 18, sy - 18), 2)
    for bx, by in [(sx + 8, sy - 8), (sx - 8, sy + 8), (sx + 12, sy + 4)]:
        pygame.draw.circle(f2, (255, 60, 80, 240), (bx, by), 2)
    attack_frames.append(f2)

    # F3
    f3 = pygame.Surface((fw, fh), pygame.SRCALPHA)
    f3.blit(base_surf, (ox, oy))
    attack_frames.append(f3)

    # --- 4-FRAME IDLE ---
    idle_frames = []
    for dy in [0, -1, -2, -1]:
        f = pygame.Surface((fw, fh), pygame.SRCALPHA)
        f.blit(base_surf, (ox, oy + dy))
        idle_frames.append(f)

    return {"walk": walk_frames, "attack": attack_frames, "idle": idle_frames}


# =============================================================================
# 4. CULTIST 4-FRAME GENERATOR (WALK, DAGGER THRUST, IDLE)
# =============================================================================
def generate_cultist_frames(base_surf):
    w, h = base_surf.get_size()
    pad = 12
    fw, fh = w + pad * 2, h + pad * 2
    ox, oy = pad, pad

    upper_sub = base_surf.subsurface((0, 0, w, 44)).copy()
    leg_left = base_surf.subsurface((0, 44, w // 2, h - 44)).copy()
    leg_right = base_surf.subsurface((w // 2, 44, w - w // 2, h - 44)).copy()

    # --- 4-FRAME WALK CYCLE (FANATICAL SCURRY) ---
    walk_frames = []
    walk_configs = [
        ( 3, -1, -3,  1,  3.0,  1),
        ( 0, -2,  0, -1,  0.0, -2),
        (-3,  1,  3, -1, -3.0,  1),
        ( 0, -1,  0, -2,  0.0, -2),
    ]
    for l_dx, l_dy, r_dx, r_dy, tilt, u_dy in walk_configs:
        f = pygame.Surface((fw, fh), pygame.SRCALPHA)
        f.blit(leg_left, (ox + l_dx, oy + 44 + l_dy))
        f.blit(leg_right, (ox + w // 2 + r_dx, oy + 44 + r_dy))

        if tilt != 0:
            rot = pygame.transform.rotate(upper_sub, tilt)
            rw, rh = rot.get_size()
            f.blit(rot, (ox + (w - rw) // 2, oy + (44 - rh) // 2 + u_dy))
        else:
            f.blit(upper_sub, (ox, oy + u_dy))

        walk_frames.append(f)

    # --- 4-FRAME ATTACK / DAGGER THRUST ---
    attack_frames = []
    # F0
    f0 = pygame.Surface((fw, fh), pygame.SRCALPHA)
    f0.blit(base_surf, (ox, oy - 2))
    pygame.draw.circle(f0, (220, 30, 40, 180), (ox + w // 2 + 6, oy + 10), 4, 1)
    attack_frames.append(f0)

    # F1
    f1 = pygame.Surface((fw, fh), pygame.SRCALPHA)
    f1.blit(base_surf, (ox + 1, oy - 3))
    pygame.draw.circle(f1, (255, 60, 60, 240), (ox + w // 2 + 10, oy + 12), 4)
    pygame.draw.circle(f1, (255, 255, 255, 255), (ox + w // 2 + 10, oy + 12), 2)
    attack_frames.append(f1)

    # F2: Sacrificial Plunge Thrust!
    f2 = pygame.Surface((fw, fh), pygame.SRCALPHA)
    f2.blit(base_surf, (ox + 6, oy + 1))
    dx, dy = ox + w // 2 + 18, oy + 26
    pygame.draw.circle(f2, (255, 20, 30, 255), (dx, dy), 4)
    pygame.draw.line(f2, (255, 80, 80, 220), (dx, dy), (dx + 12, dy), 3)
    attack_frames.append(f2)

    # F3
    f3 = pygame.Surface((fw, fh), pygame.SRCALPHA)
    f3.blit(base_surf, (ox - 2, oy))
    attack_frames.append(f3)

    # --- 4-FRAME IDLE ---
    idle_frames = []
    for dy in [0, -1, -2, -1]:
        f = pygame.Surface((fw, fh), pygame.SRCALPHA)
        f.blit(base_surf, (ox, oy + dy))
        idle_frames.append(f)

    return {"walk": walk_frames, "attack": attack_frames, "idle": idle_frames}


# =============================================================================
# 5. LICH 4-FRAME GENERATOR (LEVITATION WALK, DEATH RAY CAST, IDLE)
# =============================================================================
def generate_lich_frames(base_surf):
    w, h = base_surf.get_size()
    pad = 14
    fw, fh = w + pad * 2, h + pad * 2
    ox, oy = pad, pad

    # --- 4-FRAME WALK / LEVITATION CYCLE ---
    walk_frames = []
    walk_configs = [
        ( 1, -1, 180),
        (-2,  0, 220),
        (-4,  1, 255),
        (-1,  0, 210),
    ]
    for dy, rx, glow in walk_configs:
        f = pygame.Surface((fw, fh), pygame.SRCALPHA)
        f.blit(base_surf, (ox + rx, oy + dy))
        wy = oy + h - 6 + dy
        pygame.draw.circle(f, (60, 240, 180, 140), (ox + w // 2 - 6, wy), 3)
        pygame.draw.circle(f, (80, 200, 255, 120), (ox + w // 2 + 6, wy + 1), 2)
        pygame.draw.circle(f, (80, 255, 200, glow), (ox + w // 2 - 2 + rx, oy + 14 + dy), 2)
        walk_frames.append(f)

    # --- 4-FRAME ATTACK / DEATH RAY CAST ---
    attack_frames = []
    # F0
    f0 = pygame.Surface((fw, fh), pygame.SRCALPHA)
    f0.blit(base_surf, (ox, oy - 2))
    pygame.draw.circle(f0, (140, 40, 255, 180), (ox + w // 2, oy + 20), 5, 1)
    attack_frames.append(f0)

    # F1
    f1 = pygame.Surface((fw, fh), pygame.SRCALPHA)
    f1.blit(base_surf, (ox, oy - 5))
    sx, sy = ox + w // 2 + 10, oy + 26
    pygame.draw.circle(f1, (160, 50, 255, 220), (sx, sy), 8)
    pygame.draw.circle(f1, (60, 255, 200, 240), (sx, sy), 5)
    pygame.draw.circle(f1, (255, 255, 255, 255), (sx, sy), 2)
    attack_frames.append(f1)

    # F2: Necrotic Soul Blast Release!
    f2 = pygame.Surface((fw, fh), pygame.SRCALPHA)
    f2.blit(base_surf, (ox + 4, oy - 2))
    bx, by = ox + w // 2 + 14, oy + 26
    pygame.draw.line(f2, (255, 255, 255, 255), (bx, by), (bx + 18, by), 4)
    pygame.draw.line(f2, (60, 255, 180, 240), (bx, by), (bx + 16, by - 6), 3)
    pygame.draw.line(f2, (180, 60, 255, 240), (bx, by), (bx + 16, by + 6), 3)
    pygame.draw.circle(f2, (60, 255, 200, 200), (bx + 20, by - 4), 3)
    pygame.draw.circle(f2, (180, 60, 255, 200), (bx + 20, by + 4), 3)
    attack_frames.append(f2)

    # F3
    f3 = pygame.Surface((fw, fh), pygame.SRCALPHA)
    f3.blit(base_surf, (ox, oy - 1))
    attack_frames.append(f3)

    # --- 4-FRAME IDLE ---
    idle_frames = []
    for dy in [0, -1, -3, -2]:
        f = pygame.Surface((fw, fh), pygame.SRCALPHA)
        f.blit(base_surf, (ox, oy + dy))
        idle_frames.append(f)

    return {"walk": walk_frames, "attack": attack_frames, "idle": idle_frames}


# =============================================================================
# MASTER LOADER & CACHE MANAGER
# =============================================================================
def load_or_generate_all_animations(base_sprites):
    """
    Loads all 4-frame animation sets for player and all enemy archetypes.
    If pre-rendered files exist on disk in assets/anim_frames/, loads them instantly.
    Otherwise generates them from base_sprites and caches them to disk.
    """
    os.makedirs(ANIM_FRAMES_DIR, exist_ok=True)

    char_generators = {
        "player": generate_player_frames,
        "golem": generate_golem_frames,
        "inquisitor": generate_inquisitor_frames,
        "cultist": generate_cultist_frames,
        "lich": generate_lich_frames,
    }

    result = {}

    for char_key, gen_fn in char_generators.items():
        base_img = base_sprites.get(char_key)
        actions = ["walk", "cast" if char_key == "player" else "attack", "idle"]
        char_dict = {}

        # Check if all files exist
        all_exist = True
        for act in actions:
            for idx in range(4):
                path = os.path.join(ANIM_FRAMES_DIR, f"{char_key}_{act}_{idx}.png")
                if not os.path.exists(path):
                    all_exist = False
                    break
            if not all_exist:
                break

        if all_exist:
            # Fast disk load
            for act in actions:
                frames = []
                for idx in range(4):
                    path = os.path.join(ANIM_FRAMES_DIR, f"{char_key}_{act}_{idx}.png")
                    surf = pygame.image.load(path).convert_alpha()
                    frames.append(surf)
                char_dict[act] = frames
        elif base_img:
            # Generate and save
            generated = gen_fn(base_img)
            for act, frames in generated.items():
                for idx, frame in enumerate(frames):
                    path = os.path.join(ANIM_FRAMES_DIR, f"{char_key}_{act}_{idx}.png")
                    pygame.image.save(frame, path)
            char_dict = generated
        else:
            # Fallback empty
            for act in actions:
                char_dict[act] = []

        result[char_key] = char_dict

    # Alias stalker to inquisitor
    result["stalker"] = result.get("inquisitor", {})

    return result


# =============================================================================
# 6. 10TH FLOOR CHALK RITUAL & GLOWING BLUE PORTAL (12 FRAMES)
# =============================================================================
PORTAL_CHALK_DIR = os.path.join(ANIM_FRAMES_DIR, "portal_chalk")

def generate_chalk_portal_frames():
    """
    Generates the 12-frame chalk ritual and blue glowing portal animation:
    Phase 1 (Frames 0-3): Drawing chalk on the floor (white chalk strokes & dust)
    Phase 2 (Frames 4-7): Chalk turns luminous blue, ignites and radiates mana rays
    Phase 3 (Frames 8-11): Dimensional portal opens above the glowing seal and swirls
    """
    W, H = 200, 200
    CX, CY = 100, 130  # Center of floor chalk seal
    PORTAL_CY = 65     # Center of hovering portal in the air above

    def draw_chalk_stroke(surface, pts, color, width=2, dust=True):
        for i in range(len(pts) - 1):
            x1, y1 = pts[i]
            x2, y2 = pts[i + 1]
            pygame.draw.line(surface, color, (int(x1), int(y1)), (int(x2), int(y2)), width)
            if dust and random.random() < 0.4:
                ox = x1 + random.uniform(-2, 2)
                oy = y1 + random.uniform(-1, 1)
                pygame.draw.circle(surface, (210, 215, 225, 140), (int(ox), int(oy)), 1)

    def get_ellipse_pts(cx, cy, rx, ry, start_angle=0, end_angle=360, steps=36):
        pts = []
        for i in range(steps + 1):
            a = math.radians(start_angle + (end_angle - start_angle) * (i / steps))
            x = cx + rx * math.cos(a)
            y = cy + ry * math.sin(a)
            pts.append((x, y))
        return pts

    def get_star_pts(cx, cy, rx, ry):
        star_angles = [-90, -90 + 144, -90 + 288, -90 + 72, -90 + 216, -90]
        pts = []
        for a in star_angles:
            rad = math.radians(a)
            x = cx + rx * math.cos(rad)
            y = cy + ry * math.sin(rad)
            pts.append((x, y))
        return pts

    frames = []
    rx, ry = 52, 22
    inner_rx, inner_ry = 38, 16

    CHALK_WHITE = (235, 238, 245, 230)
    MANA_CORE = (230, 250, 255, 255)

    # Phase 1: Chalk on Floor (Frames 0 to 3)
    f0 = pygame.Surface((W, H), pygame.SRCALPHA)
    arc0 = get_ellipse_pts(CX, CY, rx, ry, -90, 30, steps=14)
    draw_chalk_stroke(f0, arc0, CHALK_WHITE, width=2)
    tip_x, tip_y = arc0[-1]
    pygame.draw.circle(f0, (255, 255, 255), (int(tip_x), int(tip_y)), 2)
    for _ in range(4):
        pygame.draw.circle(f0, (200, 210, 225, 160), (int(tip_x + random.uniform(-4, 4)), int(tip_y + random.uniform(-3, 3))), 1)
    frames.append(f0)

    f1 = pygame.Surface((W, H), pygame.SRCALPHA)
    arc1 = get_ellipse_pts(CX, CY, rx, ry, -90, 270, steps=36)
    draw_chalk_stroke(f1, arc1, CHALK_WHITE, width=2)
    for _ in range(8):
        ca = math.radians(random.uniform(0, 360))
        cx_crumb = CX + (rx + random.uniform(-3, 3)) * math.cos(ca)
        cy_crumb = CY + (ry + random.uniform(-2, 2)) * math.sin(ca)
        pygame.draw.circle(f1, (200, 210, 220, 140), (int(cx_crumb), int(cy_crumb)), 1)
    frames.append(f1)

    f2 = pygame.Surface((W, H), pygame.SRCALPHA)
    f2.blit(f1, (0, 0))
    star_pts = get_star_pts(CX, CY, inner_rx, inner_ry)
    draw_chalk_stroke(f2, star_pts[:4], CHALK_WHITE, width=2)
    frames.append(f2)

    f3 = pygame.Surface((W, H), pygame.SRCALPHA)
    f3.blit(f1, (0, 0))
    draw_chalk_stroke(f3, star_pts, CHALK_WHITE, width=2)
    for ang in [0, 90, 180, 270]:
        ra = math.radians(ang)
        p1 = (CX + (rx - 4) * math.cos(ra), CY + (ry - 3) * math.sin(ra))
        p2 = (CX + (rx + 4) * math.cos(ra), CY + (ry + 3) * math.sin(ra))
        pygame.draw.line(f3, CHALK_WHITE, (int(p1[0]), int(p1[1])), (int(p2[0]), int(p2[1])), 2)
    frames.append(f3)

    # Phase 2: Chalk turns Blue & Glows (Frames 4 to 7)
    arc_pts = get_ellipse_pts(CX, CY, rx, ry, 0, 360, steps=36)

    f4 = pygame.Surface((W, H), pygame.SRCALPHA)
    draw_chalk_stroke(f4, arc_pts, (120, 220, 255, 230), width=2, dust=False)
    draw_chalk_stroke(f4, star_pts, (120, 220, 255, 230), width=2, dust=False)
    for sp_ang in [30, 110, 210, 300]:
        sa = math.radians(sp_ang)
        sx = CX + rx * math.cos(sa)
        sy = CY + ry * math.sin(sa)
        pygame.draw.circle(f4, (160, 240, 255, 220), (int(sx), int(sy)), 3)
        pygame.draw.circle(f4, (255, 255, 255), (int(sx), int(sy)), 1)
    frames.append(f4)

    f5 = pygame.Surface((W, H), pygame.SRCALPHA)
    glow_surf = pygame.Surface((W, H), pygame.SRCALPHA)
    pygame.draw.ellipse(glow_surf, (20, 120, 255, 80), (CX - rx - 6, CY - ry - 4, (rx + 6) * 2, (ry + 4) * 2), 6)
    f5.blit(glow_surf, (0, 0))
    draw_chalk_stroke(f5, arc_pts, (40, 160, 255, 240), width=4, dust=False)
    draw_chalk_stroke(f5, arc_pts, MANA_CORE, width=2, dust=False)
    draw_chalk_stroke(f5, star_pts, (40, 160, 255, 240), width=3, dust=False)
    draw_chalk_stroke(f5, star_pts, MANA_CORE, width=1, dust=False)
    for p in star_pts[:-1]:
        pygame.draw.circle(f5, (80, 220, 255), (int(p[0]), int(p[1])), 4)
        pygame.draw.circle(f5, (255, 255, 255), (int(p[0]), int(p[1])), 2)
    frames.append(f5)

    f6 = pygame.Surface((W, H), pygame.SRCALPHA)
    f6.blit(f5, (0, 0))
    for lx_off in [-35, -15, 0, 15, 35]:
        lx = CX + lx_off
        ly = CY - 2
        pillar = pygame.Surface((10, 70), pygame.SRCALPHA)
        for step in range(10):
            alpha = int(90 * (1.0 - step / 10.0))
            pygame.draw.line(pillar, (100, 210, 255, alpha), (5, 70 - step * 7), (5, 70 - (step + 1) * 7), 4)
        f6.blit(pillar, (lx - 5, ly - 65))
    frames.append(f6)

    f7 = pygame.Surface((W, H), pygame.SRCALPHA)
    f7.blit(f5, (0, 0))
    pygame.draw.circle(f7, (255, 255, 255), (CX, PORTAL_CY), 6)
    pygame.draw.circle(f7, (100, 220, 255, 220), (CX, PORTAL_CY), 12, 2)
    pygame.draw.circle(f7, (40, 140, 255, 140), (CX, PORTAL_CY), 18, 1)
    pygame.draw.line(f7, (255, 255, 255, 240), (CX - 22, PORTAL_CY), (CX + 22, PORTAL_CY), 2)
    pygame.draw.line(f7, (255, 255, 255, 240), (CX, PORTAL_CY - 16), (CX, PORTAL_CY + 16), 2)
    frames.append(f7)

    # Phase 3: Portal Swirling Above the Blue Seal (Frames 8 to 11)
    for p_idx in range(4):
        f = pygame.Surface((W, H), pygame.SRCALPHA)
        f.blit(f5, (0, 0))

        tether_surf = pygame.Surface((W, H), pygame.SRCALPHA)
        pygame.draw.line(tether_surf, (80, 200, 255, 90), (CX - 15, CY), (CX - 20, PORTAL_CY + 10), 2)
        pygame.draw.line(tether_surf, (80, 200, 255, 120), (CX, CY), (CX, PORTAL_CY + 12), 3)
        pygame.draw.line(tether_surf, (80, 200, 255, 90), (CX + 15, CY), (CX + 20, PORTAL_CY + 10), 2)
        f.blit(tether_surf, (0, 0))

        p_surf = pygame.Surface((90, 90), pygame.SRCALPHA)
        pcx, pcy = 45, 45
        rot_ang = p_idx * (math.pi / 2)
        p_rad = 34
        pygame.draw.circle(p_surf, (30, 100, 240, 140), (pcx, pcy), p_rad, 4)
        pygame.draw.circle(p_surf, (100, 220, 255, 220), (pcx, pcy), p_rad, 2)

        for i in range(4):
            na = rot_ang + i * (math.pi / 2)
            nx = pcx + int(p_rad * math.cos(na))
            ny = pcy + int(p_rad * math.sin(na))
            pygame.draw.circle(p_surf, (255, 255, 255), (nx, ny), 3)
            pygame.draw.circle(p_surf, (80, 210, 255), (nx, ny), 5, 1)

        for arm in range(3):
            arm_base = rot_ang * 1.5 + arm * (2 * math.pi / 3)
            pts_arm = []
            for r_step in range(6, 26, 3):
                theta = arm_base + (r_step * 0.14)
                ax = pcx + int(r_step * math.cos(theta))
                ay = pcy + int(r_step * math.sin(theta))
                pts_arm.append((ax, ay))
            if len(pts_arm) > 1:
                pygame.draw.lines(p_surf, (140, 230, 255, 220), False, pts_arm, 2)

        pygame.draw.circle(p_surf, (10, 18, 45, 240), (pcx, pcy), 14)
        pygame.draw.circle(p_surf, (220, 245, 255, 255), (pcx, pcy), 6)
        pygame.draw.circle(p_surf, (255, 255, 255), (pcx, pcy), 3)

        f.blit(p_surf, (CX - pcx, PORTAL_CY - pcy))
        frames.append(f)

    return frames


def load_or_generate_chalk_portal_frames():
    """
    Loads all 12 frames of the chalk ritual and blue glowing portal.
    If cached on disk, loads them instantly. Otherwise generates and saves them.
    """
    os.makedirs(PORTAL_CHALK_DIR, exist_ok=True)
    all_exist = all(os.path.exists(os.path.join(PORTAL_CHALK_DIR, f"portal_chalk_{i}.png")) for i in range(12))

    if all_exist:
        frames = []
        for i in range(12):
            path = os.path.join(PORTAL_CHALK_DIR, f"portal_chalk_{i}.png")
            frames.append(pygame.image.load(path).convert_alpha())
        return frames
    else:
        frames = generate_chalk_portal_frames()
        for idx, fr in enumerate(frames):
            path = os.path.join(PORTAL_CHALK_DIR, f"portal_chalk_{idx}.png")
            pygame.image.save(fr, path)
        return frames

