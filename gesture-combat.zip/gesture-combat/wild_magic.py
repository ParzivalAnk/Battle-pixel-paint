"""
wild_magic.py - Sacred Glyph Patterns, Blueprint Tracing, and Wild Magic Ritual Engine.
Part of the GLYPH-BLADE modular architecture.
"""

import os
import json
import math
import random
import pygame

from recognizer import Point, resample, scale_and_center, gesture_distance, path_length, SKILL_INFO
from config import VIEW_WIDTH, VIEW_HEIGHT, TEXT_GOLD, TEXT_CYAN, TEXT_RED, GLYPH_COMPLEXITY
from effects import render_mixed_text
from achievements import ACHIEVEMENT_MANAGER


def best_template_distance(u_pts, t_pts, is_closed=False):
    """Computes minimum matching distance considering stroke direction and cyclic shifts for loops."""
    best_d = float('inf')
    for direction in (t_pts, t_pts[::-1]):
        if is_closed:
            step = max(1, len(direction) // 16)
            for shift in range(0, len(direction), step):
                shifted = direction[shift:] + direction[:shift]
                d = gesture_distance(u_pts, shifted)
                if d < best_d:
                    best_d = d
        else:
            d = gesture_distance(u_pts, direction)
            if d < best_d:
                best_d = d
    return best_d


def _build_wild_magic_patterns():
    patterns = {}

    # 1. CRESCENT_BLADE (Tier 1 - 1 glyph, simple slash / thrust) - 18s
    pts_cres = []
    for i in range(32):
        t = i / 31.0
        x = 20.0 + 60.0 * t
        y = 50.0 - 32.0 * math.sin(math.pi * t)
        pts_cres.append(Point(x, y))
    for i in range(32):
        t = i / 31.0
        x = 80.0 - 60.0 * t
        y = 50.0 + 14.0 * math.sin(math.pi * t)
        pts_cres.append(Point(x, y))
    patterns["CRESCENT_BLADE"] = {
        "id": "CRESCENT_BLADE",
        "name": "Серповидный Клинок: Дуга Ветра",
        "symbol": "🌙",
        "color": (120, 240, 255),
        "desc": "Плавная серповидная дуга рассекающего ветра. Простой и быстрый росчерк!",
        "is_closed": True,
        "duration": 18.0,
        "boss_req": 0,
        "resampled": scale_and_center(resample(pts_cres, 64), 100.0),
        "raw_verts": [(20, 50), (50, 18), (80, 50), (50, 64), (20, 50)]
    }

    # 2. TRIANGLE_APEX (Tier 1 - 1 glyph, vertical / uppercut / defense) - 18s
    v_tri = [(50, 16), (84, 82), (16, 82), (50, 16)]
    pts_tri = []
    for i in range(len(v_tri) - 1):
        x1, y1 = v_tri[i]
        x2, y2 = v_tri[i + 1]
        for s in range(12):
            t = s / 12.0
            pts_tri.append(Point(x1 + t * (x2 - x1), y1 + t * (y2 - y1)))
    pts_tri.append(Point(v_tri[-1][0], v_tri[-1][1]))
    patterns["TRIANGLE_APEX"] = {
        "id": "TRIANGLE_APEX",
        "name": "Пирамида Стихий: Клинок Зари",
        "symbol": "△",
        "color": (255, 210, 80),
        "desc": "Священный треугольник стихий. 3 четкие грани и вершины!",
        "is_closed": True,
        "duration": 18.0,
        "boss_req": 0,
        "resampled": scale_and_center(resample(pts_tri, 64), 100.0),
        "raw_verts": v_tri
    }

    # 3. DIAMOND_SEAL (Tier 2 - 2 glyphs, balanced) - 19s
    v_dia = [(50, 14), (86, 50), (50, 86), (14, 50), (50, 14)]
    pts_dia = []
    for i in range(len(v_dia) - 1):
        x1, y1 = v_dia[i]
        x2, y2 = v_dia[i + 1]
        for s in range(12):
            t = s / 12.0
            pts_dia.append(Point(x1 + t * (x2 - x1), y1 + t * (y2 - y1)))
    pts_dia.append(Point(v_dia[-1][0], v_dia[-1][1]))
    patterns["DIAMOND_SEAL"] = {
        "id": "DIAMOND_SEAL",
        "name": "Алмаз Равновесия: Ромб Света",
        "symbol": "✦",
        "color": (255, 180, 50),
        "desc": "Четырехконечный алмазный кристалл. Четкий контур четырех сторон!",
        "is_closed": True,
        "duration": 19.0,
        "boss_req": 0,
        "resampled": scale_and_center(resample(pts_dia, 64), 100.0),
        "raw_verts": v_dia
    }

    # 4. HEXAGRAM_SEAL (Tier 2 - 2 glyphs, elemental synthesis) - 19s
    v_hex = [
        (50, 6), (68, 36), (94, 36), (72, 54),
        (82, 86), (50, 66), (18, 86), (28, 54),
        (6, 36), (32, 36), (50, 6)
    ]
    pts_hex = []
    for i in range(len(v_hex) - 1):
        x1, y1 = v_hex[i]
        x2, y2 = v_hex[i + 1]
        for s in range(8):
            t = s / 8.0
            pts_hex.append(Point(x1 + t * (x2 - x1), y1 + t * (y2 - y1)))
    pts_hex.append(Point(v_hex[-1][0], v_hex[-1][1]))
    patterns["HEXAGRAM_SEAL"] = {
        "id": "HEXAGRAM_SEAL",
        "name": "Гексаграмма Равновесия: Печать Соломона",
        "symbol": "✡",
        "color": (255, 160, 60),
        "desc": "Уникурсальная шестиконечная печать гармонии материи и духа!",
        "is_closed": True,
        "duration": 19.0,
        "boss_req": 0,
        "resampled": scale_and_center(resample(pts_hex, 64), 100.0),
        "raw_verts": v_hex
    }

    # 5. AETHER_LEMNISCATE (Tier 2 - 2 glyphs, flow / infinity) - 20s
    pts_lem = []
    for i in range(72):
        t = (2.0 * math.pi * i) / 71.0
        x = 50.0 + 38.0 * math.sin(t)
        y = 50.0 + 38.0 * math.sin(t) * math.cos(t)
        pts_lem.append(Point(x, y))
    patterns["AETHER_LEMNISCATE"] = {
        "id": "AETHER_LEMNISCATE",
        "name": "Омни-Петля: Бесконечность",
        "symbol": "∞",
        "color": (190, 130, 255),
        "desc": "Плавная непрерывная петля бесконечности. Вечный ток маны!",
        "is_closed": True,
        "duration": 20.0,
        "boss_req": 0,
        "resampled": scale_and_center(resample(pts_lem, 64), 100.0),
        "raw_verts": [(50, 50), (88, 50), (50, 50), (12, 50), (50, 50)]
    }

    # 6. CROWN_SERAPHIM (Tier 2 - 2 glyphs, defense / divinity) - 20s
    v_crown = [
        (18, 80), (15, 36), (32, 56), (50, 14), (68, 56), (85, 36), (82, 80), (18, 80)
    ]
    pts_crown = []
    for i in range(len(v_crown) - 1):
        x1, y1 = v_crown[i]
        x2, y2 = v_crown[i + 1]
        for s in range(8):
            t = s / 8.0
            pts_crown.append(Point(x1 + t * (x2 - x1), y1 + t * (y2 - y1)))
    pts_crown.append(Point(v_crown[-1][0], v_crown[-1][1]))
    patterns["CROWN_SERAPHIM"] = {
        "id": "CROWN_SERAPHIM",
        "name": "Венец Серафима: Божественный Суд",
        "symbol": "👑",
        "color": (255, 220, 60),
        "desc": "Трехзубчатая священная корона с прямым основанием!",
        "is_closed": True,
        "duration": 20.0,
        "boss_req": 0,
        "resampled": scale_and_center(resample(pts_crown, 64), 100.0),
        "raw_verts": v_crown
    }

    # 7. OCULUS_VOID (Tier 3 - 3 glyphs) - Single continuous almond mystic eye! 22s
    pts_eye = []
    for i in range(32):
        t = i / 31.0
        x = 12.0 + 76.0 * t
        y = 50.0 - 32.0 * math.sin(math.pi * t)
        pts_eye.append(Point(x, y))
    for i in range(32):
        t = i / 31.0
        x = 88.0 - 76.0 * t
        y = 50.0 + 32.0 * math.sin(math.pi * t)
        pts_eye.append(Point(x, y))
    patterns["OCULUS_VOID"] = {
        "id": "OCULUS_VOID",
        "name": "Око Бездны: Взгляд Пустоты",
        "symbol": "❂",
        "color": (180, 80, 255),
        "desc": "Мистический контур ока Бездны. Плавная непрерывная миндалевидная дуга!",
        "is_closed": True,
        "duration": 22.0,
        "boss_req": 0,
        "resampled": scale_and_center(resample(pts_eye, 64), 100.0),
        "raw_verts": [(12, 50), (50, 18), (88, 50), (50, 82), (12, 50)]
    }

    # 8. CHRONO_HOURGLASS_KNOT (Tier 3 - 3 glyphs, Boss 1 Unlock) - 22s
    v_hg = [(25, 20), (75, 20), (25, 80), (75, 80), (25, 20)]
    pts_hg = []
    for i in range(len(v_hg) - 1):
        x1, y1 = v_hg[i]
        x2, y2 = v_hg[i + 1]
        for s in range(12):
            t = s / 12.0
            pts_hg.append(Point(x1 + t * (x2 - x1), y1 + t * (y2 - y1)))
    pts_hg.append(Point(v_hg[-1][0], v_hg[-1][1]))
    patterns["CHRONO_HOURGLASS_KNOT"] = {
        "id": "CHRONO_HOURGLASS_KNOT",
        "name": "Хроно-Разлом: Временной Узел",
        "symbol": "⌛",
        "color": (90, 235, 255),
        "desc": "Песочные часы времени. 4 прямые грани с верхним и нижним основанием!",
        "is_closed": True,
        "duration": 22.0,
        "boss_req": 1,
        "resampled": scale_and_center(resample(pts_hg, 64), 100.0),
        "raw_verts": v_hg
    }

    # 9. VALKIRIA_BLADE_CREST (Tier 3 - 3 glyphs, Boss 2 Unlock) - 23s
    v_valk = [
        (50, 12), (75, 40), (88, 75), (50, 60), (12, 75), (25, 40), (50, 12)
    ]
    pts_valk = []
    for i in range(len(v_valk) - 1):
        x1, y1 = v_valk[i]
        x2, y2 = v_valk[i + 1]
        for s in range(10):
            t = s / 10.0
            pts_valk.append(Point(x1 + t * (x2 - x1), y1 + t * (y2 - y1)))
    pts_valk.append(Point(v_valk[-1][0], v_valk[-1][1]))
    patterns["VALKIRIA_BLADE_CREST"] = {
        "id": "VALKIRIA_BLADE_CREST",
        "name": "Герб Владычицы Клинков: Танец Стали",
        "symbol": "⚔",
        "color": (255, 130, 70),
        "desc": "Крылатый шеврон клинков Валькирии. 100% пробивание брони!",
        "is_closed": True,
        "duration": 23.0,
        "boss_req": 2,
        "resampled": scale_and_center(resample(pts_valk, 64), 100.0),
        "raw_verts": v_valk
    }

    # 10. HEPTAGRAM_CHAOS (Tier 4 - 4 glyphs) - 22s
    order_hept = [0, 3, 6, 2, 5, 1, 4, 0]
    v_hept = []
    for k in order_hept:
        ang = -math.pi / 2.0 + k * (2.0 * math.pi / 7.0)
        v_hept.append((50.0 + 40.0 * math.cos(ang), 50.0 + 40.0 * math.sin(ang)))
    pts_hept = []
    for i in range(len(v_hept) - 1):
        x1, y1 = v_hept[i]
        x2, y2 = v_hept[i + 1]
        for s in range(10):
            t = s / 10.0
            pts_hept.append(Point(x1 + t * (x2 - x1), y1 + t * (y2 - y1)))
    pts_hept.append(Point(v_hept[-1][0], v_hept[-1][1]))
    patterns["HEPTAGRAM_CHAOS"] = {
        "id": "HEPTAGRAM_CHAOS",
        "name": "Семиконечная Звезда Хаоса {7/3}",
        "symbol": "★",
        "color": (255, 60, 85),
        "desc": "Древняя семиконечная печать {7/3}. Непрерывно обведи все 7 лучей звезды!",
        "is_closed": True,
        "duration": 22.0,
        "boss_req": 0,
        "resampled": scale_and_center(resample(pts_hept, 64), 100.0),
        "raw_verts": v_hept
    }

    # 11. NECRO_SPIRE_SIGIL (Tier 4 - 4 glyphs, Boss 3 Unlock) - 24s
    v_necro = [(50, 92), (18, 32), (82, 32), (50, 92), (50, 8), (50, 92)]
    pts_necro = []
    for i in range(len(v_necro) - 1):
        x1, y1 = v_necro[i]
        x2, y2 = v_necro[i + 1]
        for s in range(10):
            t = s / 10.0
            pts_necro.append(Point(x1 + t * (x2 - x1), y1 + t * (y2 - y1)))
    pts_necro.append(Point(v_necro[-1][0], v_necro[-1][1]))
    patterns["NECRO_SPIRE_SIGIL"] = {
        "id": "NECRO_SPIRE_SIGIL",
        "name": "Печать Архилича: Шпиль Скверны",
        "symbol": "☠",
        "color": (120, 255, 140),
        "desc": "Перевернутая пирамида душ со сквозным шпилем некромантии!",
        "is_closed": True,
        "duration": 24.0,
        "boss_req": 3,
        "resampled": scale_and_center(resample(pts_necro, 64), 100.0),
        "raw_verts": v_necro
    }

    # 12. COSMIC_PENTACLE_SUPREME (Tier 5 - 5 glyphs! Ultimate Finisher!) - 25s
    order_star = [0, 2, 4, 1, 3, 0]
    v_star = []
    for idx in order_star:
        ang = -math.pi / 2.0 + idx * (2.0 * math.pi / 5.0)
        v_star.append((50.0 + 38.0 * math.cos(ang), 50.0 + 38.0 * math.sin(ang)))
    pts_star = []
    for i in range(len(v_star) - 1):
        x1, y1 = v_star[i]
        x2, y2 = v_star[i + 1]
        for s in range(12):
            t = s / 12.0
            pts_star.append(Point(x1 + t * (x2 - x1), y1 + t * (y2 - y1)))
    pts_star.append(Point(v_star[-1][0], v_star[-1][1]))
    patterns["COSMIC_PENTACLE_SUPREME"] = {
        "id": "COSMIC_PENTACLE_SUPREME",
        "name": "Сверхновая Пяти Стихий: Великая Печать",
        "symbol": "✦",
        "color": (255, 235, 90),
        "desc": "Великая пятиконечная печать стихийного синтеза. Активирует финишер катсцены!",
        "is_closed": True,
        "duration": 25.0,
        "boss_req": 0,
        "resampled": scale_and_center(resample(pts_star, 64), 100.0),
        "raw_verts": v_star
    }

    # 13. JUDGEMENT_SCALES (Tier 5 - 5 glyphs, Boss 4 / 50 Unlock) - 25s
    v_judge = [
        (50, 10), (14, 28), (86, 28), (50, 10),
        (50, 88), (24, 88), (76, 88), (50, 88),
        (14, 28), (4, 56), (24, 56), (14, 28),
        (86, 28), (76, 56), (96, 56), (86, 28),
        (50, 10)
    ]
    pts_judge = []
    for i in range(len(v_judge) - 1):
        x1, y1 = v_judge[i]
        x2, y2 = v_judge[i + 1]
        for s in range(8):
            t = s / 8.0
            pts_judge.append(Point(x1 + t * (x2 - x1), y1 + t * (y2 - y1)))
    pts_judge.append(Point(v_judge[-1][0], v_judge[-1][1]))
    patterns["JUDGEMENT_SCALES"] = {
        "id": "JUDGEMENT_SCALES",
        "name": "Весы Истины: Абсолютный Вердикт",
        "symbol": "⚖",
        "color": (255, 240, 150),
        "desc": "Небесные Весы Правосудия. Абсолютное уничтожение всей арены!",
        "is_closed": True,
        "duration": 25.0,
        "boss_req": 4,
        "resampled": scale_and_center(resample(pts_judge, 64), 100.0),
        "raw_verts": v_judge
    }

    load_custom_wild_glyphs(patterns)
    return patterns


def load_custom_wild_glyphs(target_dict=None):
    """Loads developer-created custom wild glyphs from custom_wild_glyphs.json."""
    if target_dict is None:
        target_dict = WILD_MAGIC_PATTERNS
    file_path = "custom_wild_glyphs.json"
    if not os.path.exists(file_path):
        return
    try:
        with open(file_path, "r", encoding="utf-8") as f:
            data = json.load(f)
        for gid, item in data.items():
            pts_obj = [Point(c[0], c[1]) for c in item.get("resampled_coords", [])]
            target_dict[gid] = {
                "id": gid,
                "name": item.get("name", gid),
                "symbol": item.get("symbol", "✦"),
                "color": tuple(item.get("color", (120, 240, 255))),
                "desc": item.get("desc", "Священный глиф созданный в Студии Разработчика."),
                "is_closed": item.get("is_closed", False),
                "duration": float(item.get("duration", 20.0)),
                "boss_req": int(item.get("boss_req", 0)),
                "resampled": pts_obj,
                "raw_verts": item.get("raw_verts", [])
            }
    except Exception as e:
        print(f"[WildMagic] Note: custom wild glyphs file load error: {e}")


def register_wild_magic_pattern(pattern_dict):
    """Dynamically registers a custom pattern into the active WILD_MAGIC_PATTERNS registry."""
    WILD_MAGIC_PATTERNS[pattern_dict["id"]] = pattern_dict


WILD_MAGIC_PATTERNS = _build_wild_magic_patterns()


def get_wild_magic_pattern_for_queue(game):
    """Picks a sacred complex pattern dynamically based on rune count, complexity, and elemental theme."""
    q = game.wild_magic_queue
    if not q:
        return WILD_MAGIC_PATTERNS["CRESCENT_BLADE"]

    unlocked = getattr(game, "unlocked_wild_magic_glyphs", {
        "CRESCENT_BLADE", "TRIANGLE_APEX", "DIAMOND_SEAL", "HEXAGRAM_SEAL",
        "AETHER_LEMNISCATE", "CROWN_SERAPHIM", "OCULUS_VOID", "HEPTAGRAM_CHAOS",
        "COSMIC_PENTACLE_SUPREME"
    })

    count = len(q)
    total_comp = sum(GLYPH_COMPLEXITY.get(g, 1) for g in q)

    has_time = any(g in ("HOURGLASS_SWAP", "PARRY") for g in q)
    has_blade = any(g in ("SLASH_H", "SLASH_V", "THRUST") for g in q) and ("CROSS" in q or count >= 3)
    has_defense = any(g in ("SHIELD_BLOCK", "TRIANGLE") for g in q)
    has_chaos = any(g in ("STAR_PENTAGRAM", "UPPERCUT") for g in q)
    has_void = any(g in ("CIRCLE", "CUSTOM_GLYPH") for g in q)
    has_flow = any(g in ("INFINITY", "ZIGZAG") for g in q)

    # Tier 5: 5 runes in buffer! The Ultimate 5-Rune Finisher!
    if count == 5:
        if has_defense and ("JUDGEMENT_SCALES" in unlocked):
            return WILD_MAGIC_PATTERNS["JUDGEMENT_SCALES"]
        return WILD_MAGIC_PATTERNS["COSMIC_PENTACLE_SUPREME"]

    # Tier 4: 4 runes in buffer
    if count == 4:
        if (has_chaos or has_void) and ("NECRO_SPIRE_SIGIL" in unlocked):
            return WILD_MAGIC_PATTERNS["NECRO_SPIRE_SIGIL"]
        if has_time and ("CHRONO_HOURGLASS_KNOT" in unlocked):
            return WILD_MAGIC_PATTERNS["CHRONO_HOURGLASS_KNOT"]
        if has_defense:
            return WILD_MAGIC_PATTERNS["CROWN_SERAPHIM"]
        if has_void:
            return WILD_MAGIC_PATTERNS["OCULUS_VOID"]
        return WILD_MAGIC_PATTERNS["HEPTAGRAM_CHAOS"]

    # Tier 3: 3 runes or high complexity (>= 6)
    if count == 3 or total_comp >= 6:
        if has_time:
            if "CHRONO_HOURGLASS_KNOT" in unlocked:
                return WILD_MAGIC_PATTERNS["CHRONO_HOURGLASS_KNOT"]
            else:
                return WILD_MAGIC_PATTERNS["AETHER_LEMNISCATE"]  # Locked fallback
        if has_blade and ("VALKIRIA_BLADE_CREST" in unlocked):
            return WILD_MAGIC_PATTERNS["VALKIRIA_BLADE_CREST"]
        if has_defense and not has_chaos:
            return WILD_MAGIC_PATTERNS["CROWN_SERAPHIM"]
        if has_void and not has_chaos:
            return WILD_MAGIC_PATTERNS["OCULUS_VOID"]
        if has_chaos:
            return WILD_MAGIC_PATTERNS["HEPTAGRAM_CHAOS"]
        if has_flow:
            return WILD_MAGIC_PATTERNS["AETHER_LEMNISCATE"]
        return WILD_MAGIC_PATTERNS["DIAMOND_SEAL"]

    # Tier 2: 2 runes or medium complexity (>= 3)
    if count == 2 or total_comp >= 3:
        if has_defense:
            return WILD_MAGIC_PATTERNS["CROWN_SERAPHIM"]
        if has_flow or has_time:
            return WILD_MAGIC_PATTERNS["AETHER_LEMNISCATE"]
        if has_chaos:
            return WILD_MAGIC_PATTERNS["HEXAGRAM_SEAL"]
        return WILD_MAGIC_PATTERNS["DIAMOND_SEAL"]

    # Tier 1: 1 basic rune (count == 1) - Clean single-stroke shapes!
    if has_defense or any(g in ("UPPERCUT", "CROSS") for g in q):
        return WILD_MAGIC_PATTERNS["TRIANGLE_APEX"]
    return WILD_MAGIC_PATTERNS["CRESCENT_BLADE"]


def trigger_wild_magic_start(game):
    """Validates queue and triggers the Wild Magic Ritual."""
    if game.state not in ('PLAYING', 'DOJO'):
        return
    if getattr(game, 'wild_magic_state', None) == 'RITUAL':
        return
    if not game.wild_magic_queue:
        game.fx.add_floating_text("Сначала начерти знаки для комбо (1-5 знаков)!", game.player.x, game.player.y - 45, (255, 130, 90), size=22)
        game.sfx.play("fumble")
        return
    start_wild_magic_ritual(game)


def start_wild_magic_ritual(game):
    """Initiates the dramatic slow-motion Wild Magic drawing ritual with extended duration."""
    pattern = get_wild_magic_pattern_for_queue(game)
    game.wild_magic_pattern = pattern
    game.wild_magic_state = 'RITUAL'
    duration = pattern.get("duration", 20.0)
    game.wild_magic_max_timer = duration
    game.wild_magic_timer = duration
    game.wild_magic_drawn_points = []
    game.is_drawing_wild_magic = False
    game.wild_magic_live_score = 0.0
    game.bullet_time_timer = duration
    game.fx.add_screen_shake(15.0)
    game.sfx.play("crit")
    game.fx.add_floating_text(
        f"⚡ РИТУАЛ ДИКОЙ МАГИИ: {pattern['name']} ({duration:.0f}с)! ⚡",
        game.player.x, game.player.y - 65, pattern["color"], size=28
    )


def evaluate_wild_magic_drawing(game):
    """Evaluates the player's tracing of the sacred glyph and unleashes the cataclysm."""
    if not game.wild_magic_pattern:
        game.wild_magic_state = None
        return

    pts = [Point(x, y) for x, y in game.wild_magic_drawn_points]
    # Ignore accidental micro-clicks
    if len(pts) < 14 or path_length(pts) < 90.0:
        game.wild_magic_drawn_points = []
        return

    resampled_user = resample(pts, 64)
    norm_user = scale_and_center(resampled_user, 100.0)

    pattern = game.wild_magic_pattern
    template_norm = pattern["resampled"]
    is_closed = pattern.get("is_closed", False)

    best_d = best_template_distance(norm_user, template_norm, is_closed=is_closed)
    # Forgiving tolerance: divisor increased from strict 48.0 to 68.0 for fluid tracing satisfaction!
    score = max(0.0, min(1.0, 1.0 - (best_d / 68.0)))
    acc_pct = int(score * 100)

    # Accuracy tiers
    if acc_pct >= 85:
        tier_title = "СОВЕРШЕНСТВО (PERFECT)"
        acc_mult = 2.5
        tier_color = TEXT_GOLD
        game.sfx.play("crit")
    elif acc_pct >= 68:
        tier_title = "ЧИСТЫЙ РОСЧЕРК (CLEAN)"
        acc_mult = 1.7
        tier_color = TEXT_CYAN
        game.sfx.play("crit")
    else:
        tier_title = "ИСКАЖЕНИЕ (SLOPPY)"
        acc_mult = 0.60
        tier_color = (255, 110, 70)
        game.sfx.play("fumble")

    # Cataclysm damage calculation
    count = max(1, len(game.wild_magic_queue))
    base_dmg = 120.0 * count
    total_dmg = base_dmg * acc_mult * game.player.weapon.damage_mult * game.player.bonus_damage_mult

    # -----------------------------------------------------------------
    # CINEMATIC 5-GLYPH BOSS FINISHER TRIGGER
    # -----------------------------------------------------------------
    is_5_glyph = (count >= 5) or (pattern["id"] in ("COSMIC_PENTACLE_SUPREME", "JUDGEMENT_SCALES"))
    target_boss = next((en for en in game.enemies if en.alive and getattr(en, 'is_boss', False)), None)

    if is_5_glyph and target_boss and hasattr(game, 'start_5_glyph_boss_cutscene'):
        game.start_5_glyph_boss_cutscene(
            target_boss, total_dmg, pattern, list(game.wild_magic_queue),
            len([e for e in game.enemies if e.alive]), acc_pct, tier_title, tier_color
        )
        return

    # Detonate Wild Magic on field (standard execution)
    game.fx.add_screen_shake(35.0 if acc_pct >= 68 else 18.0)
    game.fx.spawn_sparks(game.player.x, game.player.y, pattern["color"], count=60, speed=360)
    game.art.add_scorch_mark(game.player.x, game.player.y, radius=90)

    # Hit and apply status to all enemies
    hit_count = 0
    q = list(game.wild_magic_queue)
    for en in game.enemies:
        if en.alive:
            hit_count += 1
            dx = en.x - game.player.x
            dy = en.y - game.player.y
            dist = max(1.0, math.hypot(dx, dy))
            kb_x = (dx / dist) * 350.0
            kb_y = (dy / dist) * 350.0

            # Status ailments according to combo runes & sacred patterns
            if "PARRY" in q or pattern["id"] == "CHRONO_HOURGLASS_KNOT":
                en.is_frozen = True
                en.stun_timer = max(en.stun_timer, 4.5)
            if "ZIGZAG" in q or pattern["id"] == "AETHER_LEMNISCATE":
                en.stun_timer = max(en.stun_timer, 3.2)
            if "UPPERCUT" in q or pattern["id"] in ("HEPTAGRAM_CHAOS", "COSMIC_PENTACLE_SUPREME"):
                en.is_burning = True
                en.burn_timer = 5.0

            en.take_hit(total_dmg, kb_x, kb_y, 0.35, True, game.fx, game.sfx, spell_tag="ДИКАЯ МАГИЯ", player=game.player)
            game.art.add_blood_splatter(en.x, en.y, count=6)

    # Secondary boons
    if pattern["id"] == "NECRO_SPIRE_SIGIL":
        heal_amt = hit_count * 25.0
        if heal_amt > 0 and game.player.alive:
            game.player.hp += heal_amt
            game.fx.add_floating_text(f"+{int(heal_amt)} HP (ПОЖИРАНИЕ ДУШ)!", game.player.x, game.player.y - 45, (120, 255, 140), size=24)
    if pattern["id"] == "CHRONO_HOURGLASS_KNOT":
        game.player.bonus_speed_mult = max(getattr(game.player, 'bonus_speed_mult', 1.0), 1.45)
        game.fx.add_floating_text("ВРЕМЕННОЕ УСКОРЕНИЕ +45%!", game.player.x, game.player.y - 45, (90, 235, 255), size=24)

    # Massive floating banner text
    game.fx.add_floating_text(
        f"★★★ ДИКАЯ МАГИЯ: {pattern['name']} ({acc_pct}%) — {tier_title}! ★★★",
        game.player.x, game.player.y - 75, tier_color, size=28
    )
    game.fx.add_floating_text(
        f"+{int(total_dmg)} УРОНА ПО {hit_count} ВРАГАМ!",
        game.player.x, game.player.y - 105, TEXT_GOLD, size=24
    )

    ACHIEVEMENT_MANAGER.unlock("wild_magic_unleashed", game.fx, game.sfx)

    # Clear queue and end ritual
    game.wild_magic_queue.clear()
    game.wild_magic_state = None
    game.wild_magic_drawn_points = []
    game.draw_cooldown = 0.45
    game.bullet_time_timer = 0.0


def draw_wild_magic_ritual(game, surface):
    """Renders the sacred blueprint and live player tracing ritual overlay."""
    if not game.wild_magic_pattern:
        return

    pattern = game.wild_magic_pattern
    w = surface.get_width()
    h = surface.get_height()

    # Dark overlay
    overlay = pygame.Surface((w, h), pygame.SRCALPHA)
    overlay.fill((6, 10, 18, 220))
    surface.blit(overlay, (0, 0))

    # Centered canvas
    cw = 420
    ch = 420
    cx = w // 2 - cw // 2
    cy = h // 2 - ch // 2 + 30
    canvas_rect = pygame.Rect(cx, cy, cw, ch)

    # Canvas frame & background
    pygame.draw.rect(surface, (14, 20, 32), canvas_rect, border_radius=12)
    pulse = (math.sin(game.anim_time * 5.0) + 1.0) * 0.5
    col = pattern["color"]
    glow_col = (
        min(255, int(col[0] * 0.7 + 70 * pulse)),
        min(255, int(col[1] * 0.7 + 70 * pulse)),
        min(255, int(col[2] * 0.7 + 70 * pulse))
    )
    pygame.draw.rect(surface, glow_col, canvas_rect, 2, border_radius=12)

    # Runic corners / corner brackets
    cor_len = 18
    for (ox, oy, dx, dy) in [
        (cx + 6, cy + 6, 1, 1),
        (cx + cw - 6, cy + 6, -1, 1),
        (cx + 6, cy + ch - 6, 1, -1),
        (cx + cw - 6, cy + ch - 6, -1, -1)
    ]:
        pygame.draw.line(surface, TEXT_GOLD, (ox, oy), (ox + dx * cor_len, oy), 2)
        pygame.draw.line(surface, TEXT_GOLD, (ox, oy), (ox, oy + dy * cor_len), 2)

    # Subtle cosmic circles in background
    pygame.draw.circle(surface, (25, 35, 55), (cx + cw // 2, cy + ch // 2), 170, 1)
    pygame.draw.circle(surface, (25, 35, 55), (cx + cw // 2, cy + ch // 2), 90, 1)

    # Banner Title
    t_surf = render_mixed_text("⚡ РИТУАЛ ДИКОЙ МАГИИ ⚡", game.font_title, game.font_sym_large, TEXT_GOLD)
    surface.blit(t_surf, (w // 2 - t_surf.get_width() // 2, cy - 90))

    name_surf = game.font_large.render(f"«{pattern['name']}»", True, pattern["color"])
    surface.blit(name_surf, (w // 2 - name_surf.get_width() // 2, cy - 54))

    sub_surf = game.font_small.render("АККУРАТНО И ТОЧНО ОБВЕДИ ЗНАК ПО КОНТУРУ [Зажми ЛКМ и веди]  •  [ESC] Отмена", True, (180, 200, 225))
    surface.blit(sub_surf, (w // 2 - sub_surf.get_width() // 2, cy - 26))

    # Sacred Blueprint Outline Points
    margin = 35
    scale_x = (cw - margin * 2) / 100.0
    scale_y = (ch - margin * 2) / 100.0
    template_screen_pts = []
    for p in pattern["resampled"]:
        sx = cx + margin + (p.x + 50.0) * scale_x
        sy = cy + margin + (p.y + 50.0) * scale_y
        template_screen_pts.append((sx, sy))

    # Draw blueprint glowing outline
    if len(template_screen_pts) >= 2:
        # Outer aura
        for i in range(len(template_screen_pts) - 1):
            p1 = template_screen_pts[i]
            p2 = template_screen_pts[i + 1]
            pygame.draw.line(surface, (col[0] // 3, col[1] // 3, col[2] // 3), p1, p2, 6)
        # Core line
        for i in range(len(template_screen_pts) - 1):
            p1 = template_screen_pts[i]
            p2 = template_screen_pts[i + 1]
            pygame.draw.line(surface, col, p1, p2, 2)

    # Vertex control dots
    for vx, vy in pattern.get("raw_verts", []):
        vsx = cx + margin + vx * scale_x
        vsy = cy + margin + vy * scale_y
        pygame.draw.circle(surface, col, (int(vsx), int(vsy)), 4)
        pygame.draw.circle(surface, (255, 255, 255), (int(vsx), int(vsy)), 2)

    # Start Dot Marker
    if template_screen_pts:
        s_pt = template_screen_pts[0]
        pygame.draw.circle(surface, (80, 255, 120), (int(s_pt[0]), int(s_pt[1])), 7)
        pygame.draw.circle(surface, (255, 255, 255), (int(s_pt[0]), int(s_pt[1])), 3)
        start_lbl = render_mixed_text("СТАРТ ➔", game.font_small, game.font_sym_small, (100, 255, 140))
        surface.blit(start_lbl, (int(s_pt[0]) + 10, int(s_pt[1]) - 10))

    # Travelling guiding spark / wisp along template
    if template_screen_pts:
        spark_idx = int(((game.anim_time * 0.35) % 1.0) * (len(template_screen_pts) - 1))
        sp_pos = template_screen_pts[spark_idx]
        pygame.draw.circle(surface, (255, 255, 255), (int(sp_pos[0]), int(sp_pos[1])), 5)
        pygame.draw.circle(surface, pattern["color"], (int(sp_pos[0]), int(sp_pos[1])), 10, 2)

    # Player's Drawn Stroke
    if len(game.wild_magic_drawn_points) >= 2:
        pygame.draw.lines(surface, (70, 220, 255), False, game.wild_magic_drawn_points, 7)
        pygame.draw.lines(surface, (255, 255, 255), False, game.wild_magic_drawn_points, 2)
        tip_x, tip_y = game.wild_magic_drawn_points[-1]
        pygame.draw.circle(surface, (255, 255, 200), (tip_x, tip_y), 6)

    # Live Accuracy Meter (forgiving 68.0 divisor)
    if len(game.wild_magic_drawn_points) >= 12:
        u_res = resample([Point(x, y) for x, y in game.wild_magic_drawn_points], 64)
        u_norm = scale_and_center(u_res, 100.0)
        d_live = best_template_distance(u_norm, pattern["resampled"], is_closed=pattern.get("is_closed", False))
        live_acc = int(max(0.0, min(1.0, 1.0 - (d_live / 68.0))) * 100)
        acc_col = TEXT_GOLD if live_acc >= 85 else (TEXT_CYAN if live_acc >= 68 else (255, 120, 60))
        acc_surf = game.font_med.render(f"ТОЧНОСТЬ: {live_acc}%", True, acc_col)
        surface.blit(acc_surf, (cx + cw // 2 - acc_surf.get_width() // 2, cy + ch - 35))

    # Countdown Timer Bar at bottom
    bar_w = cw
    bar_h = 8
    bar_y = cy + ch + 12
    pygame.draw.rect(surface, (20, 24, 36), (cx, bar_y, bar_w, bar_h), border_radius=4)
    max_t = getattr(game, 'wild_magic_max_timer', pattern.get("duration", 20.0))
    t_ratio = max(0.0, min(1.0, game.wild_magic_timer / max_t))
    t_col = TEXT_CYAN if game.wild_magic_timer > 5.0 else TEXT_RED
    pygame.draw.rect(surface, t_col, (cx, bar_y, int(bar_w * t_ratio), bar_h), border_radius=4)
    pygame.draw.rect(surface, (60, 80, 120), (cx, bar_y, bar_w, bar_h), 1, border_radius=4)

    t_lbl = game.font_small.render(f"ВРЕМЯ: {game.wild_magic_timer:.1f}с / {max_t:.0f}с", True, (170, 190, 220))
    surface.blit(t_lbl, (cx + bar_w // 2 - t_lbl.get_width() // 2, bar_y + 12))
