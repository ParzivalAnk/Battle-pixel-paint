"""
test_monster_immunities.py - Verification of Innate Monster Elemental Immunities.
Validates:
1. Bestiary definitions for all immune monsters across factions.
2. Complete damage nullification (0 dmg) when matching immune damage categories:
   - Fire immunity (magma_golem, ember_wisp, obsidian_juggernaut, plasma_vortex_entity)
   - Ice/Freeze immunity (frost_shardling, death_knight) + cannot be frozen
   - Lightning immunity (spark_elemental, runic_automaton)
   - Physical/Blade immunity (crypt_wraith, aether_phantom, stone_sentry, crimson_executioner, lodestone_golem)
   - Void immunity (void_stalker, shadow_drinker, lich_archivist)
3. Vulnerability to non-immune elements.
4. Glacial stasis immunity handling.
5. Visual overhead badges and floating combat text rendering.
"""

import os
os.environ["SDL_VIDEODRIVER"] = "dummy"
import pygame
pygame.init()

from game_engine import Game
from entities import Enemy
from bestiary import BESTIARY, DAMAGE_CATEGORIES, get_spell_damage_categories
from abilities import GlacialStasis

print("=== TEST 1: Initializing Game & Verifying Bestiary Immunities ===")
game = Game()
game.start_run()
assert len(BESTIARY) >= 40

immune_monsters = [
    ("magma_golem", "FIRE"),
    ("ember_wisp", "FIRE"),
    ("obsidian_juggernaut", "FIRE"),
    ("plasma_vortex_entity", "FIRE"),
    ("frost_shardling", "ICE"),
    ("death_knight", "ICE"),
    ("spark_elemental", "LIGHTNING"),
    ("runic_automaton", "LIGHTNING"),
    ("crypt_wraith", "PHYSICAL"),
    ("aether_phantom", "PHYSICAL"),
    ("stone_sentry", "PHYSICAL"),
    ("crimson_executioner", "PHYSICAL"),
    ("lodestone_golem", "PHYSICAL"),
    ("void_stalker", "VOID"),
    ("shadow_drinker", "VOID"),
    ("lich_archivist", "VOID")
]

for mid, cat in immune_monsters:
    assert mid in BESTIARY, f"Enemy '{mid}' not found in BESTIARY!"
    entry = BESTIARY[mid]
    assert "immunities" in entry, f"Enemy '{mid}' missing 'immunities' field!"
    assert cat in entry["immunities"], f"Enemy '{mid}' should be immune to {cat}, has {entry['immunities']}"
print(f"Verified all {len(immune_monsters)} immune enemy definitions in BESTIARY!")

print("\n=== TEST 2: Testing FIRE Immunity (Magma Golem) ===")
golem = Enemy(300, 300, "magma_golem")
assert golem.is_immune_to("FIRE")
initial_hp = golem.hp

# Hit with FIRE -> Must deal 0 damage
golem.take_hit(50.0, 0, 0, 0.5, False, game.fx, game.sfx, spell_tag="ОГОНЬ", player=game.player)
assert golem.hp == initial_hp, f"Magma golem should take 0 fire damage! Current HP: {golem.hp}/{initial_hp}"

# Hit with INFERNO -> Must deal 0 damage
golem.take_hit(120.0, 0, 0, 0.5, False, game.fx, game.sfx, spell_tag="ИНФЕРНО", player=game.player)
assert golem.hp == initial_hp, f"Magma golem should take 0 inferno damage! Current HP: {golem.hp}/{initial_hp}"

# Hit with METEOR -> Must deal 0 damage
golem.take_hit(80.0, 0, 0, 0.5, False, game.fx, game.sfx, spell_tag="МЕТЕОР", player=game.player)
assert golem.hp == initial_hp, f"Magma golem should take 0 meteor damage! Current HP: {golem.hp}/{initial_hp}"

# Hit with non-immune element (ICE / КРИО) -> Must take full damage!
golem.take_hit(40.0, 0, 0, 0.5, False, game.fx, game.sfx, spell_tag="КРИО", player=game.player)
assert golem.hp == initial_hp - 40.0, f"Magma golem should take cryo damage! Current HP: {golem.hp}"
print(f"FIRE immunity verified! Took 0 damage from Fire/Inferno/Meteor, took normal damage from Cryo.")

print("\n=== TEST 3: Testing ICE Immunity (Frost Shardling & Death Knight) ===")
shardling = Enemy(400, 300, "frost_shardling")
assert shardling.is_immune_to("ICE")
shard_hp = shardling.hp

# Attempt to freeze shardling
shardling.is_frozen = True
assert shardling.is_frozen == False, "Ice immune monster must never become frozen!"

# Hit with CRYO -> Must deal 0 damage and NOT freeze
shardling.take_hit(60.0, 0, 0, 0.5, False, game.fx, game.sfx, spell_tag="КРИО", player=game.player)
assert shardling.hp == shard_hp, f"Frost shardling should take 0 ice damage! HP: {shardling.hp}"
assert shardling.is_frozen == False

# Hit with ULTRA-FREEZE -> Must deal 0 damage
shardling.take_hit(150.0, 0, 0, 0.5, False, game.fx, game.sfx, spell_tag="УЛЬТРА-ЗАМОРОЗКА", player=game.player)
assert shardling.hp == shard_hp, f"Frost shardling should take 0 ultra freeze damage! HP: {shardling.hp}"
assert shardling.is_frozen == False

# Test GlacialStasis ability: should immediately abort on ice-immune enemy
stasis = GlacialStasis(shardling, 1.0, game.player)
assert stasis.alive == False, "GlacialStasis must terminate immediately on ice-immune enemies!"
assert shardling.is_frozen == False

# Hit with non-immune element (FIRE / ОГОНЬ) -> Melts the shardling!
shardling.take_hit(50.0, 0, 0, 0.5, False, game.fx, game.sfx, spell_tag="ОГОНЬ", player=game.player)
assert shardling.hp == shard_hp - 50.0, f"Frost shardling should take fire damage! HP: {shardling.hp}"
print("ICE immunity verified! Immune to Cryo, Ultra-Freeze, and Glacial Stasis, took normal damage from Fire.")

print("\n=== TEST 4: Testing LIGHTNING Immunity (Spark Elemental) ===")
spark = Enemy(500, 300, "spark_elemental")
assert spark.is_immune_to("LIGHTNING")
spark_hp = spark.hp

# Hit with LIGHTNING / ГРОЗА -> 0 damage
spark.take_hit(45.0, 0, 0, 0.5, False, game.fx, game.sfx, spell_tag="МОЛНИЯ", player=game.player)
assert spark.hp == spark_hp
spark.take_hit(90.0, 0, 0, 0.5, False, game.fx, game.sfx, spell_tag="ГРОЗА", player=game.player)
assert spark.hp == spark_hp

# Hit with PHYSICAL / РАЗРУБ -> Takes damage!
spark.take_hit(30.0, 0, 0, 0.5, False, game.fx, game.sfx, spell_tag="РАЗРУБ", player=game.player)
assert spark.hp == spark_hp - 30.0
print("LIGHTNING immunity verified! Absorbed Lightning and Thunder, damaged by Physical Slash.")

print("\n=== TEST 5: Testing PHYSICAL Immunity (Crypt Wraith - Incorporeal Ghost) ===")
wraith = Enemy(600, 300, "crypt_wraith")
assert wraith.is_immune_to("PHYSICAL")
wraith_hp = wraith.hp

# Hit with BLADES (АТАКА, РАЗРУБ, ОМНИСЛЕШ, БАЗОВЫЙ РАЗРЕЗ) -> Incorporeal passes harmlessly (0 damage)
wraith.take_hit(40.0, 0, 0, 0.5, False, game.fx, game.sfx, spell_tag="АТАКА", player=game.player)
assert wraith.hp == wraith_hp
wraith.take_hit(70.0, 0, 0, 0.5, False, game.fx, game.sfx, spell_tag="РАЗРУБ", player=game.player)
assert wraith.hp == wraith_hp
wraith.take_hit(25.0, 0, 0, 0.5, False, game.fx, game.sfx, spell_tag="ОМНИСЛЕШ", player=game.player)
assert wraith.hp == wraith_hp
wraith.take_hit(35.0, 0, 0, 0.5, False, game.fx, game.sfx, spell_tag="БАЗОВЫЙ РАЗРЕЗ", player=game.player)
assert wraith.hp == wraith_hp

# Hit with MAGIC (FIRE / ОГОНЬ) -> Obliterates the ghost!
wraith.take_hit(60.0, 0, 0, 0.5, False, game.fx, game.sfx, spell_tag="ОГОНЬ", player=game.player)
assert wraith.hp == wraith_hp - 60.0
print("PHYSICAL immunity verified! Incorporeal body ignores blade slashes, takes full damage from magic.")

print("\n=== TEST 6: Testing VOID Immunity (Void Stalker) ===")
stalker = Enemy(700, 300, "void_stalker")
assert stalker.is_immune_to("VOID")
stalker_hp = stalker.hp

# Hit with VOID (СИНГУЛЯРНОСТЬ, РАЗРЫВ) -> 0 damage
stalker.take_hit(50.0, 0, 0, 0.5, False, game.fx, game.sfx, spell_tag="СИНГУЛЯРНОСТЬ", player=game.player)
assert stalker.hp == stalker_hp
stalker.take_hit(100.0, 0, 0, 0.5, False, game.fx, game.sfx, spell_tag="РАЗРЫВ", player=game.player)
assert stalker.hp == stalker_hp

# Hit with LIGHTNING -> Takes damage!
stalker.take_hit(40.0, 0, 0, 0.5, False, game.fx, game.sfx, spell_tag="МОЛНИЯ", player=game.player)
assert stalker.hp == stalker_hp - 40.0
print("VOID immunity verified! Nullified Singularity and Rift, damaged by Lightning.")

print("\n=== TEST 7: Testing Hybrid / Compound Spell Partial Immunity ===")
# Cryo-Meteor (Compound of ICE + FIRE) against ICE-immune Death Knight
dk = Enemy(800, 300, "death_knight")
dk_hp = dk.hp
# Cryo-Meteor has categories: {'ICE', 'FIRE'}. Since Death Knight is immune to ICE, the ICE component is blocked and damage is reduced by 50%
dk.take_hit(100.0, 0, 0, 0.5, False, game.fx, game.sfx, spell_tag="КРИО-МЕТЕОР", player=game.player)
assert dk.hp == dk_hp - 50.0, f"Death Knight should take 50% partial damage from Cryo-Meteor! Current HP: {dk.hp}/{dk_hp}"
assert dk.is_frozen == False, "Death Knight must not be frozen even by Cryo-Meteor!"
print("Hybrid spell partial immunity verified! 50% damage applied, freeze status blocked.")

print("\n=== TEST 8: Visual Rendering of Overhead Immunity Badges & Screenshot ===")
game.state = 'PLAYING'
game.player.x = 950.0
game.player.y = 480.0

game.enemies = [
    Enemy(420, 380, "magma_golem"),
    Enemy(680, 380, "frost_shardling"),
    Enemy(950, 380, "spark_elemental"),
    Enemy(1220, 380, "crypt_wraith"),
    Enemy(1480, 380, "void_stalker"),
]

# Clear any leftover texts from earlier unit tests
game.fx.floating_texts.clear()

# Trigger a hit on each with their immune element -> sparks and parry only, NO text!
game.enemies[0].take_hit(50, 0, 0, 0, False, game.fx, game.sfx, spell_tag="ОГОНЬ", player=game.player)
game.enemies[1].take_hit(50, 0, 0, 0, False, game.fx, game.sfx, spell_tag="КРИО", player=game.player)
game.enemies[2].take_hit(50, 0, 0, 0, False, game.fx, game.sfx, spell_tag="МОЛНИЯ", player=game.player)
game.enemies[3].take_hit(50, 0, 0, 0, False, game.fx, game.sfx, spell_tag="РАЗРУБ", player=game.player)
game.enemies[4].take_hit(50, 0, 0, 0, False, game.fx, game.sfx, spell_tag="СИНГУЛЯРНОСТЬ", player=game.player)

# Assert that only numbers ('0') are spawned, no text words!
assert len(game.fx.floating_texts) == 5, f"Expected 5 numeric popups, got {len(game.fx.floating_texts)}"
assert all(t.text == '0' for t in game.fx.floating_texts), f"Expected pure '0' damage numbers, got {[t.text for t in game.fx.floating_texts]}"
print("Verified: Only damage numbers ('0') are displayed, completely without word clutter!")

# Render a frame
game.render()

# Save preview artifact
out_dir = r"C:\Users\Parzi\.gemini\antigravity\brain\479ac71d-3313-4bcf-ac56-8d3888ba42d4"
os.makedirs(out_dir, exist_ok=True)
screenshot_path = os.path.join(out_dir, "monster_immunities_clean_preview.png")
pygame.image.save(game.screen, screenshot_path)
assert os.path.exists(screenshot_path)
print(f"Saved clean visual arena preview (without text) to:\n  {screenshot_path}")

print("\n=======================================================")
print("  ALL MONSTER IMMUNITY TESTS PASSED WITH 100% SUCCESS! ")
print("=======================================================")
