"""
test_restart_confirmation.py - Comprehensive verification of restart confirmation modal
during active gameplay, preventing accidental run loss.
"""

import os
import pygame
from game_engine import Game
import hud

def test_restart_confirmation():
    pygame.init()
    game = Game()
    game.start_run()

    print("=== TEST 1: Pressing [R] During Active Gameplay (Must NOT restart immediately) ===")
    assert game.state == 'PLAYING'
    assert game.player.alive is True
    game.score = 500
    game.player.hp = 70

    # Simulate pressing R in the middle of battle
    r_key_event = pygame.event.Event(pygame.KEYDOWN, {'key': pygame.K_r})
    pygame.event.post(r_key_event)
    game.handle_input()

    # Must NOT have restarted, modal must be active!
    assert game.restart_confirm_active is True, "Restart confirmation modal should be active!"
    assert game.player.hp == 70, "Run progress was wiped before confirmation!"
    assert game.score == 500, "Score was wiped before confirmation!"
    print("Modal successfully activated on [R], game progress protected!")

    print("\n=== TEST 2: Simulation Paused While Confirmation is Active ===")
    timer_before = game.zone_timer
    game.update(0.5)
    assert game.zone_timer == timer_before, "Zone timer decreased while confirmation modal was open!"
    print("Game simulation properly paused during confirmation prompt!")

    print("\n=== TEST 3: Canceling Restart via [N] / [ESC] ===")
    # 1. Cancel via ESC
    esc_event = pygame.event.Event(pygame.KEYDOWN, {'key': pygame.K_ESCAPE})
    pygame.event.post(esc_event)
    game.handle_input()
    assert game.restart_confirm_active is False, "Modal should close on ESC"
    assert game.state == 'PLAYING', "Game state should remain PLAYING after cancel"
    assert game.score == 500, "Progress should be intact after cancel"
    print("Cancel via [ESC] verified!")

    # 2. Cancel via N
    pygame.event.post(r_key_event)
    game.handle_input()
    assert game.restart_confirm_active is True
    n_event = pygame.event.Event(pygame.KEYDOWN, {'key': pygame.K_n})
    pygame.event.post(n_event)
    game.handle_input()
    assert game.restart_confirm_active is False, "Modal should close on [N]"
    print("Cancel via [N] verified!")

    print("\n=== TEST 4: Modal Visual Rendering and Screenshot ===")
    game.restart_confirm_active = True
    game.render()
    assert "confirm" in game.restart_confirm_rects, "Confirm button missing in restart_confirm_rects"
    assert "cancel" in game.restart_confirm_rects, "Cancel button missing in restart_confirm_rects"
    assert "modal_rect" in game.restart_confirm_rects, "Modal rect missing in restart_confirm_rects"

    out_dir = r"C:\Users\Parzi\.gemini\antigravity\brain\479ac71d-3313-4bcf-ac56-8d3888ba42d4"
    os.makedirs(out_dir, exist_ok=True)
    modal_preview_path = os.path.join(out_dir, "restart_confirmation_preview.png")
    pygame.image.save(game.screen, modal_preview_path)
    print(f"Saved Restart Confirmation Modal preview to: {modal_preview_path}")

    print("\n=== TEST 5: Canceling via Mouse Click Outside and Cancel Button ===")
    # Cancel button click
    btn_cancel = game.restart_confirm_rects["cancel"]
    c_click = pygame.event.Event(pygame.MOUSEBUTTONDOWN, {'pos': (btn_cancel.centerx, btn_cancel.centery), 'button': 1})
    pygame.event.post(c_click)
    game.handle_input()
    assert game.restart_confirm_active is False, "Modal should close on Cancel button click"
    print("Cancel via button click verified!")

    # Outside click
    game.restart_confirm_active = True
    out_click = pygame.event.Event(pygame.MOUSEBUTTONDOWN, {'pos': (50, 50), 'button': 1})
    pygame.event.post(out_click)
    game.handle_input()
    assert game.restart_confirm_active is False, "Modal should close on outside click"
    print("Cancel via outside click verified!")

    print("\n=== TEST 6: Confirming Restart via [ENTER] / [Y] ===")
    # 1. Confirm via Y
    game.restart_confirm_active = True
    y_event = pygame.event.Event(pygame.KEYDOWN, {'key': pygame.K_y})
    pygame.event.post(y_event)
    game.handle_input()
    assert game.restart_confirm_active is False, "Modal should close on confirm"
    assert game.player.hp == game.player.max_hp, "Fresh run was not started!"
    assert game.score == 0, "Score was not reset on confirmed restart!"
    print("Confirmed restart via [Y] key: SUCCESS!")

    # 2. Confirm via Button Click
    game.score = 300
    pygame.event.post(r_key_event)
    game.handle_input()
    assert game.restart_confirm_active is True
    game.render()
    btn_confirm = game.restart_confirm_rects["confirm"]
    conf_click = pygame.event.Event(pygame.MOUSEBUTTONDOWN, {'pos': (btn_confirm.centerx, btn_confirm.centery), 'button': 1})
    pygame.event.post(conf_click)
    game.handle_input()
    assert game.restart_confirm_active is False, "Modal should close on confirm click"
    assert game.score == 0, "Fresh run was not started after confirm click!"
    print("Confirmed restart via button click: SUCCESS!")

    print("\n=== TEST 7: Restart in GAME_OVER (No confirmation needed when dead) ===")
    game.player.take_damage(game.player.max_hp * 2, game.fx, game.sfx, game.art, False)
    assert game.state == 'GAME_OVER'
    # Press R
    pygame.event.post(r_key_event)
    game.handle_input()
    assert game.restart_confirm_active is False, "Should NOT show confirmation modal when already dead"
    assert game.state == 'PLAYING' and game.player.alive is True, "Immediate restart on death screen"
    print("Immediate restart in GAME_OVER verified!")

    print("\n==========================================")
    print(" RESTART CONFIRMATION TEST 100% PASSED!   ")
    print("==========================================")

if __name__ == '__main__':
    test_restart_confirmation()
