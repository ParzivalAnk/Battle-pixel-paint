"""
game_engine.py - Core Game Engine, Lifecycle, Event Dispatcher, and Loop Orchestrator.
Part of the GLYPH-BLADE modular architecture.
"""

import os
import sys
import json
import math
import random
import pygame

from config import (
    MAP_WIDTH, MAP_HEIGHT, VIEW_WIDTH, VIEW_HEIGHT, FPS,
    RESOLUTIONS, RESOLUTION_ORDER, DEFAULT_RESOLUTION,
    TEXT_WHITE, TEXT_GOLD, TEXT_RED, TEXT_CYAN, TEXT_PURPLE,
    MUTATORS, FLOOR_WAVES, GLYPH_COMPLEXITY, get_floor_data
)
from entities import Player, Enemy, PentagramCataclysm
from weapons import WEAPONS, WEAPONS_CATALOG, DroppedWeapon, roll_enemy_weapon_drop
from effects import EffectManager, render_mixed_text
from audio import SoundFX
from art import (
    ArtAssets, draw_player_character, draw_enemy_sprite,
    draw_obstacle, draw_grimoire_lectern, draw_portal,
    draw_arena_barrier, draw_city_perimeter
)
from bestiary import BESTIARY, DAMAGE_CATEGORIES
from combos import COMBO_MATRIX, ELEMENTS, GLYPH_TO_ELEMENT
from perks import generate_portal_offerings
from difficulty import DIFFICULTY_MANAGER, DIFFICULTIES, DIFFICULTY_ORDER
from challenges import CHALLENGES, CHALLENGE_ORDER, CHALLENGE_MANAGER
from achievements import ACHIEVEMENT_MANAGER, draw_achievements_screen
from menu import draw_main_menu, draw_difficulty_modal, draw_secret_code_modal, update_menu_embers
from dev_glyph_studio import DevGlyphStudio, DEV_SECRET_CODE, safe_get_clipboard_text
from tutorial import TUTORIAL_MANAGER
from recognizer import evaluate_gesture, register_custom_glyph, SKILL_INFO

import dialogue
import forge
import spellcasting
import hud
import wild_magic

# Prevent Windows DWM DPI bitmap stretching (ensures true native 1080p FHD / 1440p 2K sharpness)
if sys.platform == "win32":
    try:
        import ctypes
        ctypes.windll.shcore.SetProcessDpiAwareness(2)
    except Exception:
        try:
            import ctypes
            ctypes.windll.user32.SetProcessDPIAware()
        except Exception:
            pass

os.environ.setdefault("SDL_RENDER_SCALE_QUALITY", "best")


def is_key_pressed(event, *keys, scancodes=(), chars=()):
    """Matches keypresses across different keyboard layouts (QWERTY, JCUKEN/Russian, etc.)."""
    if event.key in keys:
        return True
    sc = getattr(event, 'scancode', None)
    if sc is not None and sc in scancodes:
        return True
    u = getattr(event, 'unicode', '').lower()
    if u and u in chars:
        return True
    name = pygame.key.name(event.key).lower()
    if name and name in chars:
        return True
    return False


class Game:
    def __init__(self):
        pygame.init()
        pygame.display.set_caption("GLYPH-BLADE: Giant Colossi & Compound Fusions")
        self.settings = self.load_settings()
        self.is_fullscreen = self.settings.get("fullscreen", False)
        saved_res = self.settings.get("resolution", DEFAULT_RESOLUTION)
        self.resolution_key = saved_res if saved_res in RESOLUTIONS else DEFAULT_RESOLUTION
        self.apply_display_mode()

        self.clock = pygame.time.Clock()

        self.art = ArtAssets(MAP_WIDTH, MAP_HEIGHT)
        self.fx = EffectManager()
        self.sfx = SoundFX()

        # States: 'MAIN_MENU', 'DIFFICULTY_SELECT', 'ACHIEVEMENTS_MENU', 'PLAYING', 'PAUSED', 'PERK_SELECTION', 'DOJO', 'TOME_OF_SYNTHESIS', 'BOSS_DIALOGUE', 'CUSTOM_GLYPH_FORGE', 'COMBO_FORGE_MENU', 'GAME_OVER'
        self.state = 'MAIN_MENU'
        self.achievements_page = 0
        self.menu_buttons = {}
        self.pause_rects = {}
        self.death_rects = {}
        self.restart_confirm_active = False
        self.restart_confirm_rects = {}
        self.speedrun_active = False
        self.speedrun_time = 0.0
        self.speedrun_splits = {}
        self.speedrun_best_time = self.load_speedrun_record()
        self.speedrun_confirm_active = False
        self.speedrun_confirm_rects = {}
        self.visited_city_districts = set()
        self.diff_modal_rects = {}
        self.ach_menu_rects = {}
        self.dialogue_rects = {}
        self.dialogue_stage = 'QUESTION'
        self.dialogue_choice = None
        self.dialogue_boss_name = "ВЕРХОВНЫЙ СУДИЯ ИСТИНЫ [БОСС 50 ЭТАЖА]"
        self.dialogue_boss_title = "Хранитель 50-го Эшелона • Владыка Весов Судеб"
        self.dialogue_question_lines = []
        self.dialogue_result_title = ""
        self.dialogue_result_lines = []
        self.dialogue_result_color = TEXT_GOLD
        self.dialogue_damage_reported = 0
        self.current_floor_idx = 0
        self.current_wave_idx = 0

        # Player & Entities
        self.player = Player(MAP_WIDTH // 2, MAP_HEIGHT // 2)
        self.player.game = self
        self.tutorial_manager = TUTORIAL_MANAGER
        self.dojo_source = 'MAIN_MENU'
        self.enemies = []
        self.active_abilities = []
        self.obstacles = []
        self.dropped_weapons = []
        self.lectern_pos = (MAP_WIDTH // 2 - 120, MAP_HEIGHT // 2)

        # Compound gesture memory for fusion!
        self.last_gesture_id = None
        self.last_gesture_time = 0.0

        # Bullet-Time Slo-Mo
        self.bullet_time_timer = 0.0

        # Camera
        self.cam_x = 0.0
        self.cam_y = 0.0

        # Run State
        diff = DIFFICULTY_MANAGER.current
        self.zone_timer = diff.floor_timer
        self.score = 0
        self.anim_time = 0.0
        self.is_drawing = False
        self.stroke_points = []
        self.last_accuracy_info = None
        self.highest_floor_cleared = 0

        # Multi-glyph combo chain in combat
        self.combo_gesture_chain = []

        # Combo Forge Menu State
        self.forge_slots = []
        self.forge_points = []
        self.forge_feedback = "Черти знаки по очереди в алтаре (минимум 3 знака)!"
        self.sealed_ultra_combo = None

        # Level exit portal
        self.portal_pos = (MAP_WIDTH // 2, MAP_HEIGHT // 2)
        self.portal_active = False
        self.portal_ritual_active = False
        self.portal_ritual_timer = 0.0
        self.is_tenth_floor_portal = False
        self.current_portal_offerings = generate_portal_offerings(1, curse_chance=diff.curse_chance)

        # Custom Glyph Studio
        self.custom_points = []
        self.custom_glyph_recorded = False
        self.custom_glyph_feedback = "Зажми ЛКМ/ПКМ и нарисуй свой символ в золотом квадрате!"

        # Drawing Cooldown System (перезарядка на рисовку)
        self.draw_cooldown = 0.0
        self.max_draw_cooldown = 0.85

        # Wild Magic & Buffer State
        self.wild_magic_mode = True
        self.wild_magic_queue = []
        self.wild_magic_state = None
        self.wild_magic_pattern = None
        self.wild_magic_timer = 0.0
        self.wild_magic_drawn_points = []
        self.is_drawing_wild_magic = False
        self.wild_magic_live_score = 0.0
        self.wild_magic_rects = {}
        self.unlocked_wild_magic_glyphs = {
            "CRESCENT_BLADE", "TRIANGLE_APEX", "DIAMOND_SEAL", "HEXAGRAM_SEAL",
            "AETHER_LEMNISCATE", "CROWN_SERAPHIM", "OCULUS_VOID", "HEPTAGRAM_CHAOS",
            "COSMIC_PENTACLE_SUPREME"
        }

        # 5-Glyph Boss Finisher Anime Cutscene State
        self.cutscene_timer = 0.0
        self.cutscene_duration = 4.6
        self.cutscene_boss = None
        self.cutscene_dmg = 0.0
        self.cutscene_pattern = None
        self.cutscene_runes = []
        self.cutscene_hit_count = 0
        self.cutscene_acc_pct = 100
        self.cutscene_tier_title = ""
        self.cutscene_tier_color = TEXT_GOLD
        self.cutscene_boss_dead = False
        self.cutscene_sounds = [False] * 12
        self.dojo_source = None

        # Text Fonts (Arial renders Russian Cyrillic flawlessly on Windows)
        self.font_title = pygame.font.SysFont("arial", 32, bold=True)
        self.font_large = pygame.font.SysFont("arial", 22, bold=True)
        self.font_med = pygame.font.SysFont("arial", 16, bold=True)
        self.font_small = pygame.font.SysFont("arial", 13)

        # Symbol Fonts (Segoe UI Symbol renders Unicode glyphs ★ ❄ ⌛ 🛡 ⚛ ❂ flawlessly)
        self.font_sym_large = pygame.font.SysFont("segoe ui symbol", 26, bold=True)
        self.font_sym_med = pygame.font.SysFont("segoe ui symbol", 18, bold=True)
        self.font_sym_small = pygame.font.SysFont("segoe ui symbol", 14)

        # Developer Mode & Secret Code Access
        self.dev_mode_unlocked = False
        self.secret_code_modal_active = False
        self.secret_code_input = ""
        self.secret_code_feedback = ""
        self.secret_code_feedback_color = TEXT_GOLD
        self.secret_code_timer = 0.0
        self.secret_code_rects = {}
        self.dev_studio = DevGlyphStudio(self)

        self.running = True
        self._generate_map_obstacles()
        self.load_floor(0)

    def submit_secret_code(self):
        """Validates developer secret passcode for unlocking Dev Glyph Studio."""
        code = self.secret_code_input.strip()
        if code == DEV_SECRET_CODE:
            self.dev_mode_unlocked = True
            self.secret_code_modal_active = False
            self.secret_code_feedback = "★ ДОСТУП РАЗРЕШЁН! РЕЖИМ РАЗРАБОТЧИКА АКТИВИРОВАН! ★"
            self.secret_code_feedback_color = TEXT_GOLD
            self.sfx.play("crit")
            self.fx.add_screen_shake(12.0)
            self.state = 'DEV_GLYPH_STUDIO'
        else:
            self.sfx.play("dash")
            self.fx.add_screen_shake(10.0)
            self.secret_code_feedback = "ОШИБКА: НЕВЕРНЫЙ КОД ДОСТУПА!"
            self.secret_code_feedback_color = TEXT_RED

    def load_settings(self):
        """Loads persistent user settings (fullscreen, etc.)."""
        settings_file = "settings.json"
        if os.path.exists(settings_file):
            try:
                with open(settings_file, "r", encoding="utf-8") as f:
                    return json.load(f)
            except Exception:
                pass
        return {}

    def save_settings(self):
        """Saves persistent user settings (fullscreen, resolution, etc.)."""
        settings_file = "settings.json"
        try:
            data = self.load_settings()
            data["fullscreen"] = bool(getattr(self, 'is_fullscreen', False))
            data["resolution"] = getattr(self, 'resolution_key', DEFAULT_RESOLUTION)
            with open(settings_file, "w", encoding="utf-8") as f:
                json.dump(data, f, indent=2)
        except Exception:
            pass

    def load_speedrun_record(self):
        """Loads personal best speedrun completion time."""
        settings = self.load_settings()
        return settings.get("speedrun_best_time", None)

    def save_speedrun_record(self, record_time):
        """Saves new speedrun record if improved."""
        settings = self.load_settings()
        cur_best = settings.get("speedrun_best_time", None)
        if cur_best is None or record_time < cur_best:
            settings["speedrun_best_time"] = float(record_time)
            self.speedrun_best_time = float(record_time)
            try:
                with open("settings.json", "w", encoding="utf-8") as f:
                    json.dump(settings, f, indent=2)
            except Exception:
                pass

    def start_speedrun(self):
        """Initiates a fresh speedrun run with live millisecond chronometer and split tracking."""
        self.speedrun_active = True
        self.speedrun_time = 0.0
        self.speedrun_splits.clear()
        self.speedrun_confirm_active = False
        self.visited_city_districts.clear()
        self.reset_run()
        self.sfx.play("crit")
        self.fx.add_screen_shake(15.0)
        self.fx.add_floating_text("⚡ СПИДРАН АКТИВИРОВАН! ⚡", self.player.x, self.player.y - 75, (255, 215, 60), size=28)

    def get_target_resolution(self):
        """Returns the (width, height) tuple for the active resolution preset (FHD / 2K / HD)."""
        res_key = getattr(self, 'resolution_key', DEFAULT_RESOLUTION)
        return RESOLUTIONS.get(res_key, (VIEW_WIDTH, VIEW_HEIGHT))

    def apply_display_mode(self):
        """Applies the current resolution preset (FHD 1080p / 2K 1440p / HD 720p) and Fullscreen/Windowed mode."""
        target_w, target_h = self.get_target_resolution()
        is_dummy = (os.environ.get("SDL_VIDEODRIVER") == "dummy")

        desktop_w, desktop_h = target_w, target_h
        if not is_dummy:
            try:
                sizes = pygame.display.get_desktop_sizes()
                if sizes:
                    desktop_w, desktop_h = sizes[0]
            except Exception:
                pass

        applied = False
        if self.is_fullscreen:
            if not is_dummy and (target_w != desktop_w or target_h != desktop_h):
                try:
                    self.screen = pygame.display.set_mode(
                        (target_w, target_h),
                        pygame.FULLSCREEN | pygame.SCALED
                    )
                    applied = True
                except Exception:
                    pass
            if not applied:
                try:
                    self.screen = pygame.display.set_mode(
                        (target_w, target_h),
                        pygame.DOUBLEBUF | pygame.FULLSCREEN
                    )
                    applied = True
                except Exception:
                    self.is_fullscreen = False

        if not applied:
            if not is_dummy and (target_w > desktop_w or target_h > desktop_h):
                try:
                    self.screen = pygame.display.set_mode(
                        (target_w, target_h),
                        pygame.SCALED | pygame.RESIZABLE
                    )
                    applied = True
                except Exception:
                    pass
            if not applied:
                try:
                    self.screen = pygame.display.set_mode((target_w, target_h), pygame.DOUBLEBUF)
                except Exception:
                    self.screen = pygame.display.set_mode((target_w, target_h))

        if hasattr(self, 'player') and hasattr(self, 'screen'):
            sw, sh = self.screen.get_size()
            if sw >= MAP_WIDTH:
                self.cam_x = -(sw - MAP_WIDTH) // 2
            else:
                self.cam_x = max(0, min(MAP_WIDTH - sw, self.player.x - sw // 2))
            if sh >= MAP_HEIGHT:
                self.cam_y = -(sh - MAP_HEIGHT) // 2
            else:
                self.cam_y = max(0, min(MAP_HEIGHT - sh, self.player.y - sh // 2))

    def cycle_resolution(self):
        """Cycles display quality preset between FHD (1920x1080), 2K (2560x1440), and HD (1280x720)."""
        cur = getattr(self, 'resolution_key', DEFAULT_RESOLUTION)
        if cur in RESOLUTION_ORDER:
            idx = (RESOLUTION_ORDER.index(cur) + 1) % len(RESOLUTION_ORDER)
            self.resolution_key = RESOLUTION_ORDER[idx]
        else:
            self.resolution_key = DEFAULT_RESOLUTION

        self.apply_display_mode()
        self.save_settings()
        rw, rh = self.get_target_resolution()
        if hasattr(self, 'fx'):
            self.fx.add_floating_text(
                f"КАЧЕСТВО ЭКРАНА: {self.resolution_key} ({rw}x{rh})",
                self.player.x, self.player.y - 70, TEXT_CYAN, size=26
            )
        if hasattr(self, 'sfx'):
            self.sfx.play("parry")

    def toggle_fullscreen(self):
        """Toggles between Windowed and Fullscreen display modes at the active resolution (FHD/2K/HD)."""
        self.is_fullscreen = not getattr(self, 'is_fullscreen', False)
        self.apply_display_mode()
        self.save_settings()
        rw, rh = self.get_target_resolution()
        status_text = (
            f"ПОЛНОЭКРАННЫЙ РЕЖИМ [{self.resolution_key} {rw}x{rh}]"
            if self.is_fullscreen
            else f"ОКОННЫЙ РЕЖИМ [{self.resolution_key} {rw}x{rh}]"
        )
        if hasattr(self, 'fx'):
            self.fx.add_floating_text(status_text, self.player.x, self.player.y - 70, TEXT_GOLD, size=26)
        if hasattr(self, 'sfx'):
            self.sfx.play("parry")

    # -------------------------------------------------------------------------
    # SUB-SYSTEM DELEGATION METHODS (BACKWARDS COMPATIBILITY & CLEAN ACCESS)
    # -------------------------------------------------------------------------
    def cast_gesture_ability(self, raw_points):
        return spellcasting.cast_gesture_ability(self, raw_points)

    def draw_hud(self, surface=None):
        return hud.draw_hud(self, surface)

    def get_boss_info_text(self):
        return hud.get_boss_info_text(self)

    def open_boss_dialogue(self):
        return dialogue.open_boss_dialogue(self)

    def handle_boss_dialogue_choice(self, choice_idx):
        return dialogue.handle_boss_dialogue_choice(self, choice_idx)

    def close_boss_dialogue(self):
        return dialogue.close_boss_dialogue(self)

    def draw_boss_dialogue(self, surface, anim_time, fonts):
        return dialogue.draw_boss_dialogue(self, surface, anim_time, fonts)

    def get_combo_forge_rects(self):
        return forge.get_combo_forge_rects(self)

    def get_slot_element_info(self, item_key):
        return forge.get_slot_element_info(item_key)

    def _draw_combo_forge_menu(self):
        return forge.draw_combo_forge_menu(self)

    def get_wild_magic_pattern_for_queue(self):
        return wild_magic.get_wild_magic_pattern_for_queue(self)

    def trigger_wild_magic_start(self):
        return wild_magic.trigger_wild_magic_start(self)

    def start_wild_magic_ritual(self):
        return wild_magic.start_wild_magic_ritual(self)

    def evaluate_wild_magic_drawing(self):
        return wild_magic.evaluate_wild_magic_drawing(self)

    def draw_wild_magic_ritual(self, surface):
        return wild_magic.draw_wild_magic_ritual(self, surface)

    def start_5_glyph_boss_cutscene(self, boss, total_dmg, pattern, queue_runes, hit_count, acc_pct, tier_title, tier_color):
        """Initiates the dramatic frame-by-frame anime boss finisher cutscene for 5-glyph combos."""
        self.dojo_source = 'DOJO' if self.state == 'DOJO' else 'PLAYING'
        self.state = 'CUTSCENE_5_GLYPH'
        self.cutscene_timer = 0.0
        self.cutscene_duration = 4.6
        self.cutscene_boss = boss
        self.cutscene_dmg = total_dmg
        self.cutscene_pattern = pattern
        self.cutscene_runes = list(queue_runes)
        self.cutscene_hit_count = hit_count
        self.cutscene_acc_pct = acc_pct
        self.cutscene_tier_title = tier_title
        self.cutscene_tier_color = tier_color
        self.cutscene_boss_dead = (boss.hp <= total_dmg)
        self.cutscene_sounds = [False] * 12
        self.wild_magic_queue.clear()
        self.wild_magic_state = None
        self.wild_magic_drawn_points = []
        self.draw_cooldown = 0.60
        self.bullet_time_timer = 0.0
        self.fx.add_screen_shake(20.0)
        self.sfx.play("crit")

    def end_5_glyph_cutscene(self):
        """Finalizes the 5-glyph boss finisher cutscene and deals the catastrophic damage."""
        if self.state != 'CUTSCENE_5_GLYPH':
            return

        boss = getattr(self, 'cutscene_boss', None)
        total_dmg = getattr(self, 'cutscene_dmg', 600.0)
        hit_count = 0

        for en in self.enemies:
            if en.alive:
                hit_count += 1
                en.is_frozen = True
                en.stun_timer = max(en.stun_timer, 4.5)
                en.take_hit(total_dmg, 0, 0, 0.4, True, self.fx, self.sfx, spell_tag="КАТАКЛИЗМ 5 СТИХИЙ", player=self.player)
                self.art.add_blood_splatter(en.x, en.y, count=10)

        self.player.i_frame_timer = 5.0
        self.fx.add_screen_shake(35.0)
        self.sfx.play("crit")

        if boss:
            self.fx.add_floating_text(f"★★★ ФИНИШЕР 5 СТИХИЙ: -{int(total_dmg)} УРОНА ПО БОССУ! ★★★", boss.x, boss.y - 85, TEXT_GOLD, size=28)

        ACHIEVEMENT_MANAGER.unlock("wild_magic_unleashed", self.fx, self.sfx)
        self.state = 'DOJO' if getattr(self, 'dojo_source', None) == 'DOJO' and hasattr(self, 'tutorial_manager') else 'PLAYING'
        self.draw_cooldown = 0.55

    def draw_5_glyph_cutscene(self, surface, dt):
        """Renders the dramatic 5-glyph boss finisher frame-by-frame cutscene."""
        self.cutscene_timer += dt
        t = self.cutscene_timer
        boss = getattr(self, 'cutscene_boss', None)
        if not boss:
            self.end_5_glyph_cutscene()
            return

        sw, sh = surface.get_width(), surface.get_height()

        # Smooth camera lerp centering on boss & player
        target_cx = (boss.x + self.player.x) / 2.0 - sw // 2
        target_cy = (boss.y + self.player.y) / 2.0 - sh // 2
        self.cam_x += (target_cx - self.cam_x) * 0.18
        self.cam_y += (target_cy - self.cam_y) * 0.18

        shake_x, shake_y = self.fx.get_shake_offset()
        off_x = -self.cam_x + shake_x
        off_y = -self.cam_y + shake_y

        # 1. Render World & Entities
        if self.art.tile_floor:
            tw, th = self.art.tile_floor.get_size()
            start_x = int((self.cam_x // tw) * tw)
            start_y = int((self.cam_y // th) * th)
            for tx in range(start_x, int(self.cam_x + sw + tw), tw):
                for ty in range(start_y, int(self.cam_y + sh + th), th):
                    surface.blit(self.art.tile_floor, (tx + off_x, ty + off_y))
        else:
            surface.fill((14, 18, 26))

        for ob in self.obstacles:
            draw_obstacle(surface, ob, off_x, off_y, art=self.art, anim_time=self.anim_time)

        # Living minions in background
        for en in self.enemies:
            if en.alive and en != boss:
                ang_p = math.atan2(self.player.y - en.y, self.player.x - en.x)
                draw_enemy_sprite(surface, self.art, en, int(en.x + off_x), int(en.y + off_y), self.anim_time, ang_p)

        # Boss Screen Position
        bx = int(boss.x + off_x)
        by = int(boss.y + off_y)

        # Draw Boss with pulsating aura
        boss_ang = math.atan2(self.player.y - boss.y, self.player.x - boss.x)
        draw_enemy_sprite(surface, self.art, boss, bx, by, self.anim_time, boss_ang)
        boss_aura = pygame.Surface((120, 120), pygame.SRCALPHA)
        pulse = (math.sin(t * 12.0) + 1.0) * 0.5
        pygame.draw.circle(boss_aura, (255, 60, 60, int(70 + 80 * pulse)), (60, 60), 55, 3)
        surface.blit(boss_aura, (bx - 60, by - 60))

        # Draw Player
        px = int(self.player.x + off_x)
        py = int(self.player.y + off_y)
        draw_player_character(
            surface, self.art, px, py,
            self.player.aim_angle, self.anim_time,
            self.player.weapon.color, self.player.fumble_timer > 0, True,
            weapon_tier=self.player.weapon.tier,
            is_moving=False,
            is_casting=True,
            cast_timer=0.4,
            walk_time=0.0
        )

        # 2. Cinematic Dimming Vignette
        vignette = pygame.Surface((sw, sh), pygame.SRCALPHA)
        vignette.fill((8, 12, 22, 165))
        surface.blit(vignette, (0, 0))

        # 3. Cinematic Letterbox Bars (16:9 Widescreen)
        bar_h = min(74, int(74 * min(1.0, t / 0.4)))
        pygame.draw.rect(surface, (0, 0, 0), (0, 0, sw, bar_h))
        pygame.draw.rect(surface, (0, 0, 0), (0, sh - bar_h, sw, bar_h))
        pygame.draw.line(surface, TEXT_GOLD, (0, bar_h), (sw, bar_h), 2)
        pygame.draw.line(surface, TEXT_GOLD, (0, sh - bar_h), (sw, sh - bar_h), 2)

        # Header Title Card
        t_card = render_mixed_text("✦ ВЕЛИКИЙ КАТАКЛИЗМ ПЯТИ СТИХИЙ ✦", self.font_title, self.font_sym_large, TEXT_GOLD)
        surface.blit(t_card, (sw // 2 - t_card.get_width() // 2, 20))
        sub_card = self.font_small.render("PENTAGRAM OVERDRIVE • CINEMATIC BOSS FINISHER", True, (190, 215, 245))
        surface.blit(sub_card, (sw // 2 - sub_card.get_width() // 2, 54))

        # 4. Sequential 5-Rune Slam (t: 0.7s - 2.4s)
        radius = 110.0
        slam_coords = []
        for idx in range(5):
            ang = -math.pi / 2.0 + idx * (2.0 * math.pi / 5.0)
            rx = bx + int(radius * math.cos(ang))
            ry = by + int(radius * math.sin(ang))
            slam_coords.append((rx, ry))

        for idx in range(5):
            rx, ry = slam_coords[idx]
            slam_t = 0.7 + idx * 0.32
            if t >= slam_t:
                # Trigger sound & sparks once per rune slam
                if not self.cutscene_sounds[idx]:
                    self.cutscene_sounds[idx] = True
                    self.sfx.play("crit" if idx == 4 else "parry")
                    self.fx.add_screen_shake(12.0 + idx * 2.0)
                    self.fx.spawn_sparks(boss.x, boss.y, (255, 220, 90), count=25, speed=260)

                rid = self.cutscene_runes[idx] if idx < len(self.cutscene_runes) else "STAR_PENTAGRAM"
                sinfo = SKILL_INFO.get(rid, {})
                r_col = sinfo.get("color", (120, 230, 255))
                r_sym = sinfo.get("symbol", "★")

                # Rune Pentagram Connection Lines
                if idx > 0:
                    pygame.draw.line(surface, r_col, slam_coords[idx - 1], (rx, ry), 2)
                elif t >= 0.7 + 4 * 0.32:
                    pygame.draw.line(surface, r_col, slam_coords[4], (rx, ry), 2)

                # Rune orb stamp
                pygame.draw.circle(surface, (20, 24, 38), (rx, ry), 18)
                pygame.draw.circle(surface, r_col, (rx, ry), 18, 2)
                sym_surf = self.font_sym_small.render(r_sym, True, r_col)
                surface.blit(sym_surf, (rx - sym_surf.get_width() // 2, ry - sym_surf.get_height() // 2))

                # Expanding shockwave on fresh slam
                age_slam = t - slam_t
                if age_slam < 0.25:
                    sw_r = int(age_slam * 220)
                    pygame.draw.circle(surface, r_col, (rx, ry), sw_r, 2)

        # 5. Dimensional Slashes (t: 2.3s - 3.4s)
        if t >= 2.3:
            slash_count = min(6, int((t - 2.3) / 0.16))
            for s_i in range(slash_count):
                if s_i + 5 < len(self.cutscene_sounds) and not self.cutscene_sounds[s_i + 5]:
                    self.cutscene_sounds[s_i + 5] = True
                    self.sfx.play("slash")
                    self.fx.add_screen_shake(14.0)

                s_angle = s_i * (math.pi / 3.0) + 0.3
                sl_len = 140.0
                p_a = (bx + int(sl_len * math.cos(s_angle)), by + int(sl_len * math.sin(s_angle)))
                p_b = (bx - int(sl_len * math.cos(s_angle)), by - int(sl_len * math.sin(s_angle)))
                pygame.draw.line(surface, (255, 255, 255), p_a, p_b, 4)
                pygame.draw.line(surface, (255, 60, 60), p_a, p_b, 1)

        # 6. Blinding Supernova Explosion (t: 3.3s - 4.6s)
        if t >= 3.3:
            if not self.cutscene_sounds[11]:
                self.cutscene_sounds[11] = True
                self.sfx.play("crit")
                self.fx.add_screen_shake(45.0)
                self.fx.spawn_sparks(boss.x, boss.y, (255, 240, 160), count=90, speed=480)

            flash_age = t - 3.3
            flash_alpha = max(0, int(255 * (1.0 - flash_age / 0.85)))
            if flash_alpha > 0:
                flash_surf = pygame.Surface((sw, sh))
                flash_surf.fill((255, 255, 255))
                flash_surf.set_alpha(flash_alpha)
                surface.blit(flash_surf, (0, 0))

            # Expanding Supernova Shockwave Rings
            sn_r = int(flash_age * 400)
            if sn_r > 0:
                pygame.draw.circle(surface, (255, 230, 100), (bx, by), sn_r, 4)
                if sn_r > 15:
                    pygame.draw.circle(surface, TEXT_GOLD, (bx, by), sn_r - 12, 3)

            # Dramatic Typography
            if self.cutscene_boss_dead:
                b_title = render_mixed_text("★★★ ВЕЛИКИЙ БОСС УНИЧТОЖЕН! ★★★", self.font_title, self.font_sym_large, TEXT_GOLD)
                surface.blit(b_title, (sw // 2 - b_title.get_width() // 2, sh // 2 - 35))
                b_sub = self.font_large.render(f"ФИНИШЕР 5 СТИХИЙ • УРОН: -{int(self.cutscene_dmg)} HP!", True, (255, 255, 255))
                surface.blit(b_sub, (sw // 2 - b_sub.get_width() // 2, sh // 2 + 10))
            else:
                b_title = render_mixed_text(f"★★★ КАТАКЛИЗМ 5 СТИХИЙ: -{int(self.cutscene_dmg)} HP! ★★★", self.font_title, self.font_sym_large, (255, 90, 80))
                surface.blit(b_title, (sw // 2 - b_title.get_width() // 2, sh // 2 - 35))
                b_sub = self.font_large.render("БОСС ОШЕЛЕМЛЕН И ПОВЕРЖЕН В СТАЗИС!", True, TEXT_GOLD)
                surface.blit(b_sub, (sw // 2 - b_sub.get_width() // 2, sh // 2 + 10))

        # Bottom Skip Hint
        skip_hint = self.font_small.render("[ПРОБЕЛ / ESC] Пропустить", True, (160, 185, 215))
        surface.blit(skip_hint, (sw // 2 - skip_hint.get_width() // 2, sh - 32))

        # Cutscene duration finished
        if t >= self.cutscene_duration:
            self.end_5_glyph_cutscene()

    # -------------------------------------------------------------------------
    # MAP & FLOOR MANAGEMENT
    # -------------------------------------------------------------------------
    def _generate_map_obstacles(self):
        """Generates gothic shrines, corner blood fountains, bottom-entrance alchemy table, sarcophagi, braziers, and barricades."""
        self.obstacles.clear()

        # 1. North Gothic Runic Shrine (Towering Obelisk with glowing runes at North Entrance)
        self.obstacles.append({'x': MAP_WIDTH // 2, 'y': 345, 'radius': 36, 'type': 'SHRINE'})

        # 2. Compact Alchemical Arcane Workbench at the Bottom (South) Entrance
        self.obstacles.append({'x': MAP_WIDTH // 2, 'y': MAP_HEIGHT - 275, 'radius': 26, 'type': 'ALCHEMY_TABLE'})

        # 3. Four Gargoyle Blood Fountains at the Four Corners of the Arena
        corner_fountains = [
            (280, 260),
            (MAP_WIDTH - 280, 260),
            (280, MAP_HEIGHT - 260),
            (MAP_WIDTH - 280, MAP_HEIGHT - 260),
        ]
        for fx, fy in corner_fountains:
            self.obstacles.append({'x': fx, 'y': fy, 'radius': 46, 'type': 'FOUNTAIN'})

        # 4. Ancient Knight Crypt Sarcophagi (Chained tombs framing the ceremonial hall)
        sarcophagi = [
            (680, 390),
            (MAP_WIDTH - 680, 390),
            (680, MAP_HEIGHT - 390),
            (MAP_WIDTH - 680, MAP_HEIGHT - 390),
        ]
        for sx, sy in sarcophagi:
            self.obstacles.append({'x': sx, 'y': sy, 'radius': 42, 'type': 'SARCOPHAGUS'})

        # 5. Gothic Standing Torch Braziers (Architecturally aligned & framing shrines/sanctums/fountains)
        braziers = [
            # Central Ceremonial Sanctum (Framing Lectern at x=980 and Portal at x=1100)
            (980, 670),
            (980, 930),
            (1220, 670),
            (1220, 930),

            # North Gothic Runic Shrine (Flanking the grand obelisk altarpiece)
            (MAP_WIDTH // 2 - 85, 345),
            (MAP_WIDTH // 2 + 85, 345),

            # South Entrance Alchemical Workbench (Flanking the compact alchemy table)
            (MAP_WIDTH // 2 - 75, MAP_HEIGHT - 275),
            (MAP_WIDTH // 2 + 75, MAP_HEIGHT - 275),

            # West & East Gate Avenues (Torchlight welcoming the side entrances)
            (240, MAP_HEIGHT // 2 - 85),
            (240, MAP_HEIGHT // 2 + 85),
            (MAP_WIDTH - 240, MAP_HEIGHT // 2 - 85),
            (MAP_WIDTH - 240, MAP_HEIGHT // 2 + 85),

            # Four Corner Gargoyle Blood Fountains (Flanking left & right of each corner basin)
            (200, 260), (360, 260),
            (MAP_WIDTH - 360, 260), (MAP_WIDTH - 200, 260),
            (200, MAP_HEIGHT - 260), (360, MAP_HEIGHT - 260),
            (MAP_WIDTH - 360, MAP_HEIGHT - 260), (MAP_WIDTH - 200, MAP_HEIGHT - 260),

            # Ancient Crypt Sarcophagi (Vigil flames for the 4 warrior tombs)
            (680 - 75, 390),
            (MAP_WIDTH - 680 + 75, 390),
            (680 - 75, MAP_HEIGHT - 390),
            (MAP_WIDTH - 680 + 75, MAP_HEIGHT - 390),
        ]
        for bx, by in braziers:
            self.obstacles.append({'x': bx, 'y': by, 'radius': 16, 'type': 'BRAZIER'})

        # 6. City Gates Barricades (Stacked wooden benches blocking the 4 city exits)
        self.obstacles.append({'x': MAP_WIDTH // 2, 'y': 120, 'radius': 52, 'type': 'BENCH_BARRICADE', 'district': 'NORTH'})
        self.obstacles.append({'x': MAP_WIDTH // 2, 'y': MAP_HEIGHT - 120, 'radius': 52, 'type': 'BENCH_BARRICADE', 'district': 'SOUTH'})
        self.obstacles.append({'x': 120, 'y': MAP_HEIGHT // 2, 'radius': 52, 'type': 'BENCH_BARRICADE', 'district': 'WEST'})
        self.obstacles.append({'x': MAP_WIDTH - 120, 'y': MAP_HEIGHT // 2, 'radius': 52, 'type': 'BENCH_BARRICADE', 'district': 'EAST'})

        # 7. Standalone wooden street benches along sidewalks and outer walls (oriented per side)
        street_benches = [
            (MAP_WIDTH // 2 - 220, 105, 'NORTH'), (MAP_WIDTH // 2 + 220, 105, 'NORTH'),
            (MAP_WIDTH // 2 - 220, MAP_HEIGHT - 105, 'SOUTH'), (MAP_WIDTH // 2 + 220, MAP_HEIGHT - 105, 'SOUTH'),
            (105, MAP_HEIGHT // 2 - 200, 'WEST'), (105, MAP_HEIGHT // 2 + 200, 'WEST'),
            (MAP_WIDTH - 105, MAP_HEIGHT // 2 - 200, 'EAST'), (MAP_WIDTH - 105, MAP_HEIGHT // 2 + 200, 'EAST'),
        ]
        for bx, by, b_dist in street_benches:
            self.obstacles.append({'x': bx, 'y': by, 'radius': 24, 'type': 'BENCH', 'district': b_dist})

    @property
    def current_floor_data(self):
        return get_floor_data(self.current_floor_idx)

    @property
    def current_mutator(self):
        m_idx = self.current_floor_data.get("mutator_idx", 0)
        return MUTATORS[m_idx % len(MUTATORS)]

    def check_wild_magic_boss_unlocks(self, floor_idx=None):
        """Checks and unlocks higher-tier boss sacred Wild Magic glyphs."""
        if floor_idx is None:
            floor_idx = self.highest_floor_cleared

        boss_unlock_map = [
            (1, "CHRONO_HOURGLASS_KNOT", "Хроно-Разлом: Временной Узел", "chrono_wild_magic"),
            (2, "VALKIRIA_BLADE_CREST", "Герб Владычицы Клинков: Танец Стали", None),
            (3, "NECRO_SPIRE_SIGIL", "Печать Архилича: Око Скверны", None),
            (4, "JUDGEMENT_SCALES", "Весы Истины: Абсолютный Вердикт", None),
        ]

        for req_floor, glyph_id, glyph_name, ach_id in boss_unlock_map:
            is_eligible = (floor_idx >= req_floor) or (req_floor == 4 and floor_idx >= 49)
            if is_eligible and glyph_id not in self.unlocked_wild_magic_glyphs:
                self.unlocked_wild_magic_glyphs.add(glyph_id)
                pat = wild_magic.WILD_MAGIC_PATTERNS.get(glyph_id, {})
                col = pat.get("color", TEXT_GOLD)
                sym = pat.get("symbol", "★")
                self.fx.add_screen_shake(16.0)
                self.sfx.play("crit")
                self.fx.add_floating_text(
                    f"★ РАЗБЛОКИРОВАН ВЫСШИЙ ЗНАК: {glyph_name} [{sym}]! ★",
                    self.player.x, self.player.y - 80, col, size=26
                )
                if ach_id:
                    ACHIEVEMENT_MANAGER.unlock(ach_id, self.fx, self.sfx)

    def load_floor(self, floor_idx):
        self.current_floor_idx = floor_idx
        self.highest_floor_cleared = max(self.highest_floor_cleared, floor_idx)
        self.check_wild_magic_boss_unlocks(floor_idx)

        # Speedrun Split Tracking
        if getattr(self, 'speedrun_active', False):
            self.speedrun_splits[floor_idx] = self.speedrun_time
            if floor_idx > 0:
                s_m = int(self.speedrun_time // 60)
                s_s = int(self.speedrun_time % 60)
                s_ms = int((self.speedrun_time * 1000) % 1000)
                self.fx.add_floating_text(
                    f"⚡ СПЛИТ ЭТАЖА {floor_idx}: {s_m:02d}:{s_s:02d}.{s_ms:03d}",
                    self.player.x, self.player.y - 70, (255, 220, 80), size=24
                )

        self.current_wave_idx = 0
        diff = DIFFICULTY_MANAGER.current
        self.zone_timer = diff.floor_timer + getattr(self.player, 'bonus_time_per_floor', 0.0)
        self.portal_active = False
        self.portal_ritual_active = False
        self.portal_ritual_timer = 0.0
        self.is_tenth_floor_portal = ((floor_idx + 1) % 10 == 0)
        self.active_abilities.clear()
        self.dropped_weapons.clear()
        self._generate_map_obstacles()

        # Floor 50 Boss Dialogue Trigger!
        if floor_idx == 49:
            self.enemies.clear()
            boss = Enemy(MAP_WIDTH // 2, MAP_HEIGHT // 2 - 140, "judge_of_truth", hp_scale=1.0)
            self.enemies.append(boss)
            self.open_boss_dialogue()
            self.sfx.play("parry")
            return

        self.spawn_wave(0)

    def spawn_wave(self, wave_idx=0):
        f_data = self.current_floor_data
        if wave_idx >= len(f_data["waves"]):
            return
        self.current_wave_idx = wave_idx
        self.player.damage_taken_in_wave = False
        wave_enemies = f_data["waves"][wave_idx]
        self.enemies.clear()

        # Scale HP based on floor index
        hp_scale = 1.0 + (self.current_floor_idx * 0.12)
        pad = 200

        for e_id in wave_enemies:
            # Spawn at arena perimeter
            ang = random.uniform(0, 2 * math.pi)
            dist = random.uniform(400, 750)
            ex = self.player.x + dist * math.cos(ang)
            ey = self.player.y + dist * math.sin(ang)
            ex = max(pad, min(MAP_WIDTH - pad, ex))
            ey = max(pad, min(MAP_HEIGHT - pad, ey))
            self.enemies.append(Enemy(ex, ey, e_id, hp_scale))

    def enter_dojo(self):
        self.state = 'DOJO'
        self.enemies.clear()
        self.active_abilities.clear()
        self.dropped_weapons.clear()
        self._generate_map_obstacles()

        # Spawn 3 Training Dummies
        d1 = Enemy(MAP_WIDTH // 2 - 250, MAP_HEIGHT // 2, "goliath_prime_titan", hp_scale=50.0)
        d1.is_training_dummy = True
        d1.anchor_x = MAP_WIDTH // 2 - 250
        d1.anchor_y = MAP_HEIGHT // 2
        d1.name = "Манекен-Исполин (DPS Тест)"
        d1.scale = 1.4
        d1.radius = int(22 * d1.scale)
        d1.speed = 0.0
        d1.damage = 0.0
        d1.hp = 99999
        d1.max_hp = 99999

        d2 = Enemy(MAP_WIDTH // 2, MAP_HEIGHT // 2, "cult_zealot", hp_scale=50.0)
        d2.is_training_dummy = True
        d2.anchor_x = MAP_WIDTH // 2
        d2.anchor_y = MAP_HEIGHT // 2
        d2.name = "Манекен Заморозки (Shatter Тест)"
        d2.speed = 0.0
        d2.damage = 0.0
        d2.hp = 99999
        d2.max_hp = 99999

        d3 = Enemy(MAP_WIDTH // 2 + 250, MAP_HEIGHT // 2, "void_stalker", hp_scale=50.0)
        d3.is_training_dummy = True
        d3.anchor_x = MAP_WIDTH // 2 + 250
        d3.anchor_y = MAP_HEIGHT // 2
        d3.name = "Манекен Рокировки (Backstab Тест)"
        d3.speed = 0.0
        d3.damage = 0.0
        d3.hp = 99999
        d3.max_hp = 99999

        self.enemies.extend([d1, d2, d3])
        self.player.x = MAP_WIDTH // 2
        self.player.y = MAP_HEIGHT // 2 + 180
        self.player.hp = self.player.max_hp

    def return_to_main_menu(self):
        """Safely returns to the main menu from any state (Game Over, Pause, Dojo, etc.)."""
        self.state = 'MAIN_MENU'
        self.player.alive = True
        self.player.hp = self.player.max_hp
        self.death_rects.clear()
        self.restart_confirm_active = False
        self.speedrun_confirm_active = False
        self.is_drawing = False
        self.stroke_points = []
        self.wild_magic_state = None
        self.is_drawing_wild_magic = False
        if hasattr(self, 'sfx'):
            self.sfx.play("dash")

    def leave_dojo(self):
        source = getattr(self, 'dojo_source', 'MAIN_MENU')
        if source == 'MAIN_MENU':
            self.return_to_main_menu()
        else:
            self.state = 'PLAYING'
            self.load_floor(self.current_floor_idx)

    def start_run(self):
        diff = DIFFICULTY_MANAGER.current
        CHALLENGE_MANAGER.reset_run_stats()
        self.player = Player(MAP_WIDTH // 2, MAP_HEIGHT // 2)
        self.player.game = self
        CHALLENGE_MANAGER.modify_player_on_start(self.player)
        self.score = 0
        self.death_rects = {}
        self.restart_confirm_active = False
        self.restart_confirm_rects = {}
        self.is_drawing = False
        self.stroke_points = []
        only_curses = CHALLENGE_MANAGER.should_offer_only_curses()
        self.current_portal_offerings = generate_portal_offerings(1, curse_chance=(1.0 if only_curses else diff.curse_chance), only_curses=only_curses)
        self.state = 'PLAYING'
        self.load_floor(0)
        self.sfx.play("dash")
        ch_text = CHALLENGE_MANAGER.get_badge_text()
        start_msg = f"ЗАБЕГ НАЧАТ! {diff.name.upper()} {ch_text}".strip()
        self.fx.add_floating_text(start_msg, self.player.x, self.player.y - 70, (255, 90, 220) if ch_text else diff.color, size=28)

    def reset_run(self):
        self.start_run()

    def on_player_death(self):
        """Halts gameplay and transitions to the GAME_OVER state."""
        if self.state == 'GAME_OVER':
            return
        self.player.alive = False
        self.state = 'GAME_OVER'
        self.is_drawing = False
        self.stroke_points = []
        self.wild_magic_state = None
        self.is_drawing_wild_magic = False
        self.bullet_time_timer = 0.0
        self.fx.add_screen_shake(16.0)
        self.sfx.play("fumble")

    def jump_to_floor_50(self):
        """Debug / Fast-travel helper: Loads Floor 50 and triggers Truth Boss encounter."""
        self.state = 'PLAYING'
        self.load_floor(49)
        self.fx.add_floating_text("ВХОД В ЧЕРТОГ ИСТИНЫ: 50 ЭТАЖ!", self.player.x, self.player.y - 90, TEXT_GOLD, size=28)

    def apply_perk(self, choice):
        if hasattr(self, 'current_portal_offerings') and self.current_portal_offerings:
            if 1 <= choice <= len(self.current_portal_offerings):
                offering = self.current_portal_offerings[choice - 1]
                offering.apply(self.player, self)
                if offering.is_cursed:
                    ACHIEVEMENT_MANAGER.unlock("curse_pact", self.fx, self.sfx)
        else:
            if choice == 1:
                self.player.max_hp += 40
                self.player.hp = self.player.max_hp
                self.fx.add_floating_text("+40 MAX HP & ПОЛНОЕ ИСЦЕЛЕНИЕ!", self.player.x, self.player.y - 70, (60, 240, 120), size=26)
            elif choice == 2:
                self.player.bonus_time_per_floor += 25.0
                self.fx.add_floating_text("+25s К ТАЙМЕРУ ЗОНЫ!", self.player.x, self.player.y - 70, TEXT_GOLD, size=26)
            elif choice == 3:
                self.player.bonus_damage_mult += 0.35
                self.fx.add_floating_text("+35% К УРОНУ ЗАКЛИНАНИЙ!", self.player.x, self.player.y - 70, (255, 80, 80), size=26)
        
        self.state = 'PLAYING'
        self.load_floor(self.current_floor_idx + 1)

    # -------------------------------------------------------------------------
    # INPUT HANDLING
    # -------------------------------------------------------------------------
    def handle_input(self):
        if self.state == 'DEV_GLYPH_STUDIO':
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    self.running = False
                else:
                    self.dev_studio.handle_event(event)
            return

        if self.secret_code_modal_active:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    self.running = False
                elif event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_ESCAPE:
                        self.secret_code_modal_active = False
                        self.sfx.play("dash")
                    elif event.key == pygame.K_RETURN:
                        self.submit_secret_code()
                    elif event.key == pygame.K_BACKSPACE:
                        self.secret_code_input = self.secret_code_input[:-1]
                    elif event.key == pygame.K_v and (pygame.key.get_mods() & pygame.KMOD_CTRL):
                        clip = safe_get_clipboard_text()
                        if clip:
                            self.secret_code_input += clip[:50]
                            self.sfx.play("parry")
                    else:
                        char = event.unicode
                        if char and char.isprintable() and len(self.secret_code_input) < 50:
                            self.secret_code_input += char
                elif event.type == pygame.MOUSEBUTTONDOWN and event.button in (1, 3):
                    m_pos = event.pos
                    if self.secret_code_rects.get("btn_paste") and self.secret_code_rects["btn_paste"].collidepoint(m_pos):
                        clip = safe_get_clipboard_text()
                        if clip:
                            self.secret_code_input += clip[:50]
                            self.sfx.play("parry")
                    elif self.secret_code_rects.get("btn_confirm") and self.secret_code_rects["btn_confirm"].collidepoint(m_pos):
                        self.submit_secret_code()
                    elif self.secret_code_rects.get("btn_cancel") and self.secret_code_rects["btn_cancel"].collidepoint(m_pos):
                        self.secret_code_modal_active = False
                        self.sfx.play("dash")
                    elif self.secret_code_rects.get("modal_rect") and not self.secret_code_rects["modal_rect"].collidepoint(m_pos):
                        self.secret_code_modal_active = False
                        self.sfx.play("dash")
            return

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                self.running = False

            # Restart Confirmation Modal input handling
            if getattr(self, 'restart_confirm_active', False):
                if event.type == pygame.KEYDOWN:
                    if event.key in (pygame.K_RETURN, pygame.K_y) or is_key_pressed(event, chars=('y', 'н')):
                        self.restart_confirm_active = False
                        self.reset_run()
                    elif event.key in (pygame.K_ESCAPE, pygame.K_n) or is_key_pressed(event, chars=('n', 'т')):
                        self.restart_confirm_active = False
                        self.sfx.play("dash")
                elif event.type == pygame.MOUSEBUTTONDOWN and event.button in (1, 3):
                    m_pos = event.pos
                    rects = getattr(self, 'restart_confirm_rects', {})
                    if rects.get("confirm") and rects["confirm"].collidepoint(m_pos):
                        self.restart_confirm_active = False
                        self.reset_run()
                    elif rects.get("cancel") and rects["cancel"].collidepoint(m_pos):
                        self.restart_confirm_active = False
                        self.sfx.play("dash")
                    elif rects.get("modal_rect") and not rects["modal_rect"].collidepoint(m_pos):
                        self.restart_confirm_active = False
                        self.sfx.play("dash")
                continue

            # Speedrun Confirmation Modal input handling
            if getattr(self, 'speedrun_confirm_active', False):
                if event.type == pygame.KEYDOWN:
                    if event.key in (pygame.K_RETURN, pygame.K_y) or is_key_pressed(event, chars=('y', 'н')):
                        self.start_speedrun()
                    elif event.key in (pygame.K_ESCAPE, pygame.K_n) or is_key_pressed(event, chars=('n', 'т')):
                        self.speedrun_confirm_active = False
                        self.sfx.play("dash")
                elif event.type == pygame.MOUSEBUTTONDOWN and event.button in (1, 3):
                    m_pos = event.pos
                    rects = getattr(self, 'speedrun_confirm_rects', {})
                    if rects.get("confirm") and rects["confirm"].collidepoint(m_pos):
                        self.start_speedrun()
                    elif rects.get("cancel") and rects["cancel"].collidepoint(m_pos):
                        self.speedrun_confirm_active = False
                        self.sfx.play("dash")
                    elif rects.get("modal_rect") and not rects["modal_rect"].collidepoint(m_pos):
                        self.speedrun_confirm_active = False
                        self.sfx.play("dash")
                continue

            elif event.type == pygame.KEYDOWN:
                # Global Hotkey for Fullscreen Toggle: F11 or Alt+Enter
                if event.key == pygame.K_F11 or (event.key == pygame.K_RETURN and ((pygame.key.get_mods() | getattr(event, 'mod', 0)) & pygame.KMOD_ALT)):
                    self.toggle_fullscreen()
                    continue

                # Global Hotkey for Display Quality / Resolution Toggle (FHD 1080p / 2K 1440p / HD 720p): F10
                if event.key == pygame.K_F10:
                    self.cycle_resolution()
                    continue

                # Global Hotkey for Developer Mode: ~ (Backquote) or F1
                if event.key in (pygame.K_BACKQUOTE, pygame.K_F1):
                    if self.dev_mode_unlocked:
                        self.state = 'DEV_GLYPH_STUDIO'
                        self.sfx.play("parry")
                    else:
                        self.secret_code_modal_active = True
                        self.secret_code_input = ""
                        self.secret_code_feedback = ""
                        self.sfx.play("parry")
                    continue

                # GAME_OVER Menu Navigation: R (restart), M / ESC (return to main menu)
                if self.state == 'GAME_OVER' or (not self.player.alive and self.state in ('PLAYING', 'DOJO')):
                    if is_key_pressed(event, pygame.K_r, scancodes=(pygame.KSCAN_R,), chars=('r', 'к')):
                        self.reset_run()
                    elif is_key_pressed(event, pygame.K_m, scancodes=(pygame.KSCAN_M,), chars=('m', 'ь')) or event.key == pygame.K_ESCAPE:
                        self.return_to_main_menu()
                    continue

                # MAIN MENU Navigation
                if self.state == 'MAIN_MENU':
                    if event.key in (pygame.K_1, pygame.K_RETURN, pygame.K_SPACE):
                        self.start_run()
                    elif event.key == pygame.K_2:
                        self.state = 'DIFFICULTY_SELECT'
                        self.sfx.play("parry")
                    elif event.key == pygame.K_3:
                        self.state = 'ACHIEVEMENTS_MENU'
                        self.sfx.play("parry")
                    elif event.key == pygame.K_4:
                        self.dojo_source = 'MAIN_MENU'
                        self.enter_dojo()
                    elif event.key in (pygame.K_5, pygame.K_k) or is_key_pressed(event, scancodes=(getattr(pygame, 'KSCAN_K', 14),), chars=('k', 'л')):
                        self.state = 'CUSTOM_GLYPH_FORGE'
                        self.custom_points = []
                        self.custom_glyph_feedback = "Зажми ЛКМ/ПКМ и нарисуй свой символ в золотом квадрате!"
                        self.sfx.play("parry")
                    elif event.key == pygame.K_7:
                        if self.dev_mode_unlocked:
                            self.state = 'DEV_GLYPH_STUDIO'
                            self.sfx.play("parry")
                        else:
                            self.secret_code_modal_active = True
                            self.secret_code_input = ""
                            self.secret_code_feedback = ""
                            self.sfx.play("parry")
                    elif event.key in (pygame.K_6, pygame.K_ESCAPE, pygame.K_q) or is_key_pressed(event, scancodes=(getattr(pygame, 'KSCAN_Q', 20),), chars=('q', 'й')):
                        self.running = False

                # DOJO NAVIGATION & SHORTCUT Keys
                elif self.state == 'DOJO':
                    if event.key == pygame.K_ESCAPE or is_key_pressed(event, pygame.K_m, scancodes=(pygame.KSCAN_M,), chars=('m', 'ь')):
                        self.leave_dojo()
                        self.sfx.play("dash")
                    elif event.key == pygame.K_TAB:
                        if hasattr(self, 'tutorial_manager'):
                            self.tutorial_manager.panel_collapsed = not self.tutorial_manager.panel_collapsed
                            self.sfx.play("parry")
                    elif event.key == pygame.K_h:
                        if hasattr(self, 'tutorial_manager'):
                            self.tutorial_manager.show_ghost_trajectory = not self.tutorial_manager.show_ghost_trajectory
                            self.sfx.play("parry")
                    elif event.key == pygame.K_LEFT:
                        if hasattr(self, 'tutorial_manager'):
                            self.tutorial_manager.prev_quest()
                            self.sfx.play("dash")
                    elif event.key == pygame.K_RIGHT:
                        if hasattr(self, 'tutorial_manager'):
                            self.tutorial_manager.next_quest()
                            self.sfx.play("dash")
                    elif event.key == pygame.K_p or is_key_pressed(event, scancodes=(getattr(pygame, 'KSCAN_P', 19),), chars=('p', 'з')):
                        self.state = 'PAUSED'

                # DIFFICULTY SELECTION & CHALLENGES Keys
                elif self.state == 'DIFFICULTY_SELECT':
                    if event.key in (pygame.K_TAB, pygame.K_q, pygame.K_e):
                        self.diff_modal_tab = 1 - getattr(self, 'diff_modal_tab', 0)
                        self.sfx.play("parry")
                    elif getattr(self, 'diff_modal_tab', 0) == 0:
                        if event.key == pygame.K_1:
                            DIFFICULTY_MANAGER.set_difficulty("APPRENTICE")
                            self.sfx.play("parry")
                        elif event.key == pygame.K_2:
                            DIFFICULTY_MANAGER.set_difficulty("ADEPT")
                            self.sfx.play("parry")
                        elif event.key == pygame.K_3:
                            DIFFICULTY_MANAGER.set_difficulty("INQUISITOR")
                            self.sfx.play("parry")
                        elif event.key == pygame.K_4:
                            DIFFICULTY_MANAGER.set_difficulty("NIGHTMARE")
                            self.sfx.play("parry")
                        elif event.key in (pygame.K_ESCAPE, pygame.K_RETURN) or is_key_pressed(event, pygame.K_m, scancodes=(pygame.KSCAN_M,), chars=('m', 'ь')):
                            self.return_to_main_menu()
                    else:
                        # Challenges Tab Keys (1-7 toggle individual challenges, A all, C clear, P/H/G presets)
                        ch_keys = [pygame.K_1, pygame.K_2, pygame.K_3, pygame.K_4, pygame.K_5, pygame.K_6, pygame.K_7]
                        if event.key in ch_keys:
                            ch_idx = ch_keys.index(event.key)
                            if ch_idx < len(CHALLENGE_ORDER):
                                CHALLENGE_MANAGER.toggle(CHALLENGE_ORDER[ch_idx])
                                self.sfx.play("parry")
                        elif event.key == pygame.K_a:
                            CHALLENGE_MANAGER.enable_all()
                            self.sfx.play("crit")
                        elif event.key == pygame.K_c:
                            CHALLENGE_MANAGER.disable_all()
                            self.sfx.play("dash")
                        elif event.key == pygame.K_p:
                            CHALLENGE_MANAGER.apply_preset_only_curses()
                            self.sfx.play("crit")
                        elif event.key == pygame.K_h:
                            CHALLENGE_MANAGER.apply_preset_titan_hell()
                            self.sfx.play("crit")
                        elif event.key == pygame.K_g:
                            CHALLENGE_MANAGER.apply_preset_glass_nightmare()
                            self.sfx.play("crit")
                        elif event.key in (pygame.K_ESCAPE, pygame.K_RETURN) or is_key_pressed(event, pygame.K_m, scancodes=(pygame.KSCAN_M,), chars=('m', 'ь')):
                            self.return_to_main_menu()

                # ACHIEVEMENTS MENU Keys
                elif self.state == 'ACHIEVEMENTS_MENU':
                    if event.key in (pygame.K_ESCAPE, pygame.K_BACKSPACE) or is_key_pressed(event, pygame.K_m, scancodes=(pygame.KSCAN_M,), chars=('m', 'ь')):
                        self.return_to_main_menu()
                    elif event.key in (pygame.K_LEFT, pygame.K_a):
                        self.achievements_page = max(0, self.achievements_page - 1)
                        self.sfx.play("dash")
                    elif event.key in (pygame.K_RIGHT, pygame.K_d):
                        tot_p = self.ach_menu_rects.get("total_pages", 1)
                        self.achievements_page = min(tot_p - 1, self.achievements_page + 1)
                        self.sfx.play("dash")

                # PAUSED Menu Navigation
                elif self.state == 'PAUSED':
                    if event.key in (pygame.K_ESCAPE, pygame.K_p) or is_key_pressed(event, scancodes=(getattr(pygame, 'KSCAN_P', 19),), chars=('p', 'з')):
                        self.state = 'PLAYING'
                    elif is_key_pressed(event, pygame.K_m, scancodes=(pygame.KSCAN_M,), chars=('m', 'ь')):
                        self.return_to_main_menu()
                    elif is_key_pressed(event, pygame.K_r, scancodes=(pygame.KSCAN_R,), chars=('r', 'к')):
                        self.restart_confirm_active = True
                        self.sfx.play("parry")
                    elif event.key == pygame.K_q or is_key_pressed(event, scancodes=(getattr(pygame, 'KSCAN_Q', 20),), chars=('q', 'й')):
                        self.running = False

                # Toggle Pause from Gameplay
                elif (event.key in (pygame.K_ESCAPE, pygame.K_p) or is_key_pressed(event, scancodes=(getattr(pygame, 'KSCAN_P', 19),), chars=('p', 'з'))) and self.state in ('PLAYING', 'TOME_OF_SYNTHESIS'):
                    if self.state == 'PLAYING':
                        self.state = 'PAUSED'
                    elif self.state == 'TOME_OF_SYNTHESIS':
                        self.state = 'PLAYING'

                # Interact: Pick up weapon or open Grimoire Lectern: E
                elif event.key == pygame.K_e and self.state in ('PLAYING', 'DOJO') and self.player.alive:
                    # Check nearby dropped weapon first
                    closest_dw = None
                    min_dist = 70.0
                    for dw in self.dropped_weapons:
                        if dw.alive:
                            d = math.hypot(self.player.x - dw.x, self.player.y - dw.y)
                            if d < min_dist:
                                min_dist = d
                                closest_dw = dw

                    if closest_dw:
                        old_wep = self.player.weapon
                        self.player.equip_weapon(closest_dw.weapon)
                        closest_dw.weapon = old_wep
                        closest_dw.x = self.player.x
                        closest_dw.y = self.player.y

                        cur_w = self.player.weapon
                        self.fx.spawn_sparks(self.player.x, self.player.y, cur_w.glow_color, count=36, speed=230)
                        if cur_w.tier == 5:
                            self.fx.add_screen_shake(22.0)
                            self.sfx.play("crit")
                            self.fx.add_floating_text(f"ВЗЯТО: {cur_w.name}", self.player.x, self.player.y - 75, (255, 255, 255), size=28)
                            ACHIEVEMENT_MANAGER.unlock("divine_weapon_pickup", self.fx, self.sfx)
                        elif cur_w.tier >= 4:
                            self.fx.add_screen_shake(12.0)
                            self.sfx.play("crit")
                            self.fx.add_floating_text(f"ВЗЯТО: {cur_w.name}", self.player.x, self.player.y - 55, cur_w.glow_color, size=24)
                        else:
                            self.sfx.play("parry")
                            self.fx.add_floating_text(f"ВЗЯТО: {cur_w.name}", self.player.x, self.player.y - 50, cur_w.glow_color, size=22)

                        if all(w.tier >= 3 for w in self.player.weapon_slots.values()):
                            ACHIEVEMENT_MANAGER.unlock("arsenal_master", self.fx, self.sfx)
                    else:
                        d_lectern = math.hypot(self.player.x - self.lectern_pos[0], self.player.y - self.lectern_pos[1])
                        if d_lectern < 100:
                            self.state = 'TOME_OF_SYNTHESIS'
                            self.sfx.play("parry")

                # Training Dojo toggle: T
                elif event.key == pygame.K_t and self.player.alive and self.state in ('PLAYING', 'DOJO'):
                    if self.state == 'DOJO':
                        self.leave_dojo()
                    else:
                        self.dojo_source = 'PLAYING'
                        self.enter_dojo()

                # Combo Forge Menu toggle: C
                elif event.key == pygame.K_c and self.player.alive and self.state in ('PLAYING', 'DOJO', 'COMBO_FORGE_MENU'):
                    if self.state == 'COMBO_FORGE_MENU':
                        self.state = getattr(self, 'combo_forge_prev_state', 'PLAYING')
                    else:
                        self.combo_forge_prev_state = self.state
                        self.state = 'COMBO_FORGE_MENU'
                        self.forge_points = []
                        self.forge_feedback = "Черти знаки связкой (минимум 3, максимум 5 знаков)!"
                        if hasattr(self, 'tutorial_manager'):
                            self.tutorial_manager.on_altar_open(self.fx, self.sfx)
                            if self.tutorial_manager.is_all_completed():
                                ACHIEVEMENT_MANAGER.unlock("dojo_graduate", self.fx, self.sfx)

                elif self.state == 'COMBO_FORGE_MENU':
                    if event.key == pygame.K_SPACE:
                        if len(self.forge_slots) >= 3:
                            resolved = COMBO_MATRIX.resolve_combo(self.forge_slots)
                            self.fx.add_screen_shake(20.0)
                            self.sfx.play("crit")
                            self.forge_feedback = f"ТЕСТ: {resolved['name']} сработал с уроном x{resolved['mult']:.2f}!"
                        else:
                            self.forge_feedback = "Сначала начерти минимум 3 знака для комбо!"
                    elif event.key == pygame.K_RETURN:
                        if len(self.forge_slots) >= 3:
                            resolved = COMBO_MATRIX.resolve_combo(self.forge_slots)
                            self.sealed_ultra_combo = resolved
                            self.sfx.play("crit")
                            self.forge_feedback = f"★ УЛЬТРА-КОМБО «{resolved['name']}» ЗАПЕЧАТАНО В СЛОТ!"
                        else:
                            self.forge_feedback = "Нужно минимум 3 знака для запечатывания комбо!"
                    elif event.key == pygame.K_BACKSPACE:
                        self.forge_slots.clear()
                        self.forge_feedback = "Слоты очищены. Начерти новую связку из 3-5 знаков!"
                    elif event.key in (pygame.K_ESCAPE, pygame.K_c):
                        self.state = getattr(self, 'combo_forge_prev_state', 'PLAYING')

                # Custom Glyph Studio toggle: K
                elif event.key == pygame.K_k and self.player.alive and self.state in ('PLAYING', 'DOJO', 'CUSTOM_GLYPH_FORGE'):
                    if self.state == 'CUSTOM_GLYPH_FORGE':
                        self.state = 'DOJO'
                    else:
                        self.state = 'CUSTOM_GLYPH_FORGE'
                        self.custom_points = []
                        self.custom_glyph_feedback = "Зажми ЛКМ/ПКМ и нарисуй свой символ в золотом квадрате!"

                elif self.state == 'CUSTOM_GLYPH_FORGE':
                    if event.key == pygame.K_RETURN:
                        if len(self.custom_points) >= 4:
                            register_custom_glyph(self.custom_points, "CUSTOM_GLYPH")
                            self.custom_glyph_recorded = True
                            self.custom_glyph_feedback = "★ ЗНАК УСПЕШНО СОХРАНЕН! Теперь черти его в бою! [ESC / K]"
                            self.sfx.play("crit")
                            self.fx.add_screen_shake(12.0)
                            ACHIEVEMENT_MANAGER.unlock("custom_glyph_creator", self.fx, self.sfx)
                        else:
                            self.custom_glyph_feedback = "Слишком мало точек! Нарисуй четкий знак."
                    elif event.key == pygame.K_BACKSPACE:
                        self.custom_points = []
                        self.custom_glyph_feedback = "Холст очищен. Нарисуй новый знак!"
                    elif event.key == pygame.K_ESCAPE or is_key_pressed(event, pygame.K_m, scancodes=(pygame.KSCAN_M,), chars=('m', 'ь')):
                        self.return_to_main_menu()

                # Restart run shortcut (with confirmation during active gameplay)
                elif is_key_pressed(event, pygame.K_r, scancodes=(pygame.KSCAN_R,), chars=('r', 'к')):
                    if self.state == 'GAME_OVER' or not self.player.alive:
                        self.reset_run()
                    elif self.state in ('PLAYING', 'PAUSED', 'DOJO', 'TOME_OF_SYNTHESIS', 'COMBO_FORGE_MENU', 'PERK_SELECTION'):
                        self.restart_confirm_active = True
                        self.sfx.play("parry")

                # Speedrun mode shortcut: Slash key '/' or '?'
                elif (event.key in (pygame.K_SLASH, pygame.K_QUESTION) or getattr(event, 'unicode', '') == '/') and self.state in ('PLAYING', 'PAUSED', 'DOJO', 'TOME_OF_SYNTHESIS', 'COMBO_FORGE_MENU', 'PERK_SELECTION', 'MAIN_MENU'):
                    self.speedrun_confirm_active = True
                    self.sfx.play("parry")

                # Floor 50 Boss & Damage Test Shortcuts
                elif event.key == pygame.K_F5 and self.state in ('PLAYING', 'PAUSED', 'DOJO'):
                    self.jump_to_floor_50()
                elif event.key == pygame.K_F6 and self.state in ('PLAYING', 'PAUSED', 'DOJO'):
                    self.player.take_damage(20.0, self.fx, self.sfx, self.art, False)
                    self.fx.add_floating_text("ТЕСТ: +20 УРОНА ПОЛУЧЕНО!", self.player.x, self.player.y - 70, (255, 60, 60), size=24)
                elif event.key == pygame.K_F7 and self.state in ('PLAYING', 'PAUSED', 'DOJO'):
                    self.player.total_damage_taken_run = 0.0
                    self.player.total_hits_taken_run = 0
                    self.player.hp = self.player.max_hp
                    self.fx.add_floating_text("ТЕСТ: УРОН СБРОШЕН (0 HP NO-HIT)!", self.player.x, self.player.y - 70, (120, 240, 255), size=24)

                # Boss Dialogue Keyboard Controls
                elif self.state == 'BOSS_DIALOGUE':
                    if self.dialogue_stage == 'QUESTION':
                        if event.key == pygame.K_1:
                            self.handle_boss_dialogue_choice(1)
                        elif event.key == pygame.K_2:
                            self.handle_boss_dialogue_choice(2)
                    elif self.dialogue_stage in ('ANSWER_LIED', 'ANSWER_NO_HIT', 'ANSWER_TRUTH'):
                        if event.key in (pygame.K_SPACE, pygame.K_RETURN, pygame.K_1, pygame.K_2):
                            self.close_boss_dialogue()

                # Quit in pause menu
                elif event.key == pygame.K_q and self.state == 'PAUSED':
                    self.running = False

                # Perk selection keys
                elif self.state == 'PERK_SELECTION':
                    if event.key in (pygame.K_1, pygame.K_2, pygame.K_3):
                        choice = int(event.unicode)
                        self.apply_perk(choice)

                # Weapon switch between carried slots during play
                elif self.state in ('PLAYING', 'DOJO') and event.key in (pygame.K_1, pygame.K_2, pygame.K_3):
                    w_slot = int(event.unicode)
                    if hasattr(self.player, 'switch_weapon_slot') and self.player.switch_weapon_slot(w_slot):
                        w = self.player.weapon
                        self.sfx.play("dash")
                        self.fx.spawn_sparks(self.player.x, self.player.y, w.glow_color, count=16, speed=170)
                        self.fx.add_floating_text(f"[{w_slot}] {w.name} ({w.short_tier})", self.player.x, self.player.y - 50, w.glow_color, size=22)
                        if self.state == 'DOJO' and hasattr(self, 'tutorial_manager'):
                            self.tutorial_manager.on_weapon_switch(w_slot, self.fx, self.sfx)
                            if self.tutorial_manager.is_all_completed():
                                ACHIEVEMENT_MANAGER.unlock("dojo_graduate", self.fx, self.sfx)

                # Cast Sealed Ultra-Combo: F
                elif event.key == pygame.K_f and self.state in ('PLAYING', 'DOJO'):
                    if self.sealed_ultra_combo:
                        world_mx = self.cam_x + pygame.mouse.get_pos()[0]
                        world_my = self.cam_y + pygame.mouse.get_pos()[1]
                        ultra = self.sealed_ultra_combo["creator"](world_mx, world_my, self.player.weapon.damage_mult * self.sealed_ultra_combo["mult"])
                        self.active_abilities.append(ultra)
                        self.fx.add_floating_text(f"★★★ {self.sealed_ultra_combo['name']}! ★★★", world_mx, world_my - 75, self.sealed_ultra_combo["color"], size=30)
                        self.fx.add_screen_shake(28.0)
                        self.sfx.play("crit")
                        ACHIEVEMENT_MANAGER.unlock("ultra_combo_cast", self.fx, self.sfx)
                        self.sealed_ultra_combo = None
                    else:
                        self.fx.add_floating_text("НЕТ ЗАПЕЧАТАННОГО КОМБО! Нажми [C] для синтеза", self.player.x, self.player.y - 45, (255, 120, 120), size=20)

                # Wild Magic & Combo Buffer Controls: SPACE / ENTER to Start, Q to toggle mode, BACKSPACE to pop rune
                elif self.state in ('PLAYING', 'DOJO') and event.key in (pygame.K_SPACE, pygame.K_RETURN):
                    self.trigger_wild_magic_start()
                elif self.state in ('PLAYING', 'DOJO') and event.key == pygame.K_q:
                    self.wild_magic_mode = not getattr(self, 'wild_magic_mode', True)
                    m_name = "НАКОПЛЕНИЕ В КОМБО" if self.wild_magic_mode else "МГНОВЕННЫЙ КАСТ"
                    self.fx.add_floating_text(f"Режим: {m_name}", self.player.x, self.player.y - 45, TEXT_CYAN, size=22)
                    self.sfx.play("parry")
                elif self.state in ('PLAYING', 'DOJO') and event.key == pygame.K_BACKSPACE:
                    if self.wild_magic_queue:
                        popped = self.wild_magic_queue.pop()
                        p_info = SKILL_INFO.get(popped, {})
                        self.fx.add_floating_text(f"Удален знак {p_info.get('symbol', popped)}", self.player.x, self.player.y - 45, (220, 200, 200), size=20)
                        self.sfx.play("dash")
                elif getattr(self, 'wild_magic_state', None) == 'RITUAL' and event.key == pygame.K_ESCAPE:
                    self.wild_magic_state = None
                    self.wild_magic_drawn_points = []
                    self.bullet_time_timer = 0.0
                    self.fx.add_floating_text("Ритуал отменен!", self.player.x, self.player.y - 45, (200, 215, 235), size=20)
                    self.sfx.play("parry")
                elif self.state == 'CUTSCENE_5_GLYPH' and event.key in (pygame.K_SPACE, pygame.K_RETURN, pygame.K_ESCAPE):
                    self.end_5_glyph_cutscene()

            # Main Menu Mouse Click
            elif self.state == 'MAIN_MENU':
                if event.type == pygame.MOUSEBUTTONDOWN and event.button in (1, 3):
                    m_pos = event.pos
                    if self.menu_buttons.get("START") and self.menu_buttons["START"].collidepoint(m_pos):
                        self.start_run()
                    elif self.menu_buttons.get("DIFFICULTY") and self.menu_buttons["DIFFICULTY"].collidepoint(m_pos):
                        self.state = 'DIFFICULTY_SELECT'
                        self.sfx.play("parry")
                    elif self.menu_buttons.get("ACHIEVEMENTS") and self.menu_buttons["ACHIEVEMENTS"].collidepoint(m_pos):
                        self.state = 'ACHIEVEMENTS_MENU'
                        self.sfx.play("parry")
                    elif self.menu_buttons.get("DOJO") and self.menu_buttons["DOJO"].collidepoint(m_pos):
                        self.dojo_source = 'MAIN_MENU'
                        self.enter_dojo()
                    elif self.menu_buttons.get("CUSTOM_GLYPH") and self.menu_buttons["CUSTOM_GLYPH"].collidepoint(m_pos):
                        self.state = 'CUSTOM_GLYPH_FORGE'
                        self.custom_points = []
                        self.custom_glyph_feedback = "Зажми ЛКМ/ПКМ и нарисуй свой символ в золотом квадрате!"
                        self.sfx.play("parry")
                    elif self.menu_buttons.get("DEV_STUDIO") and self.menu_buttons["DEV_STUDIO"].collidepoint(m_pos):
                        self.state = 'DEV_GLYPH_STUDIO'
                        self.sfx.play("parry")
                    elif self.menu_buttons.get("SECRET_CODE") and self.menu_buttons["SECRET_CODE"].collidepoint(m_pos):
                        if self.dev_mode_unlocked:
                            self.state = 'DEV_GLYPH_STUDIO'
                            self.sfx.play("parry")
                        else:
                            self.secret_code_modal_active = True
                            self.secret_code_input = ""
                            self.secret_code_feedback = ""
                            self.sfx.play("parry")
                    elif self.menu_buttons.get("FULLSCREEN") and self.menu_buttons["FULLSCREEN"].collidepoint(m_pos):
                        self.toggle_fullscreen()
                    elif self.menu_buttons.get("RESOLUTION") and self.menu_buttons["RESOLUTION"].collidepoint(m_pos):
                        self.cycle_resolution()
                    elif self.menu_buttons.get("QUIT") and self.menu_buttons["QUIT"].collidepoint(m_pos):
                        self.running = False

            # Pause Menu Mouse Click
            elif self.state == 'PAUSED':
                if event.type == pygame.MOUSEBUTTONDOWN and event.button in (1, 3):
                    m_pos = event.pos
                    if getattr(self, 'pause_rects', {}).get("fullscreen") and self.pause_rects["fullscreen"].collidepoint(m_pos):
                        self.toggle_fullscreen()
                    elif getattr(self, 'pause_rects', {}).get("resolution") and self.pause_rects["resolution"].collidepoint(m_pos):
                        self.cycle_resolution()

            # Difficulty Selection & Challenges Mouse Click
            elif self.state == 'DIFFICULTY_SELECT':
                if event.type == pygame.MOUSEBUTTONDOWN and event.button in (1, 3):
                    m_pos = event.pos
                    if self.diff_modal_rects.get("btn_back") and self.diff_modal_rects["btn_back"].collidepoint(m_pos):
                        self.state = 'MAIN_MENU'
                        self.sfx.play("dash")
                    elif self.diff_modal_rects.get("btn_tab_diff") and self.diff_modal_rects["btn_tab_diff"].collidepoint(m_pos):
                        self.diff_modal_tab = 0
                        self.sfx.play("parry")
                    elif self.diff_modal_rects.get("btn_tab_chal") and self.diff_modal_rects["btn_tab_chal"].collidepoint(m_pos):
                        self.diff_modal_tab = 1
                        self.sfx.play("parry")
                    elif self.diff_modal_rects.get("btn_chal_banner") and self.diff_modal_rects["btn_chal_banner"].collidepoint(m_pos):
                        self.diff_modal_tab = 1
                        self.sfx.play("parry")
                    elif getattr(self, 'diff_modal_tab', 0) == 0:
                        for d_key, r in self.diff_modal_rects.get("card_rects", {}).items():
                            if r.collidepoint(m_pos):
                                DIFFICULTY_MANAGER.set_difficulty(d_key)
                                self.sfx.play("parry")
                                break
                    else:
                        # Challenges Tab clicks
                        clicked_ch = False
                        for ch_key, r in self.diff_modal_rects.get("challenge_rects", {}).items():
                            if r.collidepoint(m_pos):
                                CHALLENGE_MANAGER.toggle(ch_key)
                                self.sfx.play("parry")
                                clicked_ch = True
                                break
                        if not clicked_ch:
                            presets = self.diff_modal_rects.get("preset_rects", {})
                            if presets.get("all") and presets["all"].collidepoint(m_pos):
                                CHALLENGE_MANAGER.enable_all()
                                self.sfx.play("crit")
                            elif presets.get("clear") and presets["clear"].collidepoint(m_pos):
                                CHALLENGE_MANAGER.disable_all()
                                self.sfx.play("dash")
                            elif presets.get("only_curses") and presets["only_curses"].collidepoint(m_pos):
                                CHALLENGE_MANAGER.apply_preset_only_curses()
                                self.sfx.play("crit")
                            elif presets.get("titan_hell") and presets["titan_hell"].collidepoint(m_pos):
                                CHALLENGE_MANAGER.apply_preset_titan_hell()
                                self.sfx.play("crit")
                            elif presets.get("glass_nightmare") and presets["glass_nightmare"].collidepoint(m_pos):
                                CHALLENGE_MANAGER.apply_preset_glass_nightmare()
                                self.sfx.play("crit")

            # Achievements Menu Mouse Click
            elif self.state == 'ACHIEVEMENTS_MENU':
                if event.type == pygame.MOUSEBUTTONDOWN and event.button in (1, 3):
                    m_pos = event.pos
                    if self.ach_menu_rects.get("btn_back") and self.ach_menu_rects["btn_back"].collidepoint(m_pos):
                        self.state = 'MAIN_MENU'
                        self.sfx.play("dash")
                    elif self.ach_menu_rects.get("btn_prev") and self.ach_menu_rects["btn_prev"].collidepoint(m_pos):
                        self.achievements_page = max(0, self.achievements_page - 1)
                        self.sfx.play("dash")
                    elif self.ach_menu_rects.get("btn_next") and self.ach_menu_rects["btn_next"].collidepoint(m_pos):
                        tot_p = self.ach_menu_rects.get("total_pages", 1)
                        self.achievements_page = min(tot_p - 1, self.achievements_page + 1)
                        self.sfx.play("dash")

            # Boss Dialogue Mouse Click
            elif self.state == 'BOSS_DIALOGUE':
                if event.type == pygame.MOUSEBUTTONDOWN and event.button in (1, 3):
                    m_pos = event.pos
                    if self.dialogue_stage == 'QUESTION':
                        if self.dialogue_rects.get("opt1") and self.dialogue_rects["opt1"].collidepoint(m_pos):
                            self.handle_boss_dialogue_choice(1)
                        elif self.dialogue_rects.get("opt2") and self.dialogue_rects["opt2"].collidepoint(m_pos):
                            self.handle_boss_dialogue_choice(2)
                    elif self.dialogue_stage in ('ANSWER_LIED', 'ANSWER_NO_HIT', 'ANSWER_TRUTH'):
                        if self.dialogue_rects.get("btn_continue") and self.dialogue_rects["btn_continue"].collidepoint(m_pos):
                            self.close_boss_dialogue()

            # Perk Selection Mouse Click
            elif self.state == 'PERK_SELECTION':
                if event.type == pygame.MOUSEBUTTONDOWN and event.button in (1, 3):
                    sw = self.screen.get_width()
                    card_w = 780
                    card_h = 118
                    card_x = sw // 2 - card_w // 2
                    card_y_start = 125
                    card_gap = 135
                    offerings = getattr(self, 'current_portal_offerings', [])
                    for idx in range(len(offerings)):
                        c_rect = pygame.Rect(card_x, card_y_start + idx * card_gap, card_w, card_h)
                        if c_rect.collidepoint(event.pos):
                            self.apply_perk(idx + 1)
                            break

            # Combo Forge Menu Mouse Drawing
            elif self.state == 'COMBO_FORGE_MENU':
                if event.type == pygame.MOUSEBUTTONDOWN:
                    if event.button in (1, 3):
                        rects = self.get_combo_forge_rects()
                        if rects["btn_test"].collidepoint(event.pos):
                            if len(self.forge_slots) >= 3:
                                resolved = COMBO_MATRIX.resolve_combo(self.forge_slots)
                                self.fx.add_screen_shake(20.0)
                                self.sfx.play("crit")
                                self.forge_feedback = f"ТЕСТ: {resolved['name']} (Урон x{resolved['mult']:.2f})!"
                            else:
                                self.forge_feedback = "Сначала начерти минимум 3 знака для комбо!"
                        elif rects["btn_seal"].collidepoint(event.pos):
                            if len(self.forge_slots) >= 3:
                                resolved = COMBO_MATRIX.resolve_combo(self.forge_slots)
                                self.sealed_ultra_combo = resolved
                                self.sfx.play("crit")
                                self.forge_feedback = f"★ УЛЬТРА-КОМБО «{resolved['name']}» ЗАПЕЧАТАНО В СЛОТ [F]!"
                            else:
                                self.forge_feedback = "Нужно минимум 3 знака для запечатывания комбо!"
                        elif rects["btn_clear"].collidepoint(event.pos):
                            self.forge_slots.clear()
                            self.forge_feedback = "Слоты очищены. Начерти новую связку из 3-5 знаков!"
                        elif rects["btn_exit"].collidepoint(event.pos):
                            self.state = 'PLAYING'
                        else:
                            clicked_eid = None
                            for eid, er in rects["elem_rects"].items():
                                if er.collidepoint(event.pos):
                                    clicked_eid = eid
                                    break
                            if clicked_eid:
                                if COMBO_MATRIX.is_element_unlocked(clicked_eid):
                                    if len(self.forge_slots) < 5:
                                        self.forge_slots.append(clicked_eid)
                                        self.sfx.play("slash")
                                        if len(self.forge_slots) >= 3:
                                            res = COMBO_MATRIX.resolve_combo(self.forge_slots)
                                            self.forge_feedback = f"СИНТЕЗИРОВАНО: {res['name']}!"
                                        else:
                                            self.forge_feedback = f"Добавлена стихия: {ELEMENTS[clicked_eid]['name']} ({len(self.forge_slots)}/5)"
                                    else:
                                        self.forge_feedback = "Слоты заполнены (максимум 5 знаков)!"
                                else:
                                    self.forge_feedback = f"Стихия засекречена! Достигни Этажа {ELEMENTS[clicked_eid]['floor_unlock']} для открытия."
                                    self.sfx.play("parry")
                            elif rects["canvas_rect"].collidepoint(event.pos):
                                self.is_drawing = True
                                self.forge_points = [event.pos]
                elif event.type == pygame.MOUSEBUTTONUP:
                    if event.button in (1, 3) and self.is_drawing:
                        self.is_drawing = False
                        if len(self.forge_points) >= 3:
                            skill_id, score, tier, dev = evaluate_gesture(self.forge_points)
                            if skill_id and score >= 0.40:
                                if len(self.forge_slots) < 5:
                                    self.forge_slots.append(skill_id)
                                    self.sfx.play("slash")
                                    if len(self.forge_slots) >= 3:
                                        res = COMBO_MATRIX.resolve_combo(self.forge_slots)
                                        self.forge_feedback = f"СИНТЕЗИРОВАНО: {res['name']}!"
                                    else:
                                        self.forge_feedback = f"Добавлен знак ({len(self.forge_slots)}/5). Черти дальше..."
                            else:
                                self.forge_feedback = "Знак не распознан. Попробуй начертить четче!"
                        self.forge_points = []
                elif event.type == pygame.MOUSEMOTION and self.is_drawing:
                    self.forge_points.append(event.pos)

            # Custom Glyph Studio Mouse Drawing
            elif self.state == 'CUSTOM_GLYPH_FORGE':
                if event.type == pygame.MOUSEBUTTONDOWN:
                    if event.button in (1, 3):
                        self.is_drawing = True
                        self.custom_points = [event.pos]
                elif event.type == pygame.MOUSEBUTTONUP:
                    if event.button in (1, 3):
                        self.is_drawing = False
                elif event.type == pygame.MOUSEMOTION and self.is_drawing:
                    self.custom_points.append(event.pos)

            elif self.state == 'GAME_OVER' or not self.player.alive:
                if event.type == pygame.MOUSEBUTTONDOWN and event.button in (1, 3):
                    m_pos = event.pos
                    if getattr(self, 'death_rects', None):
                        if self.death_rects.get("restart") and self.death_rects["restart"].collidepoint(m_pos):
                            self.reset_run()
                        elif self.death_rects.get("menu") and self.death_rects["menu"].collidepoint(m_pos):
                            self.return_to_main_menu()

            # Mouse Gesture Drawing & Wild Magic Ritual Input
            elif self.state in ('PLAYING', 'DOJO') and self.state != 'GAME_OVER' and self.player.alive:
                if getattr(self, 'wild_magic_state', None) == 'RITUAL':
                    if event.type == pygame.MOUSEBUTTONDOWN and event.button in (1, 3):
                        self.is_drawing_wild_magic = True
                        self.wild_magic_drawn_points = [event.pos]
                    elif event.type == pygame.MOUSEMOTION and getattr(self, 'is_drawing_wild_magic', False):
                        self.wild_magic_drawn_points.append(event.pos)
                    elif event.type == pygame.MOUSEBUTTONUP and event.button in (1, 3):
                        if getattr(self, 'is_drawing_wild_magic', False):
                            self.is_drawing_wild_magic = False
                            self.evaluate_wild_magic_drawing()

                elif event.type == pygame.MOUSEBUTTONDOWN:
                    if event.button in (1, 3):
                        if self.state == 'DOJO' and event.button == 1 and hasattr(self, 'tutorial_manager'):
                            if self.tutorial_manager.handle_click(event.pos):
                                continue

                        # Check interactive Combo Sign HUD bar buttons!
                        if event.button == 1 and getattr(self, 'wild_magic_rects', None):
                            if self.wild_magic_rects.get("start") and self.wild_magic_rects["start"].collidepoint(event.pos):
                                self.trigger_wild_magic_start()
                                continue
                            elif self.wild_magic_rects.get("clear") and self.wild_magic_rects["clear"].collidepoint(event.pos):
                                if self.wild_magic_queue:
                                    self.wild_magic_queue.clear()
                                    self.fx.add_floating_text("Очередь комбо очищена!", self.player.x, self.player.y - 45, (200, 215, 235), size=20)
                                    self.sfx.play("dash")
                                continue
                            elif self.wild_magic_rects.get("mode") and self.wild_magic_rects["mode"].collidepoint(event.pos):
                                self.wild_magic_mode = not getattr(self, 'wild_magic_mode', True)
                                m_name = "НАКОПЛЕНИЕ В КОМБО" if self.wild_magic_mode else "МГНОВЕННЫЙ КАСТ"
                                self.fx.add_floating_text(f"Режим: {m_name}", self.player.x, self.player.y - 45, TEXT_CYAN, size=22)
                                self.sfx.play("parry")
                                continue

                        if getattr(self, 'draw_cooldown', 0.0) > 0:
                            self.fx.add_floating_text(f"ПЕРЕЗАРЯДКА РИСОВАНИЯ: {self.draw_cooldown:.1f}с", self.player.x, self.player.y - 45, (255, 120, 80), size=20)
                            self.sfx.play("fumble")
                        else:
                            self.is_drawing = True
                            self.stroke_points = [event.pos]

                elif event.type == pygame.MOUSEBUTTONUP:
                    if event.button in (1, 3) and self.is_drawing:
                        self.is_drawing = False
                        if len(self.stroke_points) >= 2:
                            self.cast_gesture_ability(self.stroke_points)
                        self.stroke_points = []

                elif event.type == pygame.MOUSEMOTION and self.is_drawing:
                    mx, my = event.pos
                    jitter = (self.current_mutator["jitter"] + getattr(self.player, 'bonus_jitter', 0.0)) if self.state != 'DOJO' else 0.0
                    if jitter > 0:
                        mx += random.uniform(-jitter, jitter)
                        my += random.uniform(-jitter, jitter)
                    self.stroke_points.append((mx, my))

            elif self.state == 'CUTSCENE_5_GLYPH':
                if event.type == pygame.MOUSEBUTTONDOWN and event.button in (1, 3):
                    self.end_5_glyph_cutscene()

    # -------------------------------------------------------------------------
    # UPDATE LOGIC
    # -------------------------------------------------------------------------
    def update(self, real_dt):
        if self.state == 'DEV_GLYPH_STUDIO':
            self.anim_time += real_dt
            self.dev_studio.update(real_dt)
            self.fx.update(real_dt)
            return

        if self.secret_code_modal_active:
            self.secret_code_timer += real_dt

        if self.state == 'CUTSCENE_5_GLYPH':
            self.anim_time += real_dt
            self.fx.update(real_dt)
            return

        if getattr(self, 'restart_confirm_active', False) or getattr(self, 'speedrun_confirm_active', False):
            self.anim_time += real_dt
            self.fx.update(real_dt)
            return

        if self.state == 'GAME_OVER':
            self.anim_time += real_dt
            self.fx.update(real_dt)
            ACHIEVEMENT_MANAGER.update_popups(real_dt)
            return

        if self.state in ('PLAYING', 'DOJO') and not self.player.alive:
            self.on_player_death()
            self.anim_time += real_dt
            self.fx.update(real_dt)
            ACHIEVEMENT_MANAGER.update_popups(real_dt)
            return

        if self.state in ('PLAYING', 'DOJO'):
            if getattr(self, 'speedrun_active', False) and self.state == 'PLAYING':
                self.speedrun_time += real_dt

            # Check exploration of barricaded city exits & houses for the achievement
            if self.state == 'PLAYING':
                for bar in [ob for ob in self.obstacles if ob.get('type') == 'BENCH_BARRICADE']:
                    dist = math.hypot(self.player.x - bar['x'], self.player.y - bar['y'])
                    if dist < 140:
                        d_name = bar.get('district')
                        if d_name and d_name not in self.visited_city_districts:
                            self.visited_city_districts.add(d_name)
                            district_names = {
                                "NORTH": "Северные ворота (Баррикада)",
                                "SOUTH": "Южная площадь (Баррикада)",
                                "WEST": "Западная аллея (Баррикада)",
                                "EAST": "Восточный тракт (Баррикада)",
                            }
                            self.fx.add_floating_text(
                                f"Осмотрено: {district_names.get(d_name, d_name)} ({len(self.visited_city_districts)}/4)",
                                self.player.x, self.player.y - 65, (255, 215, 80), size=20
                            )
                            self.sfx.play("parry")
                            if len(self.visited_city_districts) >= 4:
                                ACHIEVEMENT_MANAGER.unlock("city_escape_attempt", self.fx, self.sfx)

            if getattr(self, 'wild_magic_state', None) == 'RITUAL':
                self.wild_magic_timer = max(0.0, self.wild_magic_timer - real_dt)
                if self.wild_magic_timer <= 0:
                    if len(self.wild_magic_drawn_points) >= 14:
                        self.evaluate_wild_magic_drawing()
                    else:
                        self.wild_magic_state = None
                        self.bullet_time_timer = 0.0
                        self.fx.add_floating_text("Время ритуала истекло!", self.player.x, self.player.y - 45, (255, 100, 100), size=24)

            is_bullet_time = (self.bullet_time_timer > 0)
            if is_bullet_time:
                self.bullet_time_timer = max(0.0, self.bullet_time_timer - real_dt)
                sim_dt = real_dt * 0.20
            else:
                sim_dt = real_dt

            self.anim_time += sim_dt
            if getattr(self, 'draw_cooldown', 0.0) > 0:
                self.draw_cooldown = max(0.0, self.draw_cooldown - sim_dt)
            keys = pygame.key.get_pressed()

            # Countdown timer (disabled in Dojo!)
            if self.state != 'DOJO':
                if self.player.alive and self.zone_timer > 0:
                    self.zone_timer = max(0.0, self.zone_timer - sim_dt * self.current_mutator["timer_mult"] * getattr(self.player, 'timer_drain_mult', 1.0))
                    if self.zone_timer <= 0:
                        self.player.alive = False
                        self.on_player_death()
                        return
            else:
                if hasattr(self, 'tutorial_manager'):
                    is_moving = any(keys[k] for k in (pygame.K_w, pygame.K_a, pygame.K_s, pygame.K_d, pygame.K_UP, pygame.K_LEFT, pygame.K_DOWN, pygame.K_RIGHT))
                    self.tutorial_manager.on_player_move(sim_dt, is_moving, self.fx, self.sfx)
                    self.tutorial_manager.update(sim_dt)
                    if self.tutorial_manager.is_all_completed():
                        ACHIEVEMENT_MANAGER.unlock("dojo_graduate", self.fx, self.sfx)
                self.player.hp = self.player.max_hp

            # Update entities
            self.player.update(sim_dt, keys, self.current_mutator["inertia_mult"], self.obstacles)

            # Camera lerp towards player (symmetrically centers arena when viewport >= MAP_WIDTH, e.g. in 2K 2560x1440)
            sw, sh = self.screen.get_size()
            if sw >= MAP_WIDTH:
                self.cam_x = -(sw - MAP_WIDTH) // 2
            else:
                target_cam_x = self.player.x - sw // 2
                self.cam_x += (target_cam_x - self.cam_x) * 0.12
                self.cam_x = max(0, min(MAP_WIDTH - sw, self.cam_x))

            if sh >= MAP_HEIGHT:
                self.cam_y = -(sh - MAP_HEIGHT) // 2
            else:
                target_cam_y = self.player.y - sh // 2
                self.cam_y += (target_cam_y - self.cam_y) * 0.12
                self.cam_y = max(0, min(MAP_HEIGHT - sh, self.cam_y))

            for ab in self.active_abilities:
                ab.update(sim_dt, self.enemies, self.player, self.fx, self.sfx, self.art, self.obstacles)
            self.active_abilities = [ab for ab in self.active_abilities if ab.alive]

            for en in self.enemies:
                en.update(sim_dt, self.player, self.fx, self.sfx, self.art, is_bullet_time, self.obstacles)

            # Enemy weapon drops loot roll
            for en in self.enemies:
                if not en.alive and not getattr(en, 'loot_dropped', False):
                    en.loot_dropped = True
                    dropped_w = roll_enemy_weapon_drop(en, self.current_floor_idx)
                    if dropped_w:
                        dw_entity = DroppedWeapon(dropped_w, en.x + random.uniform(-14, 14), en.y + random.uniform(-14, 14))
                        self.dropped_weapons.append(dw_entity)
                        self.fx.spawn_sparks(en.x, en.y, dropped_w.glow_color, count=28, speed=220)
                        if dropped_w.tier == 5:
                            self.fx.add_screen_shake(18.0)
                            self.sfx.play("crit")
                            self.fx.add_floating_text("★★★ БОЖЕСТВЕННЫЙ ДАР (БЕЛОЕ СВЕЧЕНИЕ)! ★★★", en.x, en.y - 70, (255, 255, 255), size=28)
                        elif dropped_w.tier >= 3:
                            self.sfx.play("crit")
                            self.fx.add_floating_text(f"★ ВЫПАЛО: {dropped_w.name}! ★", en.x, en.y - 50, dropped_w.glow_color, size=24)
                        else:
                            self.sfx.play("parry")
                            self.fx.add_floating_text(f"ВЫПАЛО: {dropped_w.name}", en.x, en.y - 40, dropped_w.glow_color, size=20)

            # Update dropped weapons animation
            for dw in self.dropped_weapons:
                dw.update(sim_dt)

            self.fx.update(sim_dt)

            # Wave & Portal Logic (Playing state only)
            if self.state == 'PLAYING':
                alive_count = sum(1 for en in self.enemies if en.alive)
                total_waves = len(self.current_floor_data["waves"])

                if alive_count == 0 and not self.portal_active:
                    if not getattr(self.player, 'damage_taken_in_wave', False):
                        ACHIEVEMENT_MANAGER.unlock("flawless_wave", self.fx, self.sfx)

                    if self.current_wave_idx < total_waves - 1:
                        # Advance to next wave
                        self.spawn_wave(self.current_wave_idx + 1)
                    else:
                        # Floor completely cleared! Activate portal
                        self.portal_active = True
                        is_tenth = ((self.current_floor_idx + 1) % 10 == 0)
                        self.is_tenth_floor_portal = is_tenth
                        if is_tenth:
                            self.portal_ritual_active = True
                            self.portal_ritual_timer = 0.0
                            self.sfx.play("slash")
                            self.fx.add_floating_text(
                                "РИТУАЛ 10-ГО ЭТАЖА: НАЧЕРТАНИЕ ПОРТАЛА МЕЛОМ...",
                                self.portal_pos[0], self.portal_pos[1] - 65, (235, 240, 255), size=26
                            )
                        else:
                            self.portal_ritual_active = False
                            self.sfx.play("parry")
                            self.fx.add_floating_text(
                                "ЭТАЖ ЗАЧИЩЕН! ШАГНИ В ПОРТАЛ",
                                self.portal_pos[0], self.portal_pos[1] - 50, TEXT_GOLD, size=32
                            )
                        self.check_wild_magic_boss_unlocks(self.current_floor_idx + 1)

                # Ritual progression on 10th floors
                if self.portal_active and self.portal_ritual_active:
                    prev_t = self.portal_ritual_timer
                    self.portal_ritual_timer += sim_dt
                    # Phase 1 chalk dust
                    if self.portal_ritual_timer < 1.6 and random.random() < 0.35:
                        ang = random.random() * math.pi * 2
                        rx = self.portal_pos[0] + math.cos(ang) * random.uniform(20, 52)
                        ry = self.portal_pos[1] + math.sin(ang) * random.uniform(8, 22)
                        self.fx.spawn_sparks(rx, ry, (230, 240, 255), count=2, speed=40.0)
                    # Phase 1 -> 2: Chalk ignites blue!
                    if prev_t < 1.6 and self.portal_ritual_timer >= 1.6:
                        self.sfx.play("parry")
                        self.fx.add_screen_shake(7.0)
                        self.fx.add_floating_text(
                            "САКРАЛЬНЫЙ МЕЛ ВОСПЛАМЕНЯЕТСЯ СИНИМ!",
                            self.portal_pos[0], self.portal_pos[1] - 65, (80, 220, 255), size=24
                        )
                        self.fx.spawn_sparks(self.portal_pos[0], self.portal_pos[1], (60, 200, 255), count=20, speed=160.0)
                    # Phase 2 -> 3: Dimensional portal erupts above glowing chalk seal!
                    if prev_t < 2.8 and self.portal_ritual_timer >= 2.8:
                        self.sfx.play("crit")
                        self.fx.add_screen_shake(14.0)
                        self.fx.add_floating_text(
                            "ПОРТАЛ 10-ГО ЭТАЖА ОТКРЫТ! ШАГНИ В РАЗЛОМ",
                            self.portal_pos[0], self.portal_pos[1] - 75, (160, 230, 255), size=28
                        )
                        self.fx.spawn_sparks(self.portal_pos[0], self.portal_pos[1] - 65, (180, 240, 255), count=30, speed=220.0)

                # Step into portal
                if self.portal_active:
                    can_enter = (not self.portal_ritual_active) or (self.portal_ritual_timer >= 2.8)
                    p_dist = math.hypot(self.player.x - self.portal_pos[0], self.player.y - self.portal_pos[1])
                    if p_dist < 46 and can_enter:
                        self.state = 'PERK_SELECTION'
                        diff = DIFFICULTY_MANAGER.current
                        only_c = CHALLENGE_MANAGER.should_offer_only_curses()
                        self.current_portal_offerings = generate_portal_offerings(
                            self.current_floor_idx + 1,
                            curse_chance=(1.0 if only_c else diff.curse_chance),
                            only_curses=only_c
                        )
                        self.sfx.play("crit")

        elif self.state in ('MAIN_MENU', 'DIFFICULTY_SELECT'):
            self.anim_time += real_dt
            update_menu_embers(real_dt, self.screen.get_width(), self.screen.get_height())
        else:
            self.anim_time += real_dt

        ACHIEVEMENT_MANAGER.update_popups(real_dt)

    # -------------------------------------------------------------------------
    # RENDERING
    # -------------------------------------------------------------------------
    def render(self):
        fonts_dict = {
            "title": self.font_title,
            "large": self.font_large,
            "med": self.font_med,
            "small": self.font_small,
            "sym_large": self.font_sym_large,
            "sym_med": self.font_sym_med,
            "sym_small": self.font_sym_small
        }

        if self.state == 'MAIN_MENU':
            self.menu_buttons = draw_main_menu(
                self.screen, self.anim_time, fonts_dict,
                bg_image=self.art.title_menu_bg, dev_unlocked=self.dev_mode_unlocked,
                is_fullscreen=self.is_fullscreen,
                resolution_name=getattr(self, 'resolution_key', DEFAULT_RESOLUTION)
            )
            if self.secret_code_modal_active:
                self.secret_code_rects = draw_secret_code_modal(
                    self.screen, fonts_dict, self.secret_code_input,
                    feedback_text=self.secret_code_feedback,
                    feedback_color=self.secret_code_feedback_color,
                    cursor_blink_time=self.secret_code_timer
                )
            ACHIEVEMENT_MANAGER.draw_active_popup(self.screen, self.anim_time, fonts_dict)
            pygame.display.flip()
            return

        elif self.state == 'DEV_GLYPH_STUDIO':
            self.dev_studio.render(self.screen)
            ACHIEVEMENT_MANAGER.draw_active_popup(self.screen, self.anim_time, fonts_dict)
            pygame.display.flip()
            return

        elif self.state == 'DIFFICULTY_SELECT':
            current_tab = getattr(self, 'diff_modal_tab', 0)
            self.diff_modal_rects = draw_difficulty_modal(self.screen, self.anim_time, fonts_dict, current_tab=current_tab)
            ACHIEVEMENT_MANAGER.draw_active_popup(self.screen, self.anim_time, fonts_dict)
            pygame.display.flip()
            return

        elif self.state == 'ACHIEVEMENTS_MENU':
            self.ach_menu_rects = draw_achievements_screen(self.screen, self.anim_time, fonts_dict, scroll_page=self.achievements_page)
            ACHIEVEMENT_MANAGER.draw_active_popup(self.screen, self.anim_time, fonts_dict)
            pygame.display.flip()
            return

        elif self.state == 'CUTSCENE_5_GLYPH':
            self.draw_5_glyph_cutscene(self.screen, getattr(self, 'last_dt', 0.016))
            ACHIEVEMENT_MANAGER.draw_active_popup(self.screen, self.anim_time, fonts_dict)
            pygame.display.flip()
            return

        shake_x, shake_y = self.fx.get_shake_offset()
        off_x = -self.cam_x + shake_x
        off_y = -self.cam_y + shake_y

        # 1. Floor
        sw, sh = self.screen.get_size()
        if self.art.tile_floor:
            tw, th = self.art.tile_floor.get_size()
            start_x = int((self.cam_x // tw) * tw)
            start_y = int((self.cam_y // th) * th)
            for tx in range(start_x, int(self.cam_x + sw + tw), tw):
                for ty in range(start_y, int(self.cam_y + sh + th), th):
                    self.screen.blit(self.art.tile_floor, (tx + off_x, ty + off_y))
        else:
            self.screen.fill((16, 20, 28))

        # 1.5 Surrounding Gothic City Buildings outside the barrier
        draw_city_perimeter(self.screen, MAP_WIDTH, MAP_HEIGHT, off_x, off_y, art=self.art, anim_time=self.anim_time)

        # Arena Glowing Runic Barrier (Luminous energy fence with corner nodes, electric pulses and proximity reaction)
        draw_arena_barrier(self.screen, MAP_WIDTH, MAP_HEIGHT, off_x, off_y, self.anim_time, player_pos=(self.player.x, self.player.y))

        # 2. Obstacles & Detailed Gothic Decor (Y-sorted for 2.5D depth)
        for obs in sorted(self.obstacles, key=lambda o: o['y']):
            draw_obstacle(self.screen, obs, off_x, off_y, art=self.art, anim_time=self.anim_time)

        # 3. Grimoire Lectern (Светящаяся книга)
        draw_grimoire_lectern(self.screen, self.lectern_pos[0], self.lectern_pos[1], self.anim_time, off_x, off_y)
        d_lect = math.hypot(self.player.x - self.lectern_pos[0], self.player.y - self.lectern_pos[1])
        if d_lect < 95:
            l_hint = self.font_small.render("[E] Открыть Гримуар Рецептов", True, TEXT_GOLD)
            self.screen.blit(l_hint, (int(self.lectern_pos[0] + off_x - l_hint.get_width() // 2), int(self.lectern_pos[1] + off_y - 48)))

        # 4. Portal if active
        if self.portal_active:
            is_tenth = getattr(self, 'is_tenth_floor_portal', False) or ((self.current_floor_idx + 1) % 10 == 0)
            rit_timer = getattr(self, 'portal_ritual_timer', 99.0) if getattr(self, 'portal_ritual_active', False) else 99.0
            draw_portal(
                self.screen, self.portal_pos[0] + off_x, self.portal_pos[1] + off_y,
                self.anim_time, art=self.art, is_tenth_floor=is_tenth, ritual_timer=rit_timer
            )

        # 5. Active Spells
        for ab in self.active_abilities:
            ab.draw(self.screen, off_x, off_y)

        # 6. Enemies
        for en in self.enemies:
            if not en.alive:
                continue
            ex = int(en.x + off_x)
            ey = int(en.y + off_y)
            angle_to_player = math.atan2(self.player.y - en.y, self.player.x - en.x)

            draw_enemy_sprite(self.screen, self.art, en, ex, ey, self.anim_time, angle_to_player)

            # Enraged Boss Aura (If Judge of Truth was lied to)
            if getattr(en, 'enraged', False):
                e_pulse = 0.5 + 0.5 * math.sin(self.anim_time * 10.0)
                e_rad = en.radius + 18 + int(6 * e_pulse)
                pygame.draw.circle(self.screen, (255, 45, 45), (ex, ey), e_rad, 3)
                e_badge = self.font_small.render("[В ЯРОСТИ ОТ ЛЖИ: +25% СКОРОСТЬ]", True, (255, 75, 75))
                self.screen.blit(e_badge, (ex - e_badge.get_width() // 2, ey - en.radius - 50))

                # Active Spell Immunities Barrier (pure visual runic hex shield, no text clutter)
                if getattr(en, 'spell_immunities', None) and len(en.spell_immunities) > 0:
                    hex_r = en.radius + 14 + int(3 * math.sin(self.anim_time * 8.0))
                    pygame.draw.circle(self.screen, (220, 90, 255), (ex, ey), hex_r, 2)
                    for i in range(6):
                        h_ang = self.anim_time * 2.5 + i * (math.pi / 3)
                        nx = ex + int(hex_r * math.cos(h_ang))
                        ny = ey + int(hex_r * math.sin(h_ang))
                        pygame.draw.circle(self.screen, (255, 180, 255), (nx, ny), 3)



            # Backstab indicator
            if getattr(en, 'backstab_vulnerable', False):
                pygame.draw.circle(self.screen, (255, 80, 240), (ex, ey - en.radius - 24), 8)
                pygame.draw.circle(self.screen, (255, 255, 255), (ex, ey - en.radius - 24), 4)

            # Health Bar
            bar_w = int(48 * (1.0 + en.scale * 0.4))
            bar_h = 5
            hp_ratio = en.hp / en.max_hp
            pygame.draw.rect(self.screen, (20, 20, 25), (ex - bar_w // 2, ey - en.radius - 16, bar_w, bar_h))
            bar_col = (140, 230, 255) if getattr(en, 'is_frozen', False) else (230, 50, 50)
            pygame.draw.rect(self.screen, bar_col, (ex - bar_w // 2, ey - en.radius - 16, int(bar_w * hp_ratio), bar_h))

            # Windup telegraph
            if en.is_attacking:
                ratio = min(1.0, en.windup_timer / (1.2 if en.scale > 1.4 else 0.85))
                t_rad = int(en.radius + (45 if en.scale > 1.4 else 30) * ratio)
                pygame.draw.circle(self.screen, (255, 50, 50), (ex, ey), t_rad, 2)

            lbl_text = en.name
            if getattr(en, 'is_frozen', False):
                lbl_text = f"{en.name} [ЗАМОРОЖЕН x2.5]"
            elif getattr(en, 'backstab_vulnerable', False):
                lbl_text = f"{en.name} [УЯЗВИМ x3]"
            lbl = self.font_small.render(lbl_text, True, en.tint)
            self.screen.blit(lbl, (ex - lbl.get_width() // 2, ey + en.radius + 6))

        # 6.5 Dropped Weapons on Arena Floor
        for dw in self.dropped_weapons:
            if dw.alive:
                d_p = math.hypot(self.player.x - dw.x, self.player.y - dw.y)
                is_near = (d_p < dw.pickup_radius)
                dw.draw(self.screen, off_x, off_y, self.anim_time, fonts_dict, is_player_near=is_near, current_player_weapon=self.player.weapon)

        # 7. Player Character (4-Frame Animated: Walk, Cast, Idle)
        px = int(self.player.x + off_x)
        py = int(self.player.y + off_y)
        is_p_moving = math.hypot(self.player.vx, self.player.vy) > 15
        is_p_casting = self.is_drawing or getattr(self, 'is_drawing_wild_magic', False) or (getattr(self.player, 'cast_anim_timer', 0.0) > 0)
        draw_player_character(
            self.screen, self.art, px, py, self.player.aim_angle, self.anim_time,
            self.player.weapon.color, self.player.fumble_timer > 0, self.player.i_frame_timer > 0,
            weapon_tier=self.player.weapon.tier,
            is_moving=is_p_moving,
            is_casting=is_p_casting,
            cast_timer=getattr(self.player, 'cast_anim_timer', 0.0),
            walk_time=getattr(self.player, 'walk_timer', 0.0)
        )

        # Bullet-Time Barrier
        if self.bullet_time_timer > 0:
            shield_r = int(38 + 4 * math.sin(self.anim_time * 12))
            shield_surf = pygame.Surface((shield_r * 2 + 10, shield_r * 2 + 10), pygame.SRCALPHA)
            pygame.draw.circle(shield_surf, (255, 215, 60, 160), (shield_r + 5, shield_r + 5), shield_r, 3)
            pygame.draw.circle(shield_surf, (255, 245, 180, 80), (shield_r + 5, shield_r + 5), shield_r - 6)
            self.screen.blit(shield_surf, (px - shield_r - 5, py - shield_r - 5))

        # 8. Slashes & Particles
        self.fx.draw(self.screen, off_x, off_y)

        # 9. Live Gesture Ink
        if self.is_drawing and len(self.stroke_points) >= 2:
            pygame.draw.lines(self.screen, (80, 160, 255), False, self.stroke_points, width=7)
            pygame.draw.lines(self.screen, (255, 255, 255), False, self.stroke_points, width=2)
            tip_x, tip_y = self.stroke_points[-1]
            pygame.draw.circle(self.screen, (255, 255, 220), (tip_x, tip_y), 6)

        # 10. Dynamic Lighting Overlay
        base_light_r = 250 if self.bullet_time_timer <= 0 else 320
        p_light_r = CHALLENGE_MANAGER.get_light_radius(base_light_r)
        if getattr(self.player.weapon, 'tier', 1) == 5:
            p_light_r = max(p_light_r, 340)
            p_light_col = (255, 255, 255)
        else:
            p_light_col = (140, 180, 255) if self.bullet_time_timer <= 0 else (255, 220, 80)

        light_sources = [
            (self.player.x + off_x, self.player.y + off_y, p_light_r, p_light_col, 0.95),
            (self.lectern_pos[0] + off_x, self.lectern_pos[1] + off_y, 140, (120, 220, 255), 0.8)
        ]
        if self.portal_active:
            is_tenth = getattr(self, 'is_tenth_floor_portal', False) or ((self.current_floor_idx + 1) % 10 == 0)
            if is_tenth:
                rit_timer = getattr(self, 'portal_ritual_timer', 99.0) if getattr(self, 'portal_ritual_active', False) else 99.0
                if rit_timer < 1.6:
                    light_sources.append((self.portal_pos[0] + off_x, self.portal_pos[1] + off_y, 140, (220, 230, 255), 0.7))
                elif rit_timer < 2.8:
                    light_sources.append((self.portal_pos[0] + off_x, self.portal_pos[1] + off_y, 240, (50, 180, 255), 0.95))
                else:
                    light_sources.append((self.portal_pos[0] + off_x, self.portal_pos[1] - 30 + off_y, 280, (60, 210, 255), 1.0))
            else:
                light_sources.append((self.portal_pos[0] + off_x, self.portal_pos[1] + off_y, 200, (100, 220, 255), 0.9))
        for obs in self.obstacles:
            if obs['type'] == 'BRAZIER':
                pulse = 1.0 + 0.08 * math.sin(self.anim_time * 7.0 + obs['x'])
                light_sources.append((obs['x'] + off_x, obs['y'] - 62 + off_y, int(175 * pulse), (255, 150, 45), 0.8))
            elif obs['type'] == 'SHRINE':
                pulse = 1.0 + 0.12 * math.sin(self.anim_time * 3.0)
                light_sources.append((obs['x'] + off_x, obs['y'] + off_y - 20, int(180 * pulse), (120, 180, 255), 0.8))
            elif obs['type'] == 'FOUNTAIN':
                pulse = 1.0 + 0.10 * math.sin(self.anim_time * 4.0)
                light_sources.append((obs['x'] + off_x, obs['y'] + off_y, int(170 * pulse), (255, 50, 70), 0.8))
            elif obs['type'] == 'ALCHEMY_TABLE':
                light_sources.append((obs['x'] + off_x, obs['y'] + off_y - 10, 150, (80, 255, 160), 0.7))
            elif obs['type'] == 'SARCOPHAGUS':
                pulse = 1.0 + 0.08 * math.sin(self.anim_time * 2.5 + obs['x'])
                light_sources.append((obs['x'] + off_x, obs['y'] + off_y, int(135 * pulse), (60, 140, 180), 0.65))
            elif obs['type'] == 'BENCH_BARRICADE':
                light_sources.append((obs['x'] + off_x, obs['y'] + off_y, 160, (255, 185, 80), 0.75))
        for ab in self.active_abilities:
            l = ab.get_light()
            if l:
                light_sources.append((l[0] + off_x, l[1] + off_y, l[2], l[3], l[4]))
        for en in self.enemies:
            if en.alive and en.scale > 1.3:
                light_sources.append((en.x + off_x, en.y + off_y, int(120 * en.scale), en.tint, 0.65))

        # Dropped weapons dynamic lighting
        for dw in self.dropped_weapons:
            if dw.alive:
                l = dw.get_light()
                light_sources.append((l[0] + off_x, l[1] + off_y, l[2], l[3], l[4]))

        self.art.render_lighting(self.screen, light_sources)

        # -------------------------------------------------------------
        # HUD RENDERING
        # -------------------------------------------------------------
        self.draw_hud(self.screen)

        # Wild Magic Ritual Fullscreen Tracing Overlay
        if getattr(self, 'wild_magic_state', None) == 'RITUAL':
            self.draw_wild_magic_ritual(self.screen)

        # -------------------------------------------------------------
        # OVERLAYS: TOME OF SYNTHESIS, PAUSE, PERK SELECTION, DEATH
        # -------------------------------------------------------------
        if self.state == 'TOME_OF_SYNTHESIS':
            hud.draw_tome_of_synthesis(self, self.screen)
        elif self.state == 'COMBO_FORGE_MENU':
            self._draw_combo_forge_menu()
        elif self.state == 'CUSTOM_GLYPH_FORGE':
            hud.draw_custom_glyph_forge(self, self.screen)
        elif self.state == 'PAUSED':
            hud.draw_pause_menu(self, self.screen)
        elif self.state == 'PERK_SELECTION':
            hud.draw_perk_selection(self, self.screen)
        elif self.state == 'BOSS_DIALOGUE':
            self.draw_boss_dialogue(self.screen, self.anim_time, fonts_dict)
        elif self.state == 'GAME_OVER' or (self.state in ('PLAYING', 'DOJO') and not self.player.alive):
            hud.draw_permadeath(self, self.screen)

        # Mouse Cursor Recharge Radial Gauge
        hud.draw_cursor_recharge(self, self.screen)

        if self.secret_code_modal_active:
            self.secret_code_rects = draw_secret_code_modal(
                self.screen, fonts_dict, self.secret_code_input,
                feedback_text=self.secret_code_feedback,
                feedback_color=self.secret_code_feedback_color,
                cursor_blink_time=self.secret_code_timer
            )

        # Restart Confirmation Modal overlay (renders on top of current view)
        if getattr(self, 'restart_confirm_active', False):
            self.restart_confirm_rects = hud.draw_restart_confirmation_modal(self, self.screen)

        # Speedrun Confirmation Modal overlay (renders on top of current view)
        if getattr(self, 'speedrun_confirm_active', False):
            self.speedrun_confirm_rects = hud.draw_speedrun_confirmation_modal(self, self.screen)

        ACHIEVEMENT_MANAGER.draw_active_popup(self.screen, self.anim_time, fonts_dict)
        pygame.display.flip()

    # -------------------------------------------------------------------------
    # MAIN LOOP
    # -------------------------------------------------------------------------
    def run(self):
        while self.running:
            real_dt = min(self.clock.tick(FPS) / 1000.0, 0.1)
            self.last_dt = real_dt
            self.handle_input()
            self.update(real_dt)
            self.render()

        pygame.quit()
        sys.exit()
