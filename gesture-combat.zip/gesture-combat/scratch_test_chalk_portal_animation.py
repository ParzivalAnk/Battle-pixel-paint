import os
import math
import random
import pygame
from PIL import Image

os.environ["SDL_VIDEODRIVER"] = "dummy"
pygame.init()
pygame.display.set_mode((1, 1), pygame.NOFRAME)

OUTPUT_DIR = "assets/anim_frames/portal_chalk"
os.makedirs(OUTPUT_DIR, exist_ok=True)

W, H = 200, 200
CX, CY = 100, 130 # Center of floor chalk seal
PORTAL_CY = 65    # Center of hovering portal in the air above

def draw_chalk_stroke(surface, pts, color, width=2, dust=True):
    for i in range(len(pts) - 1):
        x1, y1 = pts[i]
        x2, y2 = pts[i + 1]
        pygame.draw.line(surface, color, (int(x1), int(y1)), (int(x2), int(y2)), width)
        if dust and random.random() < 0.4:
            # Chalk crumb
            ox = x1 + random.uniform(-2, 2)
            oy = y1 + random.uniform(-1, 1)
            pygame.draw.circle(surface, (210, 215, 225, 140), (int(ox), int(oy)), 1)

def get_ellipse_pts(cx, cy, rx, ry, start_angle=0, end_angle=360, steps=36):
    pts = []
    for i in range(steps + 1):
        a = math.radians(start_angle + (end_angle - start_angle) * (i / steps))
        x = cx + rx * math.cos(a)
        y = cy + ry * math.sin(a)
        pts.append((x, y))
    return pts

def get_star_pts(cx, cy, rx, ry):
    # Inscribed 5-point star inside floor ellipse
    star_angles = [-90, -90 + 144, -90 + 288, -90 + 72, -90 + 216, -90]
    pts = []
    for a in star_angles:
        rad = math.radians(a)
        x = cx + rx * math.cos(rad)
        y = cy + ry * math.sin(rad)
        pts.append((x, y))
    return pts

def generate_chalk_portal_frames():
    """
    Generates the full multi-phase pixel animation:
    Phase 1 (Frames 0-3): Drawing chalk on the floor (white chalk strokes & dust)
    Phase 2 (Frames 4-7): Chalk turns luminous blue, ignites and radiates mana rays
    Phase 3 (Frames 8-11): Dimensional portal opens above the glowing seal and swirls
    """
    frames = []
    rx, ry = 52, 22 # Floor ellipse radii
    inner_rx, inner_ry = 38, 16

    CHALK_WHITE = (235, 238, 245, 230)
    CHALK_LIGHT = (210, 220, 235, 180)
    MANA_CYAN = (80, 210, 255, 240)
    MANA_CORE = (230, 250, 255, 255)
    MANA_BLUE = (30, 140, 255, 200)

    # -------------------------------------------------------------------------
    # PHASE 1: DRAWING CHALK ON THE FLOOR (Frames 0 to 3)
    # -------------------------------------------------------------------------
    # Frame 0: First arc drawn (0 to 120 deg) + chalk hand/stick position
    f0 = pygame.Surface((W, H), pygame.SRCALPHA)
    arc0 = get_ellipse_pts(CX, CY, rx, ry, -90, 30, steps=14)
    draw_chalk_stroke(f0, arc0, CHALK_WHITE, width=2)
    # Chalk stick tip and dust puff
    tip_x, tip_y = arc0[-1]
    pygame.draw.circle(f0, (255, 255, 255), (int(tip_x), int(tip_y)), 2)
    for _ in range(4):
        pygame.draw.circle(f0, (200, 210, 225, 160), (int(tip_x + random.uniform(-4, 4)), int(tip_y + random.uniform(-3, 3))), 1)
    frames.append(f0)

    # Frame 1: Full outer circle closed (-90 to 270 deg)
    f1 = pygame.Surface((W, H), pygame.SRCALPHA)
    arc1 = get_ellipse_pts(CX, CY, rx, ry, -90, 270, steps=36)
    draw_chalk_stroke(f1, arc1, CHALK_WHITE, width=2)
    # Chalk crumbs around outer ring
    for _ in range(8):
        ca = math.radians(random.uniform(0, 360))
        cx_crumb = CX + (rx + random.uniform(-3, 3)) * math.cos(ca)
        cy_crumb = CY + (ry + random.uniform(-2, 2)) * math.sin(ca)
        pygame.draw.circle(f1, (200, 210, 220, 140), (int(cx_crumb), int(cy_crumb)), 1)
    frames.append(f1)

    # Frame 2: Outer circle + Inner inscribed sacred geometric star lines
    f2 = pygame.Surface((W, H), pygame.SRCALPHA)
    f2.blit(f1, (0, 0))
    star_pts = get_star_pts(CX, CY, inner_rx, inner_ry)
    # Draw first 3 segments of star
    draw_chalk_stroke(f2, star_pts[:4], CHALK_WHITE, width=2)
    frames.append(f2)

    # Frame 3: Complete white chalk seal (Outer ring + Full 5-point star + 4 runic tick marks)
    f3 = pygame.Surface((W, H), pygame.SRCALPHA)
    f3.blit(f1, (0, 0))
    draw_chalk_stroke(f3, star_pts, CHALK_WHITE, width=2)
    # 4 Compass runic notches
    for ang in [0, 90, 180, 270]:
        ra = math.radians(ang)
        p1 = (CX + (rx - 4) * math.cos(ra), CY + (ry - 3) * math.sin(ra))
        p2 = (CX + (rx + 4) * math.cos(ra), CY + (ry + 3) * math.sin(ra))
        pygame.draw.line(f3, CHALK_WHITE, (int(p1[0]), int(p1[1])), (int(p2[0]), int(p2[1])), 2)
    frames.append(f3)

    # -------------------------------------------------------------------------
    # PHASE 2: CHALK TURNS BLUE & GLOWS RADIANTLY (Frames 4 to 7)
    # -------------------------------------------------------------------------
    # Frame 4: Spark Ignition - Chalk lines tint cyan with small mana sparks
    f4 = pygame.Surface((W, H), pygame.SRCALPHA)
    # Outer ring in soft blue
    arc_pts = get_ellipse_pts(CX, CY, rx, ry, 0, 360, steps=36)
    draw_chalk_stroke(f4, arc_pts, (120, 220, 255, 230), width=2, dust=False)
    draw_chalk_stroke(f4, star_pts, (120, 220, 255, 230), width=2, dust=False)
    # Blue mana sparks crackling on the lines
    for sp_ang in [30, 110, 210, 300]:
        sa = math.radians(sp_ang)
        sx = CX + rx * math.cos(sa)
        sy = CY + ry * math.sin(sa)
        pygame.draw.circle(f4, (160, 240, 255, 220), (int(sx), int(sy)), 3)
        pygame.draw.circle(f4, (255, 255, 255), (int(sx), int(sy)), 1)
    frames.append(f4)

    # Frame 5: Intense Neon Blue Glow Surge
    f5 = pygame.Surface((W, H), pygame.SRCALPHA)
    # Soft outer glow halo
    glow_surf = pygame.Surface((W, H), pygame.SRCALPHA)
    pygame.draw.ellipse(glow_surf, (20, 120, 255, 80), (CX - rx - 6, CY - ry - 4, (rx + 6) * 2, (ry + 4) * 2), 6)
    f5.blit(glow_surf, (0, 0))
    # Brilliant cyan-blue lines with white core
    draw_chalk_stroke(f5, arc_pts, (40, 160, 255, 240), width=4, dust=False)
    draw_chalk_stroke(f5, arc_pts, MANA_CORE, width=2, dust=False)
    draw_chalk_stroke(f5, star_pts, (40, 160, 255, 240), width=3, dust=False)
    draw_chalk_stroke(f5, star_pts, MANA_CORE, width=1, dust=False)
    # Glowing nodes
    for p in star_pts[:-1]:
        pygame.draw.circle(f5, (80, 220, 255), (int(p[0]), int(p[1])), 4)
        pygame.draw.circle(f5, (255, 255, 255), (int(p[0]), int(p[1])), 2)
    frames.append(f5)

    # Frame 6: Radiance & Ascending Light Beams
    f6 = pygame.Surface((W, H), pygame.SRCALPHA)
    f6.blit(f5, (0, 0))
    # Vertical light pillars rising up from chalk lines into the air
    for lx_off in [-35, -15, 0, 15, 35]:
        lx = CX + lx_off
        ly = CY - 2
        pillar = pygame.Surface((10, 70), pygame.SRCALPHA)
        for step in range(10):
            alpha = int(90 * (1.0 - step / 10.0))
            pygame.draw.line(pillar, (100, 210, 255, alpha), (5, 70 - step * 7), (5, 70 - (step + 1) * 7), 4)
        f6.blit(pillar, (lx - 5, ly - 65))
    frames.append(f6)

    # Frame 7: Dimensional Rift Spark ignites above seal
    f7 = pygame.Surface((W, H), pygame.SRCALPHA)
    f7.blit(f5, (0, 0))
    # Starburst ignition at PORTAL_CY
    pygame.draw.circle(f7, (255, 255, 255), (CX, PORTAL_CY), 6)
    pygame.draw.circle(f7, (100, 220, 255, 220), (CX, PORTAL_CY), 12, 2)
    pygame.draw.circle(f7, (40, 140, 255, 140), (CX, PORTAL_CY), 18, 1)
    # Horizontal flare
    pygame.draw.line(f7, (255, 255, 255, 240), (CX - 22, PORTAL_CY), (CX + 22, PORTAL_CY), 2)
    pygame.draw.line(f7, (255, 255, 255, 240), (CX, PORTAL_CY - 16), (CX, PORTAL_CY + 16), 2)
    frames.append(f7)

    # -------------------------------------------------------------------------
    # PHASE 3: PORTAL APPEARS ABOVE THE GLOWING SEAL (Frames 8 to 11)
    # -------------------------------------------------------------------------
    # In all Phase 3 frames: floor chalk seal remains glowing bright blue!
    for p_idx in range(4):
        f = pygame.Surface((W, H), pygame.SRCALPHA)
        # 1. Base glowing blue chalk seal on the floor
        f.blit(f5, (0, 0))

        # Vertical ethereal energy tether connecting floor seal to portal
        tether_surf = pygame.Surface((W, H), pygame.SRCALPHA)
        pygame.draw.line(tether_surf, (80, 200, 255, 90), (CX - 15, CY), (CX - 20, PORTAL_CY + 10), 2)
        pygame.draw.line(tether_surf, (80, 200, 255, 120), (CX, CY), (CX, PORTAL_CY + 12), 3)
        pygame.draw.line(tether_surf, (80, 200, 255, 90), (CX + 15, CY), (CX + 20, PORTAL_CY + 10), 2)
        f.blit(tether_surf, (0, 0))

        # 2. Swirling Dimensional Portal hovering in the air above
        p_surf = pygame.Surface((90, 90), pygame.SRCALPHA)
        pcx, pcy = 45, 45
        rot_ang = p_idx * (math.pi / 2) # Rotates smoothly across frames

        # Outer glowing runic ring
        p_rad = 34
        pygame.draw.circle(p_surf, (30, 100, 240, 140), (pcx, pcy), p_rad, 4)
        pygame.draw.circle(p_surf, (100, 220, 255, 220), (pcx, pcy), p_rad, 2)

        # Orbiting dimensional nodes
        for i in range(4):
            na = rot_ang + i * (math.pi / 2)
            nx = pcx + int(p_rad * math.cos(na))
            ny = pcy + int(p_rad * math.sin(na))
            pygame.draw.circle(p_surf, (255, 255, 255), (nx, ny), 3)
            pygame.draw.circle(p_surf, (80, 210, 255), (nx, ny), 5, 1)

        # Swirling inner spiral vortex arms
        for arm in range(3):
            arm_base = rot_ang * 1.5 + arm * (2 * math.pi / 3)
            pts_arm = []
            for r_step in range(6, 26, 3):
                theta = arm_base + (r_step * 0.14)
                ax = pcx + int(r_step * math.cos(theta))
                ay = pcy + int(r_step * math.sin(theta))
                pts_arm.append((ax, ay))
            if len(pts_arm) > 1:
                pygame.draw.lines(p_surf, (140, 230, 255, 220), False, pts_arm, 2)

        # Deep cosmic event horizon core
        pygame.draw.circle(p_surf, (10, 18, 45, 240), (pcx, pcy), 14)
        pygame.draw.circle(p_surf, (220, 245, 255, 255), (pcx, pcy), 6)
        pygame.draw.circle(p_surf, (255, 255, 255), (pcx, pcy), 3)

        # Blit portal above floor seal
        f.blit(p_surf, (CX - pcx, PORTAL_CY - pcy))
        frames.append(f)

    return frames

if __name__ == "__main__":
    frames = generate_chalk_portal_frames()
    print(f"Generated {len(frames)} portal animation frames.")

    # Save individual frames
    for i, fr in enumerate(frames):
        fn = f"{OUTPUT_DIR}/portal_chalk_{i}.png"
        pygame.image.save(fr, fn)

    # Compose overview montage
    cols = 4
    rows = 3
    cw, ch = 180, 180
    montage = pygame.Surface((cols * cw + 40, rows * ch + 70))
    montage.fill((14, 16, 22))

    font_title = pygame.font.SysFont("Arial", 18, bold=True)
    font_lbl = pygame.font.SysFont("Arial", 12)

    title = font_title.render("★ ПОРТАЛ 10-ГО ЭТАЖА: МЕЛ -> СИНИЙ СВЕТ -> ПОРТАЛ СВЕРХУ ★", True, (255, 215, 60))
    montage.blit(title, (20, 12))

    labels = [
        "1. Мел: Дуга окружности", "2. Мел: Замыкание круга", "3. Мел: Звездные грани", "4. Мел: Готовый символ",
        "5. Зажигание: Синий след", "6. Накал: Неоновое сияние", "7. Столпы света вверх", "8. Искра разлома сверху",
        "9. Вихрь портала F1", "10. Вихрь портала F2", "11. Вихрь портала F3", "12. Вихрь портала F4"
    ]

    for idx, fr in enumerate(frames):
        c = idx % cols
        r = idx // cols
        bx = 20 + c * cw
        by = 45 + r * ch
        pygame.draw.rect(montage, (22, 26, 36), (bx, by, cw - 10, ch - 10), border_radius=6)
        pygame.draw.rect(montage, (45, 52, 72), (bx, by, cw - 10, ch - 10), 1, border_radius=6)

        # Draw stone floor background tile in box
        pygame.draw.rect(montage, (28, 32, 44), (bx + 10, by + 10, cw - 30, ch - 40))

        scaled = pygame.transform.scale(fr, (cw - 30, ch - 40))
        montage.blit(scaled, (bx + 10, by + 10))

        lbl = font_lbl.render(labels[idx], True, (160, 200, 240))
        montage.blit(lbl, (bx + 8, by + ch - 26))

    montage_path = f"{OUTPUT_DIR}/portal_chalk_overview.png"
    pygame.image.save(montage, montage_path)
    print(f"Saved montage to: {montage_path}")

    # Export animated GIF showing full sequence
    gif_frames = [Image.open(f"{OUTPUT_DIR}/portal_chalk_{i}.png") for i in range(len(frames))]
    # Durations: drawing phase slower (250ms), blue surge (200ms), portal vortex loop (120ms)
    durations = [250, 250, 250, 300, 200, 200, 200, 200, 130, 130, 130, 130]
    gif_path = f"{OUTPUT_DIR}/portal_chalk_ritual.gif"
    gif_frames[0].save(gif_path, save_all=True, append_images=gif_frames[1:], duration=durations, loop=0)
    print(f"Saved animated GIF to: {gif_path}")
