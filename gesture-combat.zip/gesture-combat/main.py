"""
Main entry point for Paint Remake: Rogue Spellcaster (GLYPH-BLADE).
Coordinates and re-exports game components from modular subsystems.
"""

import sys
import os

# Config & Constants
from config import (
    MAP_WIDTH,
    MAP_HEIGHT,
    VIEW_WIDTH,
    VIEW_HEIGHT,
    RESOLUTIONS,
    RESOLUTION_ORDER,
    DEFAULT_RESOLUTION,
    FPS,
    MUTATORS,
    GLYPH_COMPLEXITY,
    FLOOR_WAVES,
    get_floor_data,
    TEXT_WHITE,
    TEXT_GOLD,
    TEXT_RED,
    TEXT_CYAN,
    TEXT_PURPLE,
)

# Entities
from entities import (
    Player,
    Enemy,
    PentagramCataclysm,
)

# Wild Magic System
from wild_magic import (
    WILD_MAGIC_PATTERNS,
    best_template_distance,
    get_wild_magic_pattern_for_queue,
    trigger_wild_magic_start,
    start_wild_magic_ritual,
    evaluate_wild_magic_drawing,
    draw_wild_magic_ritual,
    load_custom_wild_glyphs,
    register_wild_magic_pattern,
)

# Developer Glyph Studio
from dev_glyph_studio import (
    DevGlyphStudio,
    DEV_SECRET_CODE,
    tidy_and_smooth_stroke,
)

# Forge & Synthesis
from forge import (
    get_combo_forge_rects,
    get_slot_element_info,
    draw_combo_forge_menu,
)

# Dialogue System
from dialogue import (
    open_boss_dialogue,
    handle_boss_dialogue_choice,
    close_boss_dialogue,
    draw_boss_dialogue,
)

# Spellcasting System
from spellcasting import (
    cast_gesture_ability,
)

# Art & Sprites
from art import (
    ArtAssets,
    draw_enemy_sprite,
    draw_player_character,
    draw_obstacle,
    draw_grimoire_lectern,
    draw_portal,
)

# HUD & Overlays
from hud import (
    get_boss_info_text,
    draw_hud,
    draw_tome_of_synthesis,
    draw_custom_glyph_forge,
    draw_pause_menu,
    draw_perk_selection,
    draw_permadeath,
    draw_cursor_recharge,
)

# Game Engine
from game_engine import (
    Game,
)


def main():
    """Main application loop entry point."""
    game = Game()
    game.run()


if __name__ == "__main__":
    main()
